"""Write an entry to a swarm scratchpad (specialist side).

Kept separate from swarm_read.py so each specialist agent only needs the
write tool loaded — read is the aggregator's job. Atomic temp-file-rename
so concurrent specialists don't corrupt the scratchpad.
"""
from __future__ import annotations

import argparse
import json
import os
import tempfile
import time
from pathlib import Path

from hermes_constants import get_hermes_home


def write_entry(
    swarm_name: str,
    agent: str,
    payload: dict,
    base_dir: Path | None = None,
) -> None:
    """Atomic append of an agent's entry to the scratchpad."""
    base = base_dir or Path(get_hermes_home()) / "swarms"
    path = base / f"{swarm_name}.json"
    if not path.exists():
        raise FileNotFoundError(
            f"Scratchpad {path} not initialized. Run swarm_init first."
        )
    data = json.loads(path.read_text())
    data["entries"][agent] = {
        "ts": time.time(),
        "payload": payload,
    }
    fd, tmp = tempfile.mkstemp(dir=str(base), prefix=".swarm.", suffix=".tmp")
    try:
        with os.fdopen(fd, "w") as f:
            json.dump(data, f, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def main():
    p = argparse.ArgumentParser(description="Write an entry to a swarm scratchpad.")
    p.add_argument("swarm_name")
    p.add_argument("agent")
    p.add_argument("--payload-json", required=True,
                   help="JSON string to store as the entry payload.")
    p.add_argument("--base-dir", type=Path, default=None)
    args = p.parse_args()
    payload = json.loads(args.payload_json)
    write_entry(args.swarm_name, args.agent, payload, args.base_dir)
    print(f"Wrote entry for {args.agent} to {args.swarm_name}")


if __name__ == "__main__":
    main()