"""Read a swarm scratchpad (aggregator side)."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from hermes_constants import get_hermes_home


def read_scratchpad(swarm_name: str, base_dir: Path | None = None) -> dict:
    base = base_dir or Path(get_hermes_home()) / "swarms"
    path = base / f"{swarm_name}.json"
    if not path.exists():
        return {"swarm": swarm_name, "entries": {}, "missing": True}
    return json.loads(path.read_text())


def main():
    p = argparse.ArgumentParser(description="Read a swarm scratchpad.")
    p.add_argument("swarm_name")
    p.add_argument("--base-dir", type=Path, default=None)
    args = p.parse_args()
    print(json.dumps(read_scratchpad(args.swarm_name, args.base_dir), indent=2))


if __name__ == "__main__":
    main()