# Vault Weekly Digest

## Script
`~/.hermes/scripts/vault-digest.py` — Python script, no_agent=true.

## Purpose
Consolidate vault into a weekly searchable digest at `AI/WeeklyDigests/YYYY-WXX.md`. Keeps a rolling record of vault activity, cross-folder bridges, and topic clusters. Silent on weeks with fewer than 3 touched files.

## Key Design Decisions

### NO_ANOMALIES pattern
```python
if file_count < 3:
    print("NO_ANOMALIES")
    return
```
Silent when vault is quiet. Prevents noisy weekly notifications for no-op runs.

### Git auth in cron context
Cron runs with stripped `$PATH` — `gh` command not found, credential helpers fail. Solution: read token directly from `~/.git-credentials`:
```python
def get_git_token():
    with open(GIT_TOKEN_PATH) as f:
        for line in f:
            if "benclawbot" in line and "@github.com" in line:
                token = line.strip().split(":")[2].split("@")[0]
                return token
```
Then push with: `git push https://benclawbot:{token}@github.com/benclawbot/obsidian-vault-backup.git HEAD:main`

### Vault scan performance
os.walk on 1,145 files takes ~0.2s. Slug detection via yaml frontmatter parsing on every file is the slow step — only parse frontmatter once per file.

### Title extraction
```python
title = os.path.splitext(os.path.basename(f))[0]
if content.startswith('---'):
    parts = content.split('---', 2)
    fm = yaml.safe_load(parts[1])
    if fm and isinstance(fm, dict) and 'title' in fm:
        title = str(fm['title'])
```
Checks frontmatter `title` before falling back to filename.

### Cross-folder bridge analysis
```python
for f in files:
    for link in f['wikilinks']:
        for f2 in files:
            if link.lower() == f2['title'].lower() and f2['folder'] != f['folder']:
                bridges.append((f['relpath'], f['folder'], target, f2['folder']))
```
Title-based matching handles aliased links (link with `|` alias maps to the same target title). Use lower-case comparison for matching, original case for display.

## Output Format

```
# Weekly Vault Digest — YYYY-WXX
*Generated YYYY-MM-DD HH:MM | covers YYYY-MM-DD – YYYY-MM-DD*

## Vault Overview
- total files, word count, wikilink count
- folders with recent activity

## Recent Activity
- folder/ — N file(s), N words
  - [[relpath]] (age, wordcount)
  — and N more

## Cross-Folder Topic Bridges
- N cross-folder connections
- **SourceFolder/** bridges to:
  - [[source]] → OtherFolder/**target**

## Active Topic Clusters
- #term (Nx)
- ...

## Projects Overview
- project-name — status

## Newest Files
- [[relpath]]
...

## Searchable Index
### Folder/
- [[relpath|title]]

## Known Limitation
"touched files" counter uses file modification time — after git operations all files show current mtime. The NO_ANOMALIES threshold (>3 files) prevents spurious digests, but a real activity filter would track git commit changes. Current workaround is sufficient for weekly cadence.

## Weekly Digest Cron
- Schedule: `0 20 * * 1` (Mondays at 8pm)
- deliver: local
- no_agent: true
- workdir: /home/thomas/Desktop/Memory