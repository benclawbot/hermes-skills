---
name: cron-avoid-hammer
description: "Prevents the two most common cron mistakes: using repeat on create (fails with str vs int), and forgetting prompt (create requires it). Use whenever creating or updating cron jobs."
version: 1.0.0
author: Thomas
metadata:
  hermes:
    tags: [cron, automation, hermes]
---

# Cron Avoid Hammer

Prevents two specific gotchas that bite on every use. Load this skill whenever creating or updating cron jobs.

## Gotcha 1: repeat param fails on create

**Symptom:** `str vs int` type error when `repeat` is passed on job creation.

**Rule:** Never pass `repeat` on `cronjob action=create`. Omit it entirely — it defaults to forever. If you need to set a repeat count, create first (no repeat), then `cronjob action=update job_id=<id> repeat=<N>`.

### Correct sequence

```bash
# Create — no repeat param
cronjob action=create name="my-job" prompt="Do the thing" schedule="0 9 * * *"

# Update — only here is repeat allowed
cronjob action=update job_id="<id>" repeat=5

# Wrong — will fail:
cronjob action=create name="my-job" prompt="..." schedule="..." repeat=5
```

## Gotcha 2: prompt is required on create

**Symptom:** Create call fails if `prompt` is absent.

**Rule:** Always include a `prompt` on create, even if it's minimal. The agent needs it to know what to do each tick.

### Minimum viable create

```bash
cronjob action=create \
  name="my-job" \
  prompt="Run health check. On failure: diagnose, fix, retest. Stay silent if healthy." \
  schedule="*/30 * * * *"
```

## `cronjob run` ≠ execution

`cronjob action=run job_id=<id>` returns success but does **not** actually spawn a session or execute the job. It only marks `last_run_at` if the scheduler permits. To test a cron job end-to-end, either:
- Wait for the scheduled time, or
- Manually invoke the underlying script/skill directly

**Do not use `cronjob run` as a test mechanism.** It will mislead you into thinking the job fired.

## Decision tree

| Action | Pattern |
|--------|---------|
| Create new recurring job | `cronjob action=create` + no repeat + prompt required |
| Set repeat count on existing job | `cronjob action=update job_id=<id> repeat=<N>` |
| List jobs | `cronjob action=list` |
| Pause/resume | `cronjob action=pause/resume job_id=<id>` |
| Remove | `cronjob action=remove job_id=<id>` (list first, never guess) |
| **Test a job** | Invoke its script/skill directly — do NOT use `cronjob run` |

## Maintenance job default (silent success)

For jobs that run automated checks or maintenance:
- `deliver: local` — successful runs stay silent
- Include self-healing instructions in the prompt
- Only send a message to Thomas if the issue couldn't be fixed

## Quick reference

```
# Create (correct)
cronjob action=create name="check-discord" prompt="Check Discord connectivity. Silent if OK." schedule="*/15 * * * *"

# Update repeat (correct)
cronjob action=update job_id="abc123" repeat=10

# Create with skills (correct)
cronjob action=create name="daily-research" skills='["last30days"]' prompt="Run daily AI research digest." schedule="0 8 * * *"
```