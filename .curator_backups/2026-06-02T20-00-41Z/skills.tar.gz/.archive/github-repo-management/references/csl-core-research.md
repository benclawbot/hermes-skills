# CSL-Core — Deterministic Policy Enforcement for AI Agents

## What It Is

[Chimera-Protocol/csl-core](https://github.com/Chimera-Protocol/csl-core) — Apache 2.0, Python ≥3.10, `pip install csl-core`

Policy language (`.csl` files) + Z3 formal verification + runtime enforcement. You write declarative rules, Z3 proves they're sound, every action is checked against the compiled policy at runtime — outside the model. The LLM cannot bypass them.

Key dependencies: `z3-solver>=4.12`, `rich`. Optional: langchain, mcp.

## Benchmark (from their README)

| Approach | Attacks Blocked | Bypass Rate | Latency |
|----------|----------------|-------------|---------|
| GPT-4.1 (prompt rules) | 10/22 (45%) | 55% | ~850ms |
| GPT-4o (prompt rules) | 15/22 (68%) | 32% | ~620ms |
| Claude Sonnet 4 (prompt rules) | 19/22 (86%) | 14% | ~480ms |
| Gemini 2.0 Flash (prompt rules) | 11/22 (50%) | 50% | ~410ms |
| **CSL-Core (deterministic)** | **22/22 (100%)** | **0%** | **~0.84ms** |

Why it works: enforcement happens outside the model. Prompt injection is irrelevant because there's nothing to inject against.

## Architecture

- `.csl` files → `cslcore verify` (Z3 formal verification) → compiled guard
- Runtime: `pre_tool_call` hook evaluates each tool call against the guard
- Modes: ADVISORY (warn but allow) / BLOCK (hard block)
- CLI: `cslcore verify`, `cslcore simulate`, `cslcore repl`

## Hermes Integration Point

The `pre_tool_call` hook in `hermes_cli/plugins.py` fires before every tool call. A CSL guard plugin can intercept sensitive operations (terminal, write_file, patch) and block/warn based on loaded `.csl` policies.

Integration plan: `.hermes/plans/2026-05-09_143000-csl-core-policy-enforcement.md`

## Policy Example (safety.csl)

```js
CONFIG {
  ENFORCEMENT_MODE: BLOCK
  CHECK_LOGICAL_CONSISTENCY: TRUE
}

DOMAIN Safety {
  VARIABLES {
    action: {"git_push", "git_add", "terminal"}
    has_credentials: {TRUE, FALSE}
    pre_push_check_done: {TRUE, FALSE}
  }

  STATE_CONSTRAINT git_push_requires_staging_check {
    WHEN action == "git_push"
    THEN pre_push_check_done == TRUE
  }

  STATE_CONSTRAINT no_build_artifacts_in_git {
    WHEN action == "git_add"
    THEN NOT contains_blocked_path([
      ".wrangler/", ".next/", "dist/", "*.map",
      "secrets.json", "credentials.json"
    ])
  }
}
```

## Topics / Keywords

`agent-framework`, `ai-governance`, `ai-safety`, `deterministic-ai`, `formal-verification`, `hallucination-prevention`, `langchain`, `llm-safety`, `mcp`, `mcp-server`, `neuro-symbolic`, `policy-as-code`, `state-machine`, `tla-plus`, `z3`