# GitHub Secret Scanning Alerts

## Listing Alerts

```bash
# List all open alerts for a repo
gh api "repos/{owner}/{repo}/secret-scanning/alerts" \
  --jq '.[] | "\(.number)|\(.secret_type)|\(.state)|\(.resolution)"'

# Full detail
gh api "repos/{owner}/{repo}/secret-scanning/alerts" --paginate \
  --jq '.[] | {type: .secret_type, state: .state, commit: .commit_id, file: .location.path, created: .created_at}'
```

## Resolving Alerts

**Via REST API (required for bulk resolution):**

```bash
# Resolution types accepted: false_positive, wont_fix, revoked, used_in_tests
curl -s -XPATCH "https://api.github.com/repos/{owner}/{repo}/secret-scanning/alerts/{alert_number}" \
  -H "Authorization: Bearer $(gh auth token)" \
  -H "Accept: application/vnd.github+json" \
  -H "X-GitHub-Api-Version: 2022-11-28" \
  -d '{
    "state": "resolved",
    "resolution": "false_positive",
    "resolution_comment": "Development test credentials in build artifacts, removed from git history"
  }'
```

**Bulk resolve all open alerts:**

```bash
# Get alert numbers and resolve each
for num in $(gh api "repos/{owner}/{repo}/secret-scanning/alerts" \
  --jq '.[] | select(.state == "open") | .number'); do
  curl -s -XPATCH "https://api.github.com/repos/{owner}/{repo}/secret-scanning/alerts/$num" \
    -H "Authorization: Bearer $(gh auth token)" \
    -H "Accept: application/vnd.github+json" \
    -H "X-GitHub-Api-Version: 2022-11-28" \
    -d '{"state":"resolved","resolution":"false_positive","resolution_comment":"Credentials in dev artifacts, removed from git history"}'
  echo "Resolved alert $num"
done
```

**Note:** `gh api` PATCH may 422 — use `curl` directly with the raw `state: resolved` + `resolution: <type>` payload.

## Removing Secrets from Git History

When secrets are detected in old commits (e.g., in build artifacts), remove them from history:

```bash
cd /path/to/repo

# Dry run first — see what would be removed
git filter-branch --force --index-filter \
  "git rm -rf --cached --ignore-unmatch .wrangler/" \
  --prune-empty --tag-name-filter cat -- --all

# Actual rewrite
git filter-branch --force --index-filter \
  "git rm -rf --cached --ignore-unmatch .wrangler/" \
  --prune-empty --tag-name-filter cat -- --all 2>&1 | tail -5

# Verify file is gone from history
git show HEAD:.wrangler/tmp/bundledWorker-0.6953392102020891.mjs 2>/dev/null | grep "sk_test_" && echo "STILL PRESENT" || echo "Clean"

# Force push to update remote
git push --force https://user:$(gh auth token)@github.com/owner/repo.git --all
git push --force https://user:$(gh auth token)@github.com/owner/repo.git --tags
```

**Other paths to remove specific files:**
```bash
# Remove a specific file from all history
git filter-branch --force --index-filter \
  "git rm --cached --ignore-unmatch path/to/secret.json" \
  --prune-empty --tag-name-filter cat -- --all

# Remove by content pattern (requires tree filter, slower)
git filter-branch --force --tree-filter \
  "find . -name '*.map' -exec grep -l 'sk_test_' {} \; -delete" \
  --prune-empty --tag-name-filter cat -- --all
```

## Key Lessons

1. **Vault backup repos must be separate from application repos** — pushing a vault to a live project repo contaminates it with whatever the vault contains, including build artifacts with credentials
2. **gh auth token ≠ git credential helper** — gh CLI can be authenticated while git's credential helper is broken; push with token-embedded URL to bypass
3. **Build artifacts (`.wrangler/`, `.next/`, `dist/`) should be in `.gitignore`** — even if not committed, cached versions can end up in git history during build
4. **Secret scanning alerts track by commit content** — resolving as false_positive doesn't remove the secret from history; git history rewrite is also needed for true remediation
5. **Credential helper breakage pattern**: `gh auth status` shows authenticated but push 403s with "Invalid username or token" — the credential helper store is broken but gh token itself is valid; embed token in URL directly as workaround