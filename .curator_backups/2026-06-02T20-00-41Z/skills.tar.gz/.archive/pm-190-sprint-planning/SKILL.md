---
name: pm-190-sprint-planning
description: Plan a sprint — select backlog items, commit to a sprint goal, assign work to team members, and produce the sprint plan.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, scrum, sprint, agile]
    trigger: [sprint planning, sprint plan, sprint backlog, sprint commitment, sprint goal, agile planning]
    trigger_context: "Thomas planning a sprint with the team — selecting items, committing to a goal, and assigning work"
---
# PM-190: Sprint Planning

## What
Plan the upcoming sprint: select backlog items the team commits to completing, define the sprint goal, break down stories into tasks, and assign work based on capacity.

## Inputs Required
| Input | Source |
|-------|--------|
| Product backlog (prioritized) | Product Owner |
| Team capacity (hours/points) | Availability calendar |
| Sprint velocity (historical) | pm-sprint-helper skill |
| Technical债务 level | Tech Lead |
| Impediments from previous sprint | Scrum Master |

## Sprint Capacity Calculation
1. Sum individual team member availability (hours) for sprint duration
2. Subtract 20% for meetings, admin, unexpected interruptions
3. Convert to story points using team's historical velocity

> Available capacity = Σ(member hours) × 0.80

> Recommended sprint commitment = Average velocity × 0.85 (conservative)

## Story Selection Heuristics
- Select highest-priority stories first
- Balance story types (features, tech debt, bugs, infrastructure)
- Ensure stories are INVEST-ready (Independent, Negotiable, Valuable, Estimable, Small, Testable)
- Mix of risk levels — don't put all high-risk stories in one sprint

## Step-by-Step SOP
1. **Review velocity**: Pull last 3-5 sprints from pm-220-sprint-velocity, calculate average
2. **Calculate capacity**: Sum team member availability for sprint length, apply 0.80 factor
3. **Define sprint goal**: One sentence describing what the sprint will deliver
4. **Select stories**: Work down backlog, selecting stories until capacity is reached
5. **Break down to tasks**: Each story → tasks (design, develop, test, document)
6. **Assign tasks**: Match tasks to team members based on skill and workload
7. **Estimate in hours**: Each task estimated, total vs. capacity — adjust if over/under
8. **Confirm commitment**: Team agrees to sprint goal and plan
9. **Update backlog**: Move selected stories to sprint backlog, update status

## Sprint Plan Output
### Sprint Header
| Field | Value |
|-------|-------|
| Sprint | #27 |
| Duration | 2 weeks (2024-03-04 to 2024-03-15) |
| Sprint Goal | Complete user authentication module and payment integration |
| Team capacity | 120 hours |
| Velocity target | 35 story points |

### Commitment Table
| Story ID | Title | SP | Tasks | Owner | Hours |
|----------|-------|-----|-------|-------|-------|
| SP-101 | User login page | 5 | Design, Dev, Test | Jean-Didier | 12h |
| SP-102 | OAuth2 integration | 8 | Design, Dev, Test | Nathanael | 16h |
| ... | ... | ... | ... | ... | ... |
| **TOTAL** | | **35** | | | **118h** |

### Risks and Assumptions
- **Risk**: OAuth2 library compatibility with existing SSO — mitigated byspike in sprint 26
- **Assumption**: API team will deliver payment gateway by March 8

## Task Breakdown Template
| Story | Task | Owner | Estimated |
|-------|------|-------|-----------|
| SP-101: User login page | Create login UI mockup | JD | 2h |
| | Implement backend auth endpoint | Nathanael | 4h |
| | Write unit tests | Guillaume | 2h |
| | Integration test | Atmane | 2h |
| | Update API docs | Ludovic | 1h |

## Automation Tier
**Tier 2 — Accelerate**: Hermes pulls velocity history, calculates capacity, drafts the sprint commitment table, and identifies if commitment is over/under.

## Limitations
- Sprint planning is a team activity — cannot be fully automated
- Story selection requires business judgment (Product Owner)
- Capacity estimates are estimates — actual may vary