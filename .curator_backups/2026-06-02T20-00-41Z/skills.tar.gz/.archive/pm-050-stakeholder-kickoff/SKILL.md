---
name: pm-050-stakeholder-kickoff
description: Facilitate the stakeholder kickoff meeting to align all key stakeholders on project objectives, governance, and working agreements.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, stakeholder-kickoff, meeting-facilitation, project-launch, alignment]
    trigger: [stakeholder kickoff, kickoff meeting, project launch, stakeholder alignment, project initiation meeting]
    trigger_context: "Thomas as Senior IT PM running the kickoff meeting with stakeholders — aligning expectations, establishing governance and communication norms"
---

# Stakeholder Kickoff Meeting SOP

## What This SOP Does

The Stakeholder Kickoff skill provides a structured approach to facilitate the official project kickoff meeting with all key stakeholders. It establishes project foundation by aligning on objectives, roles, governance, communication norms, and working agreements, ensuring all parties start the project with shared understanding and clear expectations.

**Purpose:** Officially launch the project with stakeholders, establish relationships, align on expectations, and create a foundation for successful collaboration throughout the project lifecycle.

## Step-by-Step Process

### Phase 1: Pre-Meeting Preparation

#### 1.1 Confirm Attendees and Logistics
- Review stakeholder register for required attendees
- Confirm attendance with each stakeholder (minimum 1 week notice)
- Book appropriate meeting room or video conference platform
- Send calendar invitations with agenda attached
- Arrange for meeting support (note-taker, technology assistance)

#### 1.2 Prepare Meeting Materials
- Finalize project charter presentation deck
- Prepare stakeholder communication plan draft
- Develop governance documentation (roles, RACI, escalation)
- Create project timeline overview (high-level milestones)
- Prepare meeting notes template
- Arrange for any physical materials or handouts

#### 1.3 Brief Key Stakeholders
- Meet with sponsor separately to align on key messages
- Confirm sponsor availability for opening remarks
- Brief any stakeholders with specific concerns or questions
- Address any pre-meeting objections or issues

### Phase 2: Run the Meeting

#### 2.1 Welcome and Introductions (10% of time)
- Sponsor opens meeting with official welcome
- PM introduces project team members
- Stakeholders introduce themselves and their role
- Establish meeting tone (collaborative, productive)

#### 2.2 Project Overview (15% of time)
- Present project purpose and business context
- Summarize project objectives (SMART format)
- Share high-level scope (in and out of scope)
- Present expected outcomes and benefits
- Connect project to organizational strategy

#### 2.3 Objectives Review and Validation (15% of time)
- Present project objectives for stakeholder input
- Invite questions and feedback on objectives
- Document any suggested modifications
- Confirm alignment on priorities

#### 2.4 Roles and Governance (20% of time)
- Present governance structure and decision-making bodies
- Review RACI matrix for key activities
- Define escalation path and thresholds
- Clarify PM authority and limitations
- Confirm stakeholder roles and responsibilities

#### 2.5 Communication Plan (15% of time)
- Present communication cadence and channels
- Share reporting schedule and formats
- Define meeting rhythms (steering committee, team, stakeholders)
- Establish meeting norms and participation expectations
- Review meeting notes and action item processes

#### 2.6 Timeline and Milestones (10% of time)
- Present high-level project timeline
- Highlight key milestones and dependencies
- Share any known constraints or deadlines
- Discuss timeline review and update process

#### 2.7 Working Agreements (10% of time)
- Establish team collaboration norms
- Define decision-making protocols
- Agree on conflict resolution approach
- Set expectations for responsiveness
- Document working agreements for reference

#### 2.8 Questions, Answers, and Open Discussion (remaining time)
- Facilitate open Q&A session
- Address specific concerns or questions
- Capture issues requiring follow-up
- Identify action items from discussion

#### 2.9 Next Steps and Close (5% of time)
- Summarize agreed-upon items
- Confirm next steps and owners
- Thank participants for attendance
- Confirm next meeting date if applicable

### Phase 3: Post-Meeting Follow-Up

#### 3.1 Distribute Meeting Outputs
- Send meeting notes within 24-48 hours
- Include captured action items with owners and dates
- Share approved project charter (if finalized)
- Distribute communication plan and governance documents

#### 3.2 Address Action Items
- Track all action items in project register
- Follow up on questions requiring research
- Address concerns raised during meeting
- Update stakeholder register with any changes

#### 3.3 Confirm Ongoing Engagement
- Schedule individual stakeholder check-ins as needed
- Set up recurring governance meetings
- Confirm communication channel access (chat, listservs)
- Establish baseline for stakeholder satisfaction

## Meeting Agenda Template

```
STAKEHOLDER KICKOFF MEETING
===========================

Date: [Date]
Time: [Time] - [Duration]
Location: [Room/Video Link]
Facilitator: [PM Name]

ATTENDEES
---------
Required:
- [Sponsor Name]
- [PM Name]
- [Stakeholder 1]
- [Stakeholder 2]

Optional:
- [Observer 1]

PRE-MEETING MATERIALS
---------------------
- Project Charter (draft or final)
- Communication Plan (draft)
- High-level Timeline
- RACI Matrix

AGENDA
------

| Time | Topic | Presenter | Outcome |
|------|-------|-----------|---------|
| 0:00 | Welcome and Introductions | Sponsor | Warm start, attendee awareness |
| 0:15 | Project Overview | PM | Shared understanding of project |
| 0:30 | Objectives Review | PM | Validated alignment |
| 0:45 | Roles and Governance | PM | Clear decision paths |
| 1:00 | Communication Plan | PM | Communication expectations set |
| 1:15 | Timeline and Milestones | PM | Timeline awareness |
| 1:30 | Working Agreements | PM | Collaboration norms established |
| 1:45 | Q&A and Discussion | All | Concerns addressed |
| 2:00 | Next Steps and Close | PM/Sponsor | Clear action orientation |

POST-MEETING
------------
Notes distributed by: [Date]
Action items tracked by: [Date]
Follow-up meeting: [Date/Time if scheduled]
```

## Meeting Output Templates

### Meeting Notes Template

```
MEETING NOTES
=============

Meeting: [Project Name] Kickoff
Date: [Date]
Time: [Time]
Location: [Location]
Facilitator: [Name]
Note Taker: [Name]

ATTENDEES
---------
| Name | Role | Present |
|------|------|---------|
|      |      | Yes/No  |

AGENDA SUMMARY
--------------
[Brief notes on each agenda topic discussed]

KEY DISCUSSION POINTS
----------------------
- [Point 1]
- [Point 2]

DECISIONS MADE
--------------
| Decision | Rationale | Approver |
|----------|-----------|----------|
|          |           |          |

OPEN ISSUES
-----------
| Issue | Owner | Due Date | Status |
|-------|-------|----------|--------|
|       |       |          | Open   |

ACTION ITEMS
------------
| # | Action | Owner | Due Date | Status |
|---|--------|-------|----------|--------|
| 1 |        |       |          | Open   |
| 2 |        |       |          | Open   |

NEXT MEETING
------------
Date: [Date]
Time: [Time]
Topic: [Topic]

DISTRIBUTION
------------
| Recipient | Method | Date Sent |
|-----------|--------|-----------|
|            |        |           |
```

### Working Agreements Template

```
PROJECT WORKING AGREEMENTS
==========================

Project Name: [Project Title]
Date Established: [Date]
Version: [X.X]

COLLABORATION NORMS
-------------------
| Norm | Agreement |
|------|------------|
| Response Time | [e.g., Email within 24 hours, calls returned same day] |
| Meeting Attendance | [e.g., Notify PM if unable to attend] |
| Decision Deadlines | [e.g., Decisions within 5 business days of request] |
| Information Sharing | [e.g., Share relevant docs within 3 days] |
| Conflict Resolution | [e.g., Raise to PM, then Steering Committee] |

COMMUNICATION STANDARDS
-----------------------
| Type | Frequency | Format | Owner |
|------|-----------|--------|-------|
| Status Reports | Weekly | Email with attachment | PM |
| Steering Committee | Bi-weekly | Meeting | PM |
| Stakeholder Updates | Monthly | Email digest | PM |

DECISION-MAKING PROTOCOL
------------------------
| Decision Type | Authority | Escalation |
|---------------|-----------|------------|
| Scope Changes (minor) | PM | Sponsor notification |
| Scope Changes (major) | Steering Committee | Sponsor approval |
| Budget Changes (<5%) | PM | Sponsor approval |
| Budget Changes (>5%) | Steering Committee | Executive approval |

DOCUMENT VERSION CONTROL
------------------------
| Document | Version | Last Updated | Location |
|----------|---------|--------------|----------|
| Project Charter | | | |
| Communication Plan | | | |
| Meeting Notes | | | |

PARTIES WHO AGREED
-------------------
| Name | Role | Signature | Date |
|------|------|-----------|------|
|      |      |           |      |
```

## Data Sources

- Project Charter: Authorization document and authority baseline
- Stakeholder Register: Attendee list, roles, communication preferences
- Communication Plan (Draft): Proposed communication structure
- Governance Documentation: RACI matrix, decision frameworks
- Project Timeline: High-level milestones for presentation
- Meeting Notes Template: Standard format for capturing output

## Automation Tier

**Tier 3 — Augment (Human-Facilitated with AI Assistance)**

This skill augments the kickoff meeting by:
- AI assists in generating meeting agenda
- AI drafts meeting notes from provided information
- AI compiles action items into structured format
- AI formats and distributes meeting outputs
- Human facilitates meeting, reads room, handles discussion
- Human makes judgment calls on agenda adjustments
- Human manages conflict resolution and relationship building

AI augmentation accelerates documentation and follow-up but does not replace human facilitation and judgment during the meeting itself.

## Known Limitations

- Meeting effectiveness depends on stakeholder preparation and participation
- Complex stakeholder dynamics may require additional individual meetings
- Some stakeholders may not be available; proxy representation may be needed
- Virtual meetings may limit interaction compared to in-person
- Time constraints may prevent thorough coverage of all topics
- Follow-through on commitments depends on stakeholder accountability
- Working agreements require ongoing enforcement
- Decisions made may need formal ratification after meeting
- Some stakeholders may need individual alignment before group meeting
