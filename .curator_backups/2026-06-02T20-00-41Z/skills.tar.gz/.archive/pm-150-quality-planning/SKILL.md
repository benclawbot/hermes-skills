---
name: pm-150-quality-planning
description: Define project quality standards, QA activities, quality metrics, and acceptance criteria that all deliverables must meet.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, quality, QA]
    trigger: [quality planning, QA plan, quality standards, acceptance criteria, quality metrics, test plan, quality gates]
    trigger_context: "Thomas defining quality standards and QA activities for a project — quality plan with metrics and acceptance criteria"
---
# PM-150: Quality Planning

## What
Define measurable quality objectives, QA activities, quality metrics with thresholds, and acceptance criteria that each deliverable must satisfy.

## Quality Objectives Examples
| Domain | Metric | Target |
|--------|--------|--------|
| Defect quality | Defect density | < 2 defects / KLOC |
| Testing | Test pass rate | ≥ 95% |
| Code quality | Code coverage | ≥ 80% |
| Performance | Response time | < 200ms p95 |
| Availability | Uptime | ≥ 99.5% |
| Security | Critical vulnerabilities | 0 open |

## QA Activities by Phase
| Phase | QA Activities |
|-------|--------------|
| Initiation | Peer review of business case, charter |
| Planning | Review of requirements, acceptance criteria |
| Execution | Peer reviews, unit testing, integration testing, UAT, code coverage analysis |
| Monitoring | Defect tracking, metric monitoring, test report review |
| Closure | Final QA sign-off, post-project quality review |

## Quality Gates
Quality gates are checkpoints at the end of each phase where deliverables must meet defined criteria before proceeding.
- **Gate 1 (Initiation)**: Business case approved, stakeholders aligned
- **Gate 2 (Planning)**: Requirements signed off, WBS approved, plan baselined
- **Gate 3 (Design)**: Design documents reviewed, architecture approved
- **Gate 4 (Development)**: Code meets quality thresholds (coverage, defects), ready for UAT
- **Gate 5 (UAT)**: Acceptance criteria met, sign-off obtained
- **Gate 6 (Go-Live)**: Deployment criteria met, rollback plan ready
- **Gate 7 (Closure)**: All deliverables accepted, lessons learned documented

## Step-by-Step SOP
1. Review project scope, stakeholder requirements, and organizational quality standards
2. Define quality objectives for this project (use table above as starting point)
3. Define acceptance criteria for each major deliverable — must be measurable and testable
4. Select QA activities appropriate to the project type (agile vs. waterfall, software vs. infrastructure)
5. Define metrics and thresholds — what is green, yellow, red
6. Assign QA responsibilities (who does peer reviews, who runs tests, who signs off)
7. Document in quality plan
8. Integrate quality gates into project schedule
9. During execution: track metrics, report status, trigger actions when thresholds breached

## Output: Quality Plan
### Quality Objectives
| Objective | Metric | Measurement Method | Target | Threshold (Red) |
|-----------|--------|-------------------|--------|-----------------|
| Code quality | Code coverage % | CI pipeline tool | ≥ 80% | < 60% |
| Defect density | Defects/KLOC | SonarQube | < 2 | > 5 |
| Performance | Response time p95 | Load test | < 200ms | > 500ms |
| Security | Critical vulns | Security scan | 0 | ≥ 1 |

### Acceptance Criteria Table
| Deliverable | Acceptance Criteria | Owner | Sign-off Date |
|-------------|---------------------|-------|---------------|
| API Gateway | Handles 1000 req/s, <50ms latency, 0 critical vulns | Dev Lead | [date] |
| User portal | All user stories accepted, browser compatibility tested | QA Lead | [date] |
| Documentation | All API endpoints documented, examples provided | Tech Writer | [date] |

### QA Activities Checklist
- [ ] Peer review completed for all major changes
- [ ] Unit test coverage ≥ 80%
- [ ] Integration tests passing
- [ ] UAT signed off by business owner
- [ ] Security scan shows 0 critical vulnerabilities
- [ ] Performance test meets target under load

## Data Sources
- Project charter
- Requirements register (pm-060-requirements-elicitation)
- Organizational quality standards
- Industry benchmarks

## Automation Tier
**Tier 2 — Accelerate**: Hermes can draft quality objectives and acceptance criteria from requirements. Automated QA tracking (CI/CD pipeline metrics) can feed directly into status reports.

## Limitations
- Quality targets must be realistic given budget and schedule constraints
- Too many metrics create overhead — focus on 5-7 key indicators
- Acceptance criteria must be agreed with stakeholders before development starts