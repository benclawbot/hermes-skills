---
name: pm-160-scope-change-control
description: Manage scope changes through a formal change control process — request, evaluate impact, approve/reject, and track all changes.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, change-control, scope]
    trigger: [change control, scope change, change request, CR, change board, change management]
    trigger_context: "Thomas managing scope changes through formal change control — evaluating impact and getting approvals"
---
# PM-160: Scope Change Control

## What
Ensure all scope changes go through a formal process: request → assess impact → present to change board → approve/reject → update baseline → track.

## Change Request Fields
| Field | Description |
|-------|-------------|
| CR ID | Sequential identifier (CR-001, CR-002...) |
| Title | Short description |
| Requestor | Who is asking |
| Date | Date submitted |
| Priority | Low / Medium / High / Critical |
| Description | Detailed change requested |
| Justification | Why this change is needed |
| Impact Assessment | Scope, schedule, cost, quality, risk |
| Proposed Solution | How to implement |
| Dependencies | What other items depend on this |

## Impact Assessment Dimensions
- **Scope**: What WBS elements are affected? Is the change within or outside original scope?
- **Schedule**: What is the schedule impact? Can it be absorbed or does it need extra time?
- **Cost**: What is the cost impact? Labor, materials, vendor costs?
- **Quality**: Does the change affect quality targets or acceptance criteria?
- **Risk**: Does it introduce new risks or change existing risk scores?

## Change Control Board (CCB)
| Role | Responsibility |
|------|---------------|
| Sponsor | Final approval for high-impact changes |
| PM | Assess impact, present to CCB, update baseline |
| Technical Lead | Technical feasibility and impact |
| Business Owner | Business value and priority |

## Step-by-Step SOP
1. **Log change request**: Assign CR ID, record date, requestor, description
2. **Assess impact**: PM reviews change against baseline — scope, schedule, cost, quality, risk
3. **Score priority**: Low/Medium/High/Critical based on impact dimensions
4. **Present to CCB**: For Medium and above, present impact assessment and proposed solution
5. **Decision**: Approve (with conditions), Reject, Defer
6. **If approved**: Update project baseline (scope, schedule, budget), communicate to team, update WBS
7. **Track**: Monitor change requests in log — how many requested, approved, rejected
8. **Close**: Once change is implemented, close CR and verify in status report

## Output: Change Request Log
| CR ID | Title | Requestor | Date | Priority | Impact (€) | Impact (days) | Status | Approved By |
|-------|-------|-----------|------|----------|------------|---------------|--------|-------------|
| CR-001 | Add OAuth2 support | Product Owner | 2024-03-01 | High | €12,000 | +10 days | Approved | Sponsor |
| CR-002 | Remove reporting module | Business Lead | 2024-03-05 | Medium | -€5,000 | -3 days | Approved | PM |
| CR-003 | Extra integration testing | QA Lead | 2024-03-10 | Low | €2,000 | +2 days | Rejected | PM |
| ... | ... | ... | ... | ... | ... | ... | ... | ... |

## Output: Change Control Board Agenda
1. Review new CRs since last meeting
2. For each CR: PM presents → CCB questions → vote (Approve/Reject/Defer)
3. Review approved CRs — status of implementation
4. Review deferred CRs — any new information?
5. Review rejected CRs — any appeal?

## Data Sources
- Project baseline (WBS, schedule, budget)
- Stakeholder requests
- Issue log

## Automation Tier
**Tier 2 — Accelerate**: Hermes can draft CR impact assessment based on change description. CR log can be auto-formatted and submitted. CCB agenda auto-generated from pending CRs.

## Limitations
- Change control process must be proportionate — don't over-process trivial changes
- Speed matters: a slow change process creates backlog and team frustration
- All approved changes must update the baseline — don't let scope creep silently erode the plan