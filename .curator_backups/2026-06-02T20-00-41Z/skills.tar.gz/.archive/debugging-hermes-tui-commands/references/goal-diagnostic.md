# Goal Loop Diagnostic Recipe

## Quick Check — Is the Goal Actually Stuck?

```bash
# 1. Check all goal states
python3 -c "
import sqlite3, json
db = sqlite3.connect('/home/thomas/.hermes/state.db')
cur = db.cursor()
cur.execute(\"SELECT key, value FROM state_meta WHERE key LIKE 'goal%'\")
for k, v in cur.fetchall():
    d = json.loads(v)
    print(f'{k}:')
    print(f'  status={d[\"status\"]}, turns={d[\"turns_used\"]}/{d[\"max_turns\"]}')
    print(f'  verdict={d.get(\"last_verdict\")}, reason={d.get(\"last_reason\",\"\")[:100]}')
    print(f'  goal={d[\"goal\"][:80]}')
"

# 2. Check latest session for actual output
ls -lt ~/.hermes/sessions/session_*.json | head -5

# 3. Check if hermes process is alive but TUI is frozen
ps aux | grep hermes | grep -v grep
```

## Interpretation

| status | turns_used vs max_turns | verdict | Meaning |
|--------|------------------------|---------|---------|
| `active` | `< max_turns` | `continue` | Still working, may be slow |
| `active` | `< max_turns` | `null` | Just started, judge hasn't fired yet |
| `active` | `>= max_turns` | any | Exhausted turn budget, will stop |
| `paused` | any | any | Auto-paused (budget or parse failures) |
| `done` | any | `done` | Goal completed successfully |
| `cleared` | any | any | User cleared it |

## If Goal Is Done But TUI Is Frozen

The agent finished the work but the TUI couldn't render the output (usually "window too small"). The session JSON has the actual output:

```bash
# Find the session with the goal output
cat ~/.hermes/sessions/session_<id>.json | python3 -c "
import json, sys
d = json.load(sys.stdin)
for m in d.get('messages', []):
    if m.get('role') == 'assistant' and m.get('content'):
        print(m['content'][:500])
        print('---')
"
```

## Kill and Restart

```bash
# Kill the frozen TUI process (get PID from ps aux)
kill <pid>

# Or force-kill if needed
kill -9 <pid>

# Restart
hermes
```
