---
name: pm-090-schedule-development
description: Build the project schedule using Gantt charts, assign durations, identify the critical path, and set milestones.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, schedule-management, gantt-chart, milestones, critical-path]
    trigger: [schedule development, Gantt chart, project schedule, critical path, milestones, schedule baseline, float calculation]
    trigger_context: "Thomas building the project schedule — Gantt chart, critical path, milestones, and baseline schedule"
---

# Schedule Development SOP

## What This SOP Does

This skill guides Thomas through building a complete project schedule using Gantt charts, incorporating activity durations, resource assignments, critical path identification, milestones, and schedule baseline establishment.

## Step-by-Step Schedule Development Process

### 1. Assign Durations to Activities
- Review activity list from activity sequencing
- Apply duration estimates to each activity
- Convert effort estimates to calendar durations considering resource availability
- Apply appropriate calendar working days
- Account for holidays and non-working periods
- Document assumptions used in duration estimates

### 2. Apply Resources
- Assign team members/resources to each activity
- Consider resource skills and availability
- Note resource requirements per activity
- Identify resource conflicts or constraints
- Document any shared resources across activities

### 3. Calculate Schedule
- Using network diagram and durations, calculate start/end dates
- Apply calendar constraints (start dates, deadline constraints)
- Calculate early start/finish and late start/finish dates
- Determine float for each activity
- Apply dependencies with lead/lag adjustments
- Identify the critical path

### 4. Identify Critical Path
- Calculate total float for all activities
- Identify path(s) with zero or near-zero float
- Confirm critical path activities in sequence
- Verify critical path represents the longest path through the network
- Document critical path for stakeholder communication

### 5. Add Milestones
- Define key checkpoints and decision points
- Identify phase-end milestones
- Add external milestones (dependencies on external events)
- Set milestone owners and acceptance criteria
- Clearly label milestone dependencies

### 6. Set Schedule Baseline
- Review complete schedule with stakeholders
- Validate logical flow and dependencies
- Confirm milestone dates are achievable
- Document baseline with version control
- Obtain formal approval of baseline schedule
- Store baseline for variance measurement

### 7. Perform Resource Leveling (Introduction)
- Identify resource over-allocations
- Attempt to resolve conflicts by adjusting:
  - Activity timing within float
  - Resource assignments
  - Activity dependencies (where flexible)
- Recognize that resource leveling may extend the schedule
- Document changes made for resource balancing

## Gantt Chart Basics

A Gantt chart is a horizontal bar chart that illustrates a project schedule.

### Chart Components

| Component | Description |
|-----------|-------------|
| **Bars** | Horizontal bars representing activity duration |
| **Time Scale** | Calendar dates along the top |
| **Activities** | List of activities along the left side |
| **Dependencies** | Arrows connecting related activities |
| **Milestones** | Diamond markers for key points |
| **Slack/Float** | Shaded areas showing available delay |

### Gantt Chart Example (Markdown Table Format)

```
Project Schedule: Website Redesign
Timeline: Q1 2026

| ID | Activity | Owner | Week 1 | Week 2 | Week 3 | Week 4 | Week 5 | Week 6 |
|----|----------|-------|--------|--------|--------|--------|--------|
| A  | Requirements | Sarah | ████   |       |        |        |        |        |
| B  | Design | Tom |       | ████   | ████   |        |        |        |
| C  | Development | Dev Team |     |        | ████   | ████   | ████   |        |
| D  | Testing | QA Team |        |        |        | ████   | ████   |        |
| E  | Deployment | DevOps |       |        |        |        | ████   | ████   |
| ◇  | Milestone: Go-Live | |        |        |        |        |        | ◇ |

Legend: ████ = Duration  ◇ = Milestone
```

## Critical Path Identification

The critical path is the longest sequence of activities through the project network, determining the minimum project duration.

### Identifying Critical Path Activities

1. **Zero float activities**: Activities with Total Float = 0 are on the critical path
2. **Longest path**: Trace the path(s) with greatest total duration
3. **Network boundaries**: Critical path connects project start to finish

### Critical Path Characteristics

- **Duration**: Defines minimum project length
- **Zero float**: Any delay on critical path delays the project
- **Multiple paths**: Projects may have near-critical paths
- **Changes over time**: Critical path can shift as activities complete

### Critical Path Example

```
Network: A(3) ──► B(5) ──► D(4) ──► F(2)     = 14 days (Critical Path)
                │
                ▼
           C(2) ──► E(3) ──┘                = 10 days

Critical Path: A → B → D → F (14 days)
Float: C has 2 days, E has 2 days
```

## Milestone Definition

Milestones are significant points or events in the project schedule with zero duration.

### Common Project Milestones

| Milestone | Description | Phase |
|-----------|-------------|-------|
| **Project Start** | Official project kickoff | Initiation |
| **Requirements Approved** | Business sign-off on requirements | Planning |
| **Design Complete** | All design documents finalized | Planning |
| **Development Complete** | All coding finished | Execution |
| **UAT Start** | User acceptance testing begins | Execution |
| **UAT Complete** | Testing signed off | Execution |
| **Go-Live** | Production deployment | Execution |
| **Project Close** | Final project sign-off | Closing |

### Milestone List Template

| Milestone | Description | Target Date | Owner | Status | Dependencies |
|-----------|-------------|-------------|-------|--------|-------------|
| M1 | Project Kickoff | 2026-01-15 | PM | Complete | None |
| M2 | Requirements Approved | 2026-01-31 | BA | Approved | M1 |
| M3 | Design Complete | 2026-02-28 | Architect | In Progress | M2 |
| M4 | UAT Start | 2026-04-15 | QA Lead | Planned | M3 |
| M5 | Go-Live | 2026-05-01 | PM | Planned | M4 |

## Schedule Baseline Establishment

### What is a Schedule Baseline?
The approved version of the project schedule that serves as a reference point for measuring performance.

### Baseline Components
- **Planned start and finish dates** for all activities
- **Milestone dates**
- **Planned resource assignments**
- **Scheduled dates for each WBS element**

### Baseline Documentation

```
Schedule Baseline Document
==========================
Project: [Project Name]
Version: [Baseline Version Number]
Date: [Baseline Approval Date]
Approved By: [Approver Name]

Summary:
- Planned Start Date: [Date]
- Planned Finish Date: [Date]
- Planned Duration: [X] working days
- Number of Milestones: [N]
- Number of Activities: [N]

Critical Path: [List activities on critical path]

Key Milestones:
- [Milestone]: [Date]
- [Milestone]: [Date]

Change Control:
This baseline is locked. Any changes require formal change request approval.
```

## Resource Leveling Introduction

### When Resource Leveling is Needed
- Multiple activities scheduled for the same resource simultaneously
- Resource availability constraints (vacations, other projects)
- Skills availability limited

### Resource Leveling Approaches

1. **Adjust within float**: Delay non-critical activities to smooth resource usage
2. **Adjust dependencies**: Use alternative dependency relationships where possible
3. **Split activities**: Break long activities into shorter segments
4. **Add resources**: Deploy additional resources where feasible
5. **Extend schedule**: Accept longer duration to fit resource constraints

### Trade-off Recognition
Resource leveling often involves trade-offs:
- **Cost vs. Schedule**: Adding resources may increase cost
- **Quality vs. Schedule**: Compressed schedules may affect quality
- **Risk vs. Schedule**: Reducing float increases schedule risk

## Gantt Chart Template (Detailed)

```markdown
# Project Schedule Gantt Chart

**Project:** [Project Name]
**Prepared By:** [PM Name]
**Date:** [Date]
**Version:** [Version]

## Timeline Legend
- ████ = Scheduled Duration
- ░░░░ = Remaining Duration
- ▓▓▓▓ = Actual Progress
- ◇ = Milestone

## Schedule Table

| # | WBS | Activity | Owner | Start | End | Dur. | Float | % Done | Predecessors |
|---|-----|----------|-------|-------|-----|------|-------|--------|--------------|
| 1 | 1.1 | Activity | Name | Date | Date | X d | X d | XX% | - |
| 2 | 1.2 | Activity | Name | Date | Date | X d | X d | XX% | 1 |
| ◇ | - | Requirements Approved | PM | - | Date | - | - | - | 2 |

## Critical Path
[Critical path activities listed]

## Schedule Variance Threshold
Variance > [X] days requires escalation

## Change Log
| Date | Change | Approved By |
|------|--------|-------------|
| YYYY-MM-DD | Description | Name |
```

## Schedule Development Best Practices

1. **Use consistent duration units** (days or weeks) throughout
2. **Define working calendar** (exclude weekends, holidays)
3. **Review with team** before finalizing durations
4. **Document assumptions** for all estimates
5. **Identify constraints** (hard deadlines, resource limits)
6. **Include management reserve** for unknown risks
7. **Validate dependencies** are realistic
8. **Test schedule logic** by walking through scenarios

## Automation Tier Summary

**Tier 2 — Accelerate**

This skill accelerates schedule development by:
- Providing Gantt chart templates in markdown format
- Presenting milestone list templates
- Offering schedule baseline documentation format
- Providing critical path identification guidance
- Enabling rapid creation of consistent schedule documentation

The skill does NOT automatically calculate complex schedules, resolve resource conflicts, or generate optimized timelines — it provides the framework and templates that Thomas populates with project-specific data.

## Known Limitations

1. **Duration estimation accuracy**: Schedule quality depends entirely on duration estimates
2. **Resource availability**: Schedules assume resources are available when needed
3. **External dependencies**: Dates dependent on external parties may be uncertain
4. **Dynamic changes**: Real projects experience changes requiring schedule updates
5. **Complexity explosion**: Large projects generate very complex schedules
6. **Tool dependency**: Complex schedules often require scheduling software
7. **Resource leveling complexity**: Automated resource leveling may produce counterintuitive results
8. **Stakeholder expectations**: Milestone dates may be set before realistic scheduling is complete
