---
name: pm-250-project-closure-report
description: Produce the formal project closure report — summarizing objectives met, budget, schedule, quality, and handover status.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, closure, project-report]
    trigger: [project closure report, project closure, closure report, project completion, handover, close out]
    trigger_context: "Thomas producing the formal project closure report — documenting what was delivered, what wasn't, and handover status"
---
# PM-250: Project Closure Report

## What
Document the formal closure of the project — objectives achieved, deliverables accepted, budget consumed, lessons learned, and handover to operations.

## Pre-Closure Checklist
- [ ] All deliverables accepted by sponsor/business owner
- [ ] All contracts closed (pm-180-vendor-management)
- [ ] All issues and risks closed
- [ ] All team members demobilized (pm-260-team-demobilization)
- [ ] Financial accounts closed
- [ ] Documentation archived (pm-270-project-archiving)

## Project Summary Section
| Field | Value |
|-------|-------|
| Project Name | |
| Project Code | |
| Sponsor | |
| Project Manager | |
| Start Date | |
| End Date | |
| Final Budget | |
| Final Duration | |

## Objectives Assessment
| Objective | Target | Achieved? | Notes |
|-----------|--------|-----------|-------|
| Deliver X by date Y | X delivered | ✓/✗ | |
| Stay within €200K budget | ≤ €200K | ✓/✗ | |
| Achieve 99.5% uptime | 99.5% measured | ✓/✗ | |
| ... | ... | ... | ... |

## Scope Summary
| Item | Committed | Delivered | Variance |
|------|-----------|-----------|----------|
| Features | 25 | 23 | -2 (descoped) |
| WBS elements | 48 | 46 | -2 |
| ... | ... | ... | ... |

## Budget Finalization
| Category | Budget (€) | Actual (€) | Variance |
|----------|-----------|------------|----------|
| Labor | 100,000 | 105,000 | +5,000 |
| Materials | 40,000 | 38,500 | -1,500 |
| Contractors | 50,000 | 52,000 | +2,000 |
| Contingency | 10,000 | 0 | -10,000 |
| **TOTAL** | **200,000** | **195,500** | **-4,500** |

## Schedule Summary
| Phase | Planned End | Actual End | Variance |
|-------|-------------|------------|----------|
| Initiation | 2024-01-15 | 2024-01-14 | -1 day |
| Planning | 2024-02-15 | 2024-02-18 | +3 days |
| Execution | 2024-06-30 | 2024-07-10 | +10 days |
| Closure | 2024-07-31 | | |

## Deliverable Acceptance Log
| Deliverable | Owner | Accepted Date | Sign-off |
|-------------|-------|---------------|----------|
| API Gateway | Dev Lead | 2024-07-01 | ✓ |
| User portal | Business Owner | 2024-07-05 | ✓ |
| Documentation | Tech Writer | 2024-07-08 | ✓ |
| ... | ... | ... | ... |

## Handover Status
| System/Component | Handover To | Handover Date | Status |
|------------------|-------------|---------------|--------|
| API Gateway | Operations | 2024-07-15 | Complete |
| User portal | Business | 2024-07-15 | Complete |
| Monitoring dashboards | Ops/SRE | 2024-07-15 | Pending |

## Key Decisions Made
| Decision | Date | Rationale | Outcome |
|----------|------|-----------|---------|
| Descope payment module | 2024-05-01 | Budget risk | Reduced scope, stayed in budget |
| Switch cloud provider | 2024-03-15 | SLA terms | Better pricing, on time |
| ... | ... | ... | ... |

## Data Sources
- Project charter (original objectives)
- Final accounts (pm-110-cost-estimation update)
- Deliverable log (sign-off records)
- Lessons learned (pm-280-lessons-learned)
- Handover documentation

## Automation Tier
**Tier 2 — Accelerate**: Hermes drafts closure report from project data files, fills in actuals from financial system, and formats the document. Human reviews and sponsor signs off.

## Limitations
- Cannot close until all deliverables accepted — report is dependent, not independent
- Sponsor signature required — cannot be auto-approved
- Post-project review should happen 30-60 days after closure for full perspective