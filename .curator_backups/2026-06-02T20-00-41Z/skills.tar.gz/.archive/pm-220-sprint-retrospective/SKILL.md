---
name: pm-220-sprint-retrospective
description: Facilitate the sprint retrospective to identify what went well, what didn't, and generate actionable improvement items for the next sprint.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, scrum, retrospective, continuous-improvement]
    trigger: [sprint retrospective, retro, sprint lessons, improvement, team retrospective]
    trigger_context: "Thomas facilitating the sprint retrospective — identifying what went well, what didn't, and generating actions"
---
# PM-220: Sprint Retrospective

## What
After sprint review, facilitate a team retrospective to reflect on the sprint — what worked, what didn't, and what the team will change going forward.

## Retrospective Formats

### Format 1: Start-Stop-Continue (30 min, 3 columns)
| Start | Stop | Continue |
|-------|------|----------|
| Things to start doing | Things to stop doing | Things to keep doing |

### Format 2: What Went Well / What Didn't / Action Items (standard)
| What went well | What didn't go well | Action items |
|----------------|---------------------|--------------|
| Daily standup kept short | Sprint commitment too aggressive | Reduce commitment by 10% |
| ... | ... | ... |

### Format 3: 4Ls (20 min, fast)
- **Liked**: What the team enjoyed
- **Learned**: New knowledge gained
- **Lacked**: What was missing
- **Longed for**: What the team wishes they had

## Team Norms for Retrospectives
- Safe space — no blame, focus on process
- Everyone speaks — use round-robin if needed
- Actions are concrete — not vague intentions
- Keep it short — 30-60 minutes max
- Track improvement items over multiple sprints

## Step-by-Step SOP
1. **Set stage**: Remind team of sprint goal and results (velocity, stories completed)
2. **Gather data**: Each team member writes observations on sticky notes or shared doc
3. **Generate insights**: Group similar observations, identify themes
4. **Decide actions**: Team votes on top 2-3 improvements to implement next sprint
5. **Assign owners**: Each action item gets an owner and due date
6. **Follow up**: PM tracks actions in issue log (pm-170-issues-and-actions), reviews in next retro

## Action Item Template
| Action | Category | Owner | Due | Status |
|--------|----------|-------|-----|--------|
| Reduce sprint commitment by 10% | Process | Scrum Master | Next sprint | Open |
| Add 30-min architecture review | Process | Tech Lead | Next sprint | Open |
| ... | ... | ... | ... | ... |

## Retro Trends (Over Multiple Sprints)
| Improvement Area | Sprint # | Status | Trend |
|-----------------|----------|--------|-------|
| Sprint commitment accuracy | #25-27 | Improving | +15% accuracy |
| Blocker resolution time | #24-27 | Stable | ~4h average |
| Code review turnaround | #26-27 | Declining | Up from 2h to 6h |
| ... | ... | ... | ... |

## Data Sources
- Sprint results (pm-210-sprint-review, pm-190-sprint-planning)
- Previous retro action items
- Team feedback

## Automation Tier
**Tier 2 — Accelerate**: Hermes can prepare retro workspace (shared doc with prompts), aggregate team inputs, and draft action items from patterns across multiple retros.

## Limitations
- Facilitator must be neutral — not the line manager
- Actions must be followed through — a retro without follow-up is theater
- Psychological safety is required — without it, team won't share honest feedback