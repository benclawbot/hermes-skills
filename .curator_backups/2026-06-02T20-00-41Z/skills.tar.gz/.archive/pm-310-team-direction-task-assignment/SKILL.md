---
name: pm-310-team-direction-task-assignment
description: Assign project tasks to team members, confirm role clarity, track workload balance, and direct day-to-day work assignments.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, task-assignment, team, resource-management]
    trigger: [team direction, task assignment, assign work, workload, resource allocation, who is doing what]
    trigger_context: "Thomas assigning tasks to team members — balancing workload, confirming role clarity, directing day-to-day work"
---
# PM-310: Team Direction & Task Assignment

## What
Direct the day-to-day allocation of work across team members — assigning tasks, balancing workloads, confirming role clarity, and adjusting as priorities shift.

## Task Assignment Principles
- Assign to the person with the right skill, not the person who is free
- One task owner per task — shared ownership means nobody owns it
- Task must have a clear done criteria before assignment
- Confirm availability before assigning — don't assume capacity

## Workload Balance Check
| Team Member | Assigned Hours (this week) | Capacity | Utilization |
|-------------|---------------------------|----------|-------------|
| Jean-Didier | 32h | 40h | 80% |
| Nathanael | 44h | 40h | 110% — OVER |
| Ludovic | 28h | 40h | 70% |
| ... | ... | ... | ... |

## Step-by-Step SOP
1. **Review sprint backlog**: Know what needs to be done (pm-190-sprint-planning output)
2. **Check team availability**: Who is in, who is out, who has capacity
3. **Assign tasks**: Match tasks to people by skill and availability
4. **Confirm with individual**: Communicate what, why, by when — get acknowledgment
5. **Log assignments**: Update task board with owner, due date, status
6. **Monitor workload**: Track utilization per person — don't overload
7. **Re-balance daily**: Adjust assignments as priorities change, tasks complete, or people report blockers

## Task Assignment Communication Template
> "[Name], I'm assigning you to [task]. The deliverable is [description]. The done criteria are [list]. By [date]. Any concerns or blockers?"

## Data Sources
- Sprint backlog (pm-190-sprint-planning, pm-200-sprint-execution)
- Team availability (from pm-sprint-helper team roster)
- Task board (Jira, Trello, etc.)

## Automation Tier
**Tier 3 — Augment**: Hermes can flag overloaded team members, suggest task assignments based on skill mapping, and generate workload balance reports.

## Limitations
- Task assignment requires human judgment about skill levels and motivation
- Team dynamics (who works well with whom) are not captured in data
- Cannot force a person to accept a task — requires human conversation