---
name: pm-130-risk-response-planning
description: Develop response strategies for top-ranked project risks, assign owners and trigger conditions, and build contingency plans.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, risk-management, contingency]
    trigger: [risk response, risk mitigation, risk response strategy, risk fallback plan, risk contingency, mitigation plan]
    trigger_context: "Thomas developing mitigation and contingency plans for top-ranked risks — defining response strategies and trigger points"
---
# PM-130: Risk Response Planning

## What
For each high/medium risk in the risk register, develop a response strategy, define specific actions, assign owners, and set trigger conditions for activation.

## Threat Response Strategies (Negative Risks)
| Strategy | Description | When to use |
|----------|-------------|-------------|
| **Avoid** | Eliminate the cause entirely | Risk is severe and can be eliminated |
| **Transfer** | Shift impact to third party (insurance, warranty, contract) | External party can better manage it |
| **Mitigate** | Reduce likelihood or impact | Cannot avoid or transfer |
| **Accept** | Acknowledge and prepare fallback | Risk is low, mitigation cost > benefit |

## Opportunity Response Strategies (Positive Risks)
| Strategy | Description | When to use |
|----------|-------------|-------------|
| **Exploit** | Ensure opportunity definitely happens | High value, controllable |
| **Share** | Partner with third party to share benefits | Cannot exploit alone |
| **Enhance** | Increase likelihood or impact | Worth investing to amplify |
| **Accept** | Be ready to take advantage if it occurs | Low priority opportunity |

## Contingency Reserve
Calculate contingency reserve for each HIGH risk:
> Contingency (€) = Risk Score / 25 × Available Reserve

Alternatively, use expected monetary value:
> EMV = Likelihood × Impact Cost

Reserve is drawn from the project contingency budget (pm-110-cost-estimation).

## Step-by-Step SOP
1. Review risk register — filter to High (15-25) and Medium (6-14) risks
2. For each risk, select appropriate strategy (Avoid/Transfer/Mitigate/Accept)
3. For Mitigate: design specific actions with measurable success criteria
4. Assign owner (must be someone with authority to execute)
5. Define trigger: specific condition that activates the response (e.g., "if velocity drops below 20 points for 2 consecutive sprints")
6. Calculate contingency cost and time
7. If primary response might fail, create a fallback plan
8. Document in risk response plan table
9. Integrate trigger conditions into project monitoring (status reports, standups)

## Fallback Plans
A fallback is activated if the primary response fails or trigger conditions escalate.
- Define secondary trigger (escalation signal)
- Pre-authorize fallback actions so PM doesn't need to wait for approval
- Communicate fallback availability to team and sponsor

## Output: Risk Response Plan Table
| Risk ID | Risk Description | Strategy | Primary Actions | Owner | Trigger Conditions | Contingency Cost | Fallback Plan |
|---------|------------------|----------|-----------------|-------|---------------------|------------------|---------------|
| R-001 | Key developer leaves | Mitigate | Knowledge transfer sessions, documentation, backup vendor | Thomas | Notice given | €15,000 | Engage backup vendor for 3 months |
| R-002 | API deprecation | Avoid | Abstraction layer, migration to alternative API | Dev Lead | API changelog published | €8,000 | Manual data sync as interim solution |
| ... | ... | ... | ... | ... | ... | ... | ... |

## Summary: Risk Response Status
| Status | Count |
|--------|-------|
| Responses defined | X |
| Contingency funded | X |
| Triggers documented | X |
| Fallbacks defined | X |

## Data Sources
- Risk register (pm-120-risk-identification)
- Budget baseline (pm-110-cost-estimation)
- Team input on mitigation actions

## Automation Tier
**Tier 2 — Accelerate**: Hermes can draft response strategies based on risk type, suggest standard mitigation actions, and calculate contingency reserves. Human reviews and selects appropriate response.

## Limitations
- Response strategies depend on available budget and authority
- Some risks (external, market) have limited mitigation options
- Triggers must be specific and measurable — vague triggers are useless