---
name: pm-110-cost-estimation
description: Estimate project costs (labor, materials, contingency) and build the time-phased budget baseline.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, estimation, budgeting]
    trigger: [cost estimation, budget baseline, cost breakdown, labor rates, estimation]
    trigger_context: "Thomas estimating project costs and building the budget baseline"
---
# PM-110: Cost Estimation & Budget Baseline

## What
Estimate all project costs and produce a time-phased budget baseline that can be tracked against actual spend.

## Step-by-Step SOP
1. Identify all cost elements from WBS (labor, materials, equipment, contractors, travel, contingency)
2. Estimate each element using appropriate technique:
   - **Bottom-up**: WBS-based — estimate each work package, roll up to total
   - **Parametric**: use historical ratios (e.g., $/function point, $/line of code)
   - **PERT three-point**: (O + 4M + P) / 6
3. Apply contingency reserve (10-20% of base estimate) for unidentified risks
4. Sum all elements into total project cost
5. Time-phase the budget (monthly or quarterly distribution)
6. Validate against available budget / funding envelope — iterate if gap exists
7. Baseline the budget and get sponsor approval

## Estimation Techniques
| Technique | When to use |
|-----------|-------------|
| Bottom-up (WBS-based) | Detailed scope known, well-defined work packages |
| Parametric | Historical data available, linear/repeatable scope |
| Analogous (top-down) | Early phase, limited info, rough order of magnitude |
| PERT three-point | Uncertainty in estimates, want probabilistic range |

## Cost Categories
- **Labor**: hours × loaded rate (base salary + overhead + taxes)
- **Materials**: hardware, software licenses, consumables
- **Equipment**: hardware/tools rented or purchased
- **Contractors**: vendor invoices, consulting fees
- **Travel**: transportation, accommodation, per diem
- **Contingency**: % of base cost, for unidentified risks

## Output: Cost Breakdown Table
| ID | Cost Element | Category | Estimate (€) | Contingency (€) | Total (€) |
|----|--------------|----------|-------------|-----------------|-----------|
| 1  | Requirements gathering | Labor | X | X | X |
| 2  | Development | Labor + Contractors | X | X | X |
| ... | ... | ... | ... | ... | ... |
| **TOTAL** | | | | | **X** |

## Output: Time-Phased Budget
| Period | Planned Spend (€) | Cumulative (€) | % of Total |
|--------|------------------|----------------|------------|
| Month 1 | X | X | X% |
| Month 2 | X | X | X% |
| ... | ... | ... | ... |

## Data Sources
- WBS and activity list (pm-070-wbs-development)
- Resource rates (loaded labor rates per role)
- Historical project cost data
- Approved funding envelope

## Automation Tier
**Tier 2 — Accelerate**: Hermes can draft the cost breakdown table from WBS input, apply standard contingency rates, and generate the time-phased distribution. Human reviews and adjusts rates.

## Limitations
- Estimates are only as good as scope definition and historical data
- Currency fluctuations not modeled
- Resource availability conflicts not reflected (use pm-090-schedule-development for that)