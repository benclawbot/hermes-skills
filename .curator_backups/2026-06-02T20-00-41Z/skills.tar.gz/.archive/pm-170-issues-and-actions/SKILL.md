---
name: pm-170-issues-and-actions
description: Log, track, and close project issues and action items through to completion with clear ownership and deadlines.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, issue-tracking, action-items]
    trigger: [issue log, action items, action tracking, issue management, action register]
    trigger_context: "Thomas tracking project issues and action items — ensuring they are owned, dated, and closed"
---
# PM-170: Issue & Action Item Management

## What
Log all project issues and action items, assign owners and due dates, track progress, and close items when resolved.

## Issue vs Action Item
| Type | Description | Example |
|------|-------------|---------|
| **Issue** | A problem blocking progress that needs resolution | "API integration failing in test environment" |
| **Action Item** | A task assigned to someone with a deadline | "Dev Lead to investigate API timeout by Friday" |

## Issue Priority Levels
| Priority | Description | Response Time |
|----------|-------------|---------------|
| **Critical** | Blocks all progress on a workstream | Immediate (within 1h) |
| **High** | Blocks progress on key deliverable | Within 4h |
| **Medium** | Delays work but workaround exists | Within 24h |
| **Low** | Minor impact, can be scheduled | Within 1 week |

## Issue Status Lifecycle
`Open → In Progress → Resolved → Closed`

## Step-by-Step SOP
1. **Log issue/action**: Assign ID, title, description, owner, due date, priority
2. **Categorize**: Issue vs Action Item, functional area affected
3. **Assign owner**: Person responsible for resolving (not necessarily the PM)
4. **Set due date**: Realistic, considering priority and dependencies
5. **Track**: Review in daily standup, weekly status report
6. **Escalate**: If owner doesn't respond or deadline missed — escalate
7. **Close**: Once resolved, move to Closed, verify with requestor
8. **Report**: Weekly issue summary in status report — open count, age, trend

## Output: Issue & Action Log
| ID | Title | Type | Owner | Priority | Status | Created | Due | Resolution | Closed |
|----|-------|------|-------|----------|--------|---------|-----|------------|--------|
| ISS-001 | API timeout in test env | Issue | Dev Lead | High | Resolved | 2024-03-01 | 2024-03-03 | Increased timeout config | 2024-03-02 |
| ACT-042 | Update WBS dictionary | Action | PM | Medium | Open | 2024-03-05 | 2024-03-08 | | |
| ... | ... | ... | ... | ... | ... | ... | ... | ... | ... |

## Aging Report (Weekly Review)
| Age Bracket | Count | Examples |
|-------------|-------|----------|
| 0-3 days | X | |
| 4-7 days | X | |
| 8-14 days | X | |
| > 14 days | X | Escalate or close |

## Critical Issues Escalation
For Critical issues:
1. Notify sponsor immediately
2. Convene emergency call within 2h
3. Identify workaround within 4h
4. Implement fix within 24-48h
5. Document in issue log with root cause

## Data Sources
- Team inputs (standups, emails, meetings)
- Risk register (issues that have materialized)
- Change requests (approved CRs can generate issues)

## Automation Tier
**Tier 1 — Eliminate**: Hermes can auto-log issues from standup transcripts, draft resolution summaries, send reminders for approaching due dates, and generate weekly issue reports.

## Limitations
- Log must be current — stale issues undermine trust in the tool
- Owner must be reachable and accountable
- Issues without clear resolution criteria stay open too long — define done clearly