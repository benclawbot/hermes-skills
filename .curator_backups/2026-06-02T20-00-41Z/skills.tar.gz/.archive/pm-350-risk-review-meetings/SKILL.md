---
name: pm-350-risk-review-meetings
description: Run periodic risk review meetings to reassess existing risks, score changes, activate contingency plans, and identify new risks.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, risk-management, meetings]
    trigger: [risk review, risk review meeting, risk reassessment, risk status, risk monitoring, risk meeting]
    trigger_context: "Thomas running the periodic risk review — reassessing scores, checking trigger conditions, activating contingency plans"
---
# PM-350: Risk Review Meetings

## What
Run structured risk review meetings (typically monthly or at stage gates) to reassess existing risks, identify new risks, check contingency trigger conditions, and ensure mitigation plans are on track.

## Meeting Cadence
| Project Phase | Frequency | Duration |
|--------------|-----------|----------|
| Initiation | Weekly | 30 min |
| Planning | Bi-weekly | 45 min |
| Execution | Monthly | 60 min |
| Closure | At gate reviews | 30 min |

## Risk Review Agenda (60 min)
| Time | Topic | Owner |
|------|-------|-------|
| 0-10min | Risk register review — top 10 risks | PM |
| 10-25min | Mitigation status updates (owners) | Risk owners |
| 25-40min | Trigger check — any responses activated? | All |
| 40-50min | New risks identified | All |
| 50-60min | Action items and next review date | PM |

## Risk Status Movement
Track how risks have changed since last review:
| Risk ID | Previous Score | Current Score | Movement | Reason |
|---------|---------------|---------------|----------|--------|
| R-001 | 12 (Med) | 15 (High) | ↑ | Vendor delivery delayed |
| R-002 | 8 (Med) | 6 (Med) | ↓ | Backup resource confirmed |
| ... | ... | ... | ... | ... |

## Contingency Trigger Check
For each HIGH risk with an active contingency plan:
> **Trigger condition met?** (Yes/No/Partial)

| Risk ID | Trigger Condition | Status | Contingency Activated? |
|---------|------------------|--------|----------------------|
| R-001 | API vendor delays > 5 days | ✗ Not triggered | No action needed |
| R-015 | Key developer leaves | ✗ No departure | N/A |
| ... | ... | ... | ... |

## Step-by-Step SOP
1. **Prepare**: PM pulls risk register, highlights top 10 risks, notifies owners to update status
2. **Review top risks**: Score change? Mitigation working? Timeline affected?
3. **Check triggers**: Any contingency trigger conditions met — activate if needed
4. **New risks**: Any new risks since last review — add to register with scoring
5. **Closed risks**: Any risks that have passed — close them (no longer applicable)
6. **Decide actions**: New or changed mitigation actions, assign owners
7. **Document**: Update risk register, log meeting outcomes
8. **Escalate**: Any risk now at High score without a plan — escalate to sponsor

## Output: Risk Review Meeting Notes
### Date: [DATE] | Project: [PROJECT]
**Attendees**: PM, Tech Lead, Sponsor (if High risks)

### Risk Score Changes Since Last Review
| Risk ID | Description | Prev | Curr | Movement | Action |
|---------|-------------|------|------|----------|--------|
| R-001 | Vendor delivery | 10 | 15 | ↑ +5 | Escalate to sponsor |
| R-008 | Budget overrun | 6 | 6 | → | Monitor |

### Contingency Status
| Risk ID | Trigger | Status | Action |
|---------|---------|--------|--------|
| R-001 | Delivery > 5 days late | NOT MET | Prepare if changes |

### New Risks Added
| Risk ID | Description | Score | Owner | Mitigation |
|---------|-------------|-------|-------|------------|

### Action Items
| Action | Owner | Due |
|--------|-------|-----|

## Data Sources
- Risk register (pm-120-risk-identification)
- Risk response plans (pm-130-risk-response-planning)
- Meeting with risk owners

## Automation Tier
**Tier 2 — Accelerate**: Hermes can prepare risk review package (top 10 risks, score changes, trigger status), draft meeting agenda, and update risk register after meeting.

## Limitations
- Risk owners must be present or available — PM cannot update risk status without owner input
- Contingency activation requires budget authority — not all triggers can be pre-authorized
- Subjective scoring can drift — calibrate periodically