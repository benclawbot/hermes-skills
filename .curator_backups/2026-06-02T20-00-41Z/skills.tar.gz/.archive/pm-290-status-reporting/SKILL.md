---
name: pm-290-status-reporting
description: Produce the weekly project status report — progress against plan, budget, risks, issues, and next actions for stakeholders.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, reporting, status]
    trigger: [status report, weekly status, project status, status update, executive summary, steering report]
    trigger_context: "Thomas producing the weekly status report for sponsor and steering committee"
---
# PM-290: Status Reporting

## What
Produce the weekly project status report — consolidating progress, budget, risks, issues, and decisions into a clear format for sponsor and steering committee.

## Status Report Frequency
| Audience | Format | Frequency |
|----------|--------|-----------|
| Sponsor | 1-page brief + metrics | Weekly |
| Steering Committee | 5-10 slide deck + metrics | Monthly |
| Team | Task board + standup | Daily |
| Stakeholders | Wiki/Dashboard | Weekly |

## Status Report Sections
1. **Executive Summary** (3 sentences: what's working, what's at risk, what's decision needed)
2. **Overall Status**: 🟢 Green / 🟡 Yellow / 🔴 Red
3. **Progress** (% complete, milestones hit/missed, sprint velocity)
4. **Budget** (spent vs. planned, forecast, variance)
5. **Risks** (top 3, any new high risks)
6. **Issues** (open issues count, critical issues)
7. **Decisions Needed** (from stakeholder)
8. **Next Period Actions** (top 3-5)

## Step-by-Step SOP
1. **Gather data**: Pull progress from task board, budget from financial system, risk register, issue log
2. **Calculate status**: % complete vs. plan, spend vs. budget, velocity vs. baseline
3. **Assess RAG**: Green (on track), Yellow (minor issues), Red (major issues or blocker)
4. **Write executive summary**: 3 sentences — wins, risks, decisions needed
5. **Fill sections**: Progress, budget, risks, issues, decisions, next actions
6. **Review**: PM reviews draft, checks accuracy
7. **Send**: Email to sponsor, upload to project wiki
8. **File**: Save to project records for archive

## Output: Weekly Status Report Template

### Overall Status: 🟡 YELLOW
**Reason**: Integration testing delayed by vendor API issues. Mitigation in place.

### Progress
| Milestone | Status | Date |
|-----------|--------|------|
| Design complete | ✓ | 2024-03-01 |
| Development 50% | ✓ | 2024-03-15 |
| Integration testing | 🔴 At risk | 2024-03-22 |
| UAT start | 🟡 On track | 2024-04-01 |

### Budget
| | Plan | Actual | Forecast | Variance |
|--|------|--------|----------|----------|
| Spend | €100,000 | €85,000 | €198,000 | -2% |
| % Complete | 55% | 52% | | -3% |

### Top 3 Risks
| Risk | Score | Trend | Mitigation |
|------|-------|-------|------------|
| Vendor API instability | 15 (High) | ↑ | Fallback to manual testing |
| Key developer availability | 12 (Med) | → | Knowledge transfer underway |
| Scope creep pressure | 8 (Med) | ↓ | Change control active |

### Critical Issues
| Issue | Age | Owner | Status |
|-------|-----|-------|--------|
| API timeout errors | 3 days | Dev Lead | Resolved 2024-03-18 |
| Test environment down | 1 day | Ops | In progress |

### Decisions Needed This Week
1. Approve descoping 2 low-priority features to recover schedule
2. Authorize additional €5K for vendor testing

### Next Period Actions
| Action | Owner | Due |
|--------|-------|-----|
| Complete API integration testing | Dev Team | 2024-03-22 |
| Submit change request for descope | PM | 2024-03-19 |

## Automation Tier
**Tier 1 — Eliminate**: Hermes can draft complete status report from project data files (sprint progress, budget, risk register, issue log). Human reviews and sends.

## Limitations
- Data must be current — report is only as good as the underlying project data
- Tone should be honest — don't paper over real problems with green status