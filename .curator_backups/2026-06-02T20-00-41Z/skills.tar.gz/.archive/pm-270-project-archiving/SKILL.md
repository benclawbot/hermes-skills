---
name: pm-270-project-archiving
description: Archive all project documentation, artifacts, and records into the organizational project archive with proper indexing and retention.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, closure, documentation, archive]
    trigger: [project archiving, document archive, project records, close out, documentation]
    trigger_context: "Thomas archiving all project documentation at project close — organizing files, indexing, and handing to records management"
---
# PM-270: Project Archiving

## What
Organize, index, and transfer all project documentation and artifacts to the organizational project archive — ensuring retrievability for future audits, reference, or organizational learning.

## What to Archive
| Category | Examples | Retention |
|----------|----------|-----------|
| **Planning documents** | Project charter, business case, WBS, schedule, budget | 7 years |
| **Requirements** | Requirements register, user stories, acceptance criteria | 7 years |
| **Contracts** | Vendor contracts, SOW, amendments, invoices | 7 years |
| **Meeting records** | Minutes, steering committee, decisions | 5 years |
| **Status reports** | Weekly/monthly status reports | 5 years |
| **Deliverables** | Final deliverables, designs, code, manuals | 3 years min |
| **Closure documents** | Closure report, lessons learned, sign-offs | 7 years |
| **Risk/Issue logs** | Final risk register, issue log, change log | 5 years |

## Archive Structure
```
/PROJECT-ARCHIVE/
├── [Project-Code]/
│   ├── 00-CHARTER/           (project charter, authorization)
│   ├── 01-PLANNING/          (business case, WBS, schedule, budget)
│   ├── 02-REQUIREMENTS/      (requirements docs, user stories)
│   ├── 03-CONTRACTS/         (vendor contracts, SOWs, invoices)
│   ├── 04-MEETINGS/          (minutes, decisions, steering notes)
│   ├── 05-STATUS/            (weekly reports, presentations)
│   ├── 06-DELIVERABLES/      (final deliverables, designs)
│   ├── 07-QUALITY/           (test plans, QA reports, sign-offs)
│   ├── 08-RISKS/             (risk register, issue log, change log)
│   └── 09-CLOSURE/           (closure report, lessons learned, sign-offs)
```

## Step-by-Step SOP
1. **Inventory**: List all project documents across all categories
2. **Sort**: Separate into keep / destroy (confidential or temporary documents)
3. **Organize**: Apply archive structure above — folders by phase
4. **Index**: Create master index file (filename, description, date, author, retention period)
5. **Convert formats**: Ensure documents are in long-term readable formats (PDF > DOC, XLSX > CSV)
6. **Transfer**: Upload to organizational document management system or shared archive
7. **Metadata**: Tag with project code, dates, sensitivity level
8. **Notify**: Inform stakeholders of archive location and access procedure
9. **Destroy sensitive**: Securely delete/shred any confidential hard copies

## Archive Index Template
| File | Description | Date | Author | Retention | Location |
|------|-------------|------|--------|-----------|----------|
| Project_Charter_v2.pdf | Final approved charter | 2024-01-15 | Thomas | 7 years | archive/00-CHARTER/ |
| WBS_v1.xlsx | Initial WBS baseline | 2024-01-22 | Thomas | 7 years | archive/01-PLANNING/ |
| ... | ... | ... | ... | ... | ... |

## Data Sources
- Project folder (all working documents)
- SharePoint/document management system
- Financial records (invoices)
- Email archives (if relevant)

## Automation Tier
**Tier 1 — Eliminate**: Hermes can generate the archive folder structure, draft the master index from project folder scan, identify files to convert, and prepare destruction list for sensitive items.

## Limitations
- Actual file upload/movement requires human or API access to document management system
- Retention policies vary by organization and jurisdiction — consult records management
- Confidential documents may require special handling (legal, HR)