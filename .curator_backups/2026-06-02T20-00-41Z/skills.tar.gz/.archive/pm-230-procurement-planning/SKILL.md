---
name: pm-230-procurement-planning
description: Define the procurement strategy for the project — make vs. buy decisions, vendor selection criteria, contract type, and procurement schedule.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, procurement, vendor, make-or-buy]
    trigger: [procurement planning, make or buy, vendor selection, RFP, contract type, procurement]
    trigger_context: "Thomas deciding what to buy vs. build internally, selecting vendors, and defining the procurement approach"
---
# PM-230: Procurement Planning

## What
Decide which project components will be procured externally, select the right vendors, define contract structures, and build the procurement schedule aligned with project milestones.

## Make vs. Buy Decision Matrix
| Factor | Make (Internal) | Buy (External) |
|--------|----------------|---------------|
| Core competency | Strategic advantage | Non-differentiating |
| Availability | Skills available internally | Skills gap |
| Volume | Low-medium | High |
| Time to market | Can be fast | Vendor lead times |
| Cost | Lower for small volume | Lower for large volume |
| Risk | More control | Depends on vendor capability |
| IP control | Full ownership | Shared or vendor-owned |

## Contract Type Selection
| Contract Type | Risk to Buyer | Best for |
|--------------|---------------|----------|
| **Firm Fixed Price (FFP)** | Low | Well-defined scope, low uncertainty |
| **Time & Materials (T&M)** | Medium | Variable scope, consulting, agile |
| **Cost Reimbursable** | High | Research, high uncertainty |
| **混合 (T&M + Milestones)** | Medium | Software development with defined phases |

## Vendor Evaluation Criteria
| Criteria | Weight | Notes |
|----------|--------|-------|
| Technical capability | 30% | Skills, experience, methodology |
| Cost | 25% | Total cost of ownership, not just price |
| Delivery timeline | 20% | Can meet required dates? |
| References | 15% | Similar projects, client satisfaction |
| Financial stability | 10% | Vendor risk assessment |

## RFP Contents
1. Project overview and objectives
2. Scope of work (detailed)
3. Deliverables and acceptance criteria
4. Timeline and milestones
5. Evaluation criteria and weights
6. Contract type and payment terms
7. Submission requirements and deadline

## Step-by-Step SOP
1. **Identify procurement needs**: List all project components that require external purchase
2. **Make vs. buy analysis**: For each component, assess build vs. buy decision using matrix above
3. **Market research**: Identify potential vendors — industry contacts, analyst reports, references
4. **Define evaluation criteria**: Weight technical, cost, timeline, references, financial stability
5. **Issue RFP**: To minimum 3 qualified vendors
6. **Evaluate responses**: Score against criteria, shortlist top 2-3
7. **Vendor interviews**: Deep dive on capability, methodology, team, cultural fit
8. **Negotiate and select**: Best value, not cheapest — negotiate terms and contract
9. **Document**: Contract, SOW, payment schedule, SLAs, acceptance criteria

## Output: Procurement Plan
| Component | Decision | Vendor | Contract Type | Value | Start Date | Delivery |
|-----------|----------|--------|---------------|-------|------------|----------|
| Cloud infrastructure | Buy | AWS | T&M | €45,000 | 2024-04-01 | 2024-06-30 |
| Security audit | Buy | SecuriCorp | Fixed price | €18,000 | 2024-05-01 | 2024-06-15 |
| Training | Make | Internal | N/A | €0 | 2024-07-01 | 2024-07-31 |
| ... | ... | ... | ... | ... | ... | ... |

## Output: Vendor Shortlist
| Vendor | Score | Strengths | Weaknesses | Decision |
|--------|-------|-----------|------------|----------|
| AWS | 8.5/10 | Capability, SLA, pricing | Complex billing | Shortlisted |
| Azure | 7.2/10 | Existing relationship | Less flexible | Backup |
| GCP | 6.8/10 | Technology | Support model | Not selected |
| ... | ... | ... | ... | ... |

## Data Sources
- WBS (pm-070-wbs-development)
- Project schedule (pm-090-schedule-development)
- Budget baseline (pm-110-cost-estimation)
- Organizational procurement policies

## Automation Tier
**Tier 3 — Augment**: Hermes can draft RFP templates, score vendor responses against criteria, and generate vendor comparison tables. Human makes final selection.

## Limitations
- Vendor selection requires human judgment and relationship
- Procurement timelines are external — vendors set their own schedules
- Contract negotiation requires legal and finance involvement