---
name: pm-340-burndown-chart-tracking
description: Track sprint and project burndown charts — monitor progress against plan, identify trends, and forecast completion based on current velocity.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, burndown, sprint-tracking, velocity]
    trigger: [burndown chart, sprint burndown, burndown tracking, project burndown, velocity tracking, remaining work]
    trigger_context: "Thomas tracking sprint burndown — monitoring remaining work, velocity, and forecasting completion"
---
# PM-340: Burndown Chart Tracking

## What
Track the sprint burndown (story points remaining per day) and project burndown (scope or budget consumed per time period) to monitor progress and forecast completion.

## Sprint Burndown Chart
X-axis: Sprint days (0 to length, e.g., day 0 to day 10)
Y-axis: Story points remaining

Two lines:
- **Ideal line**: Linear from commitment (e.g., 35 SP on day 0) to 0 on last day
- **Actual line**: Real remaining points per day — goal is to stay on or below ideal

## Burndown Interpretation
| Pattern | Meaning | Action |
|---------|---------|--------|
| Actual below ideal | Ahead of schedule | Can add stories (carefully) or improve quality |
| Actual on ideal | On track | Continue current approach |
| Actual above ideal (early) | Slow start — normal | Team ramping up |
| Actual above ideal (mid/end) | Behind schedule | Identify blockers, descope, or add capacity |
| Steep drop then flat | Someone did a lot of work then stopped | Check motivation, blockers |
| Sawtooth pattern | Unfinished stories carried over | Need to finish stories before new ones |

## Sprint Burndown Data Collection
Daily at same time (before standup):
- Count stories in Done column: sum story points
- Remaining = Total commitment - Done points
- Log: Day, Remaining Points, Notes

## Sprint Burndown Table
| Day | Committed | Done | Remaining | Ideal Remaining | Variance |
|-----|-----------|------|-----------|----------------|----------|
| 0 | 35 | 0 | 35 | 35 | 0 |
| 1 | 35 | 2 | 33 | 31.5 | +1.5 |
| 2 | 35 | 7 | 28 | 28 | 0 |
| 3 | 35 | 10 | 25 | 24.5 | +0.5 |
| 4 | 35 | 14 | 21 | 21 | 0 |
| 5 | 35 | 14 | 21 | 17.5 | +3.5 🔴 |

## Forecast Formulas
> **Days remaining** = Remaining SP / Avg Daily Velocity
> **Expected completion** = Today + Days remaining

> **Avg Daily Velocity** = (SP done in last 3 days) / 3

## Step-by-Step SOP
1. **Daily**: Collect remaining SP count at same time each day
2. **Log**: Record day, remaining, notes (blockers, completed items)
3. **Plot**: Update chart (ideal line vs. actual)
4. **Analyze**: Identify pattern — ahead/behind/trending
5. **Forecast**: Calculate expected completion date based on current velocity
6. **Act**: If behind by > threshold (e.g., 10% at mid-sprint), take action (descope, add capacity, escalate)
7. **Report**: Include burndown status in daily standup and weekly status report

## Sprint Burndown Action Thresholds
| Day | If remaining > ideal by | Action |
|-----|-------------------------|--------|
| 1-3 | > 15% | Monitor, check standup |
| 4-6 | > 10% | Identify blocker, consider descope |
| 7-8 | > 5% | Escalate to PM + PO — sprint goal at risk |
| 9-10 | > 0% | Emergency — accept that sprint may miss goal |

## Project-Level Burndown (Scope or Budget)
| Date | Total Scope (SP) | Done | Remaining | % Complete |
|------|-----------------|------|-----------|------------|
| 2024-03-01 | 200 | 0 | 200 | 0% |
| 2024-04-01 | 200 | 45 | 155 | 22.5% |
| 2024-05-01 | 200 | 95 | 105 | 47.5% |
| 2024-06-01 | 200 | 140 | 60 | 70% |

## Data Sources
- Daily task board status (story points by story)
- Sprint commitment (pm-190-sprint-planning)
- Historical velocity (pm-sprint-helper)

## Automation Tier
**Tier 1 — Eliminate**: Hermes can auto-calculate remaining SP from task board, plot burndown chart, identify trend patterns, and trigger alerts when thresholds are breached.

## Limitations
- Burndown only works for story-point tracked projects (scrum, not kanban)
- Forecasting assumes constant velocity — unexpected events break it
- Carried-over stories from previous sprints distort the picture — track separately