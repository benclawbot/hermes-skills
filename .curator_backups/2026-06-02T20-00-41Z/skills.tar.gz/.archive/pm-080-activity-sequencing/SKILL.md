---
name: pm-080-activity-sequencing
description: Identify and sequence all project activities, define dependencies, and build the project network diagram using CPM/PERT methods.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, schedule-management, network-diagram, critical-path]
    trigger: [activity sequencing, network diagram, CPM, PERT, dependency analysis, critical path, activity list, predecessor]
    trigger_context: "Thomas sequencing project activities and building the network diagram — identifying dependencies and the critical path"
---

# Activity Sequencing SOP

## What This SOP Does

This skill guides Thomas through the process of identifying all project activities, defining their relationships, and sequencing them into a project network diagram. It applies Critical Path Method (CPM) and PERT concepts to calculate early/late start times and identify float.

## Step-by-Step Activity Sequencing Process

### 1. List All Activities
- Review WBS work packages
- Identify specific tasks needed to complete each work package
- Break down work packages into individual activities
- Ensure activities are action-oriented and clearly defined
- Assign activity identifiers (e.g., A, B, C or 1, 2, 3)

### 2. Identify Dependencies
For each activity, determine relationships with other activities:

- **Predecessors**: Activities that must complete before this one starts
- **Successors**: Activities that cannot start until this one completes
- **External dependencies**: Activities outside the project that affect this work

Document dependencies in dependency table format.

### 3. Classify Dependency Types
Apply the appropriate dependency type to each relationship:

| Type | Code | Description | Example |
|------|------|-------------|---------|
| Finish-to-Start | FS | Successor cannot start until predecessor finishes | Test (S) cannot start until Code (P) finishes |
| Start-to-Start | SS | Successor cannot start until predecessor starts | Review starts when Development starts |
| Finish-to-Finish | FF | Successor cannot finish until predecessor finishes | Documentation finishes when Development finishes |
| Start-to-Finish | SF | Successor cannot finish until predecessor starts | Migration cannot finish until Training starts |

### 4. Sequence Activities
- Arrange activities in logical order based on dependencies
- Create a dependency list for each activity
- Handle circular dependency references (A before B, B before A is invalid)
- Document any discretionary dependencies with rationale
- Note any external constraints affecting sequence

### 5. Draw Network Diagram
- Create visual representation of activity sequence
- Use Activity-on-Node (AON) format with nodes representing activities
- Show arrows indicating dependencies and logic
- Position activities left-to-right reflecting sequence
- Include activity IDs, durations, and dependency lines

### 6. Calculate Early and Late Starts (CPM)
Apply forward and backward pass calculations:

**Forward Pass (Early Dates):**
- Early Start (ES) = Maximum EF of all predecessors + 1
- Early Finish (EF) = ES + Duration - 1

**Backward Pass (Late Dates):**
- Late Finish (LF) = Minimum LS of all successors - 1
- Late Start (LS) = LF - Duration + 1

### 7. Calculate Float
- **Total Float** = LS - ES (or LF - EF)
- **Free Float** = ES of successor - EF - 1
- Identify activities with zero float (critical path activities)
- Activities with float > 0 can be delayed without extending project duration

## Dependency Types Explained

### Finish-to-Start (FS)
The most common dependency type. Predecessor must finish before successor starts.
```
[Activity A] ──► [Activity B]
A must finish before B starts
```

### Start-to-Start (SS)
Activities can start simultaneously but successor waits for predecessor to start.
```
[Activity A]
    │
    ▼
[Activity B]──► (B starts when A starts)
```

### Finish-to-Finish (FF)
Successor cannot finish until predecessor finishes.
```
[Activity A] ──►
                   [Activity B] (B finishes when A finishes)
```

### Start-to-Finish (SF)
Rarely used. Successor cannot finish until predecessor starts.
```
[Activity A] ──► [Activity B] (B cannot finish until A starts)
```

## Lead and Lag Time

### Lead Time
A positive adjustment that allows successor to start before predecessor finishes.

- Example: FS +3 = Successor can start 3 days before predecessor finishes
- Use: When partial overlap is beneficial

### Lag Time
A waiting period between activities.

- Example: FS +5 = 5-day wait after predecessor finishes before successor starts
- Use: When natural delays exist (concrete curing, waiting for approvals)

### Example with Lead/Lag:
```
Design Complete ──► [FS +2 days] ──► Build can start 2 days before design fully done (overlap)
```

## Network Diagram Symbols (AON Format)

```
┌─────────┐     ┌─────────┐     ┌─────────┐
│  ID     │     │  ID     │     │  ID     │
│Activity │────►│Activity │────►│Activity │
│Duration │     │Duration │     │Duration │
└─────────┘     └─────────┘     └─────────┘
   ES/EF           ES/EF           ES/EF
   LS/LF           LS/LF           LS/LF
   Float           Float           Float
```

## Activity List with Dependencies Template

| ID | Activity Name | Duration (days) | Predecessors | Dependency Type | ES | EF | LS | LF | Float |
|----|---------------|-----------------|--------------|-----------------|----|----|----|-----|-------|
| A | Activity name | 3 | - | - | 1 | 3 | 1 | 3 | 0 |
| B | Activity name | 5 | A | FS | 4 | 8 | 4 | 8 | 0 |
| C | Activity name | 2 | A | FS | 4 | 5 | 6 | 7 | 2 |
| D | Activity name | 4 | B, C | FS | 9 | 12 | 9 | 12 | 0 |

## Network Diagram Output Example

```
Activity Network Diagram (AON):

    [A]          [B]           [E]
     │           │             │
     ▼           ▼             ▼
    Start ───► Finish ───► Finish
     │           │
     │           │
     ▼           ▼
    [C] ───────►[D]────────►[F]
                         │
                         ▼
                        [G]
```

## CPM Calculation Example

### Forward Pass:
| Activity | Duration | ES | EF |
|----------|----------|-----|-----|
| A | 3 | 1 | 3 |
| B | 5 | 4 | 8 |
| C | 2 | 4 | 5 |
| D | 4 | 9 | 12 |

- ES of A = 1 (project start)
- EF of A = 1 + 3 - 1 = 3
- ES of B = EF of A + 1 = 4
- EF of B = 4 + 5 - 1 = 8
- ES of C = EF of A + 1 = 4
- EF of C = 4 + 2 - 1 = 5
- ES of D = max(EF of B, EF of C) + 1 = 9
- EF of D = 9 + 4 - 1 = 12

### Backward Pass:
| Activity | LS | LF | Float |
|----------|----|----|-------|
| D | 9 | 12 | 0 |
| C | 6 | 7 | 2 |
| B | 4 | 8 | 0 |
| A | 1 | 3 | 0 |

- LF of D = EF of D = 12
- LS of D = 12 - 4 + 1 = 9
- LF of C = LS of D - 1 = 8
- LS of C = 8 - 2 + 1 = 7
- LF of B = LS of D - 1 = 8
- LS of B = 8 - 5 + 1 = 4
- LF of A = min(LS of B, LS of C) - 1 = 3
- LS of A = 3 - 3 + 1 = 1

**Critical Path: A → B → D** (float = 0 for all activities)

## Automation Tier Summary

**Tier 2 — Accelerate**

This skill accelerates activity sequencing by:
- Providing structured activity list templates with all required fields
- Presenting dependency type definitions and examples
- Offering CPM calculation frameworks for forward/backward passes
- Enabling systematic float calculation
- Providing network diagram notation standards

The skill does NOT automatically determine activity sequence or calculate dates — it provides the framework, formulas, and templates that Thomas populates with project-specific data.

## Known Limitations

1. **Dependency identification requires expertise**: Determining correct dependencies needs deep project knowledge
2. **Circular dependencies**: Complex projects may inadvertently create circular references that are hard to detect
3. **Estimate accuracy**: Network calculations are only as good as the duration estimates
4. **Resource constraints not considered**: CPM assumes unlimited resources; actual schedules may differ
5. **Lead/lag subjectivity**: Determining appropriate lead/lag times requires judgment
6. **Large networks become complex**: Projects with hundreds of activities produce complex diagrams
7. **Changes cascade**: Modifying one activity affects multiple calculations throughout the network
8. **External dependencies**: Dependencies on external parties may be difficult to sequence precisely
