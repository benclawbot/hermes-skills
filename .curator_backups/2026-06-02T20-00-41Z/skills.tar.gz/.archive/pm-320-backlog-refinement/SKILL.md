---
name: pm-320-backlog-refinement
description: Continuously groom the product backlog — prioritizing stories, splitting large items, refining acceptance criteria, and keeping the backlog ready for planning.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, scrum, backlog, user-stories, agile]
    trigger: [backlog refinement, backlog grooming, story refinement, backlog grooming, story grooming, prioritize backlog]
    trigger_context: "Thomas grooming the backlog with the Product Owner — prioritizing stories, splitting large items, defining acceptance criteria"
---
# PM-320: Backlog Refinement

## What
Regularly review and maintain the product backlog — prioritizing work, splitting epics into stories, clarifying requirements, and ensuring stories are ready for sprint planning.

## Refinement Meeting Cadence
- **Scrum**: Typically 5-10% of sprint time (e.g., 2h per 2-week sprint)
- **Kanban**: Continuous, reviewed weekly

## Ready Criteria (INVEST for User Stories)
| Letter | Criterion | Question |
|--------|-----------|----------|
| **I** | Independent | Can this be developed without depending on another story? |
| **N** | Negotiable | Is the scope flexible, not a firm contract? |
| **V** | Valuable | Does this deliver value to the customer/business? |
| **E** | Estimable | Can the team reasonably estimate the effort? |
| **S** | Small | Can this be completed within one sprint? |
| **T** | Testable | Can we verify when it's done? |

## Story Size Guidance
| Size | Story Points | Sprint-fit |
|------|-------------|------------|
| Too small | 1-2 SP | May cause overhead — batch similar stories |
| Right size | 3-8 SP | Ideal for sprint |
| Too large | > 13 SP | Must split — won't fit in one sprint |

## MoSCoW Prioritization
| Priority | Meaning | % of backlog |
|----------|---------|-------------|
| **Must have** | Non-negotiable | ~60% |
| **Should have** | Important, not critical | ~20% |
| **Could have** | Desirable | ~15% |
| **Won't have (this sprint)** | Explicitly deprioritized | ~5% |

## Step-by-Step SOP
1. **Prepare**: Product Owner prioritizes backlog before meeting — top 20 stories should be groomed
2. **Review stories**: Walk through top-priority stories — description, acceptance criteria, size
3. **Split epics**: Break any story > 8 SP into smaller stories that deliver value independently
4. **Clarify**: Ensure each story has clear value, done criteria, and is testable
5. **Estimate**: Team provides estimates for new or changed stories
6. **Re-prioritize**: Move stories based on new information, business urgency
7. **Update**: Move refined stories to "Ready" state — sprint planning can use them

## Backlog Health Metrics
| Metric | Healthy | Needs attention |
|--------|---------|----------------|
| % of top 20 stories Estimated | ≥ 80% | < 80% |
| % of top 20 stories have AC | ≥ 90% | < 90% |
| Average story size | 3-8 SP | > 13 SP |
| Stories not updated > 30 days | < 10% | > 10% |

## Output: Refined Backlog Item
| ID | Title | Epic | SP | Priority | Owner | Ready for Sprint | Notes |
|----|-------|------|----|----------|-------|-----------------|-------|
| SP-201 | Login page design | Authentication | 5 | Must | PO | ✓ | Mockups attached |
| SP-202 | API auth endpoint | Authentication | 8 | Must | Dev | ✓ | |
| SP-203 | Email notifications | Notifications | 13 | Should | — | ✗ | Must split |
| ... | ... | ... | ... | ... | ... | ... | ... |

## Data Sources
- Product backlog (from Product Owner)
- Sprint velocity data (pm-sprint-helper)
- Team capacity

## Automation Tier
**Tier 3 — Augment**: Hermes can draft story descriptions from epic themes, suggest story splits for large items, and flag stories that need refinement based on age or missing acceptance criteria.

## Limitations
- Story prioritization requires Product Owner judgment — cannot be automated
- Splitting stories requires understanding of technical dependencies
- Backlog refinement is a team activity — cannot be done alone