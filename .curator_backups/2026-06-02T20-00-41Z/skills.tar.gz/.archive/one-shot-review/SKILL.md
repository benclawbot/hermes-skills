---
name: one-shot-review
description: After a coding task, skim changed files and flag anything obviously wrong. Fast second pair of eyes — no linter, just judgment.
triggers:
  - coding_task_done
  - files_created
  - files_modified
  - user_requests_review
---

# One-Shot Review

A 30-second code review before wrapping a coding task. Read the changed files, flag the obvious stuff, move on.

**Critical: Test before reporting done.** Thomas expects all changes to be verified with tests before declaring completion. After implementing fixes, run the relevant test suite — do not report "done" until tests pass or pre-existing failures are confirmed as pre-existing. Use `git stash` to isolate your changes and verify the baseline failure before your work; `git stash pop` to restore.

## When to Fire

Run automatically when:
- A coding task is complete (user says "done", "that works", "thanks", or similar close signals)
- You created or modified files
- User asks for a review explicitly ("review this", "/review")

## How to Run

1. **Identify changed files** — `git diff --name-only` or recall from the session what was touched
2. **Skim each file** — read_file with limit=200 lines per file, focus on:
   - Imports (unused? wrong paths? missing dependencies?)
   - Function/class names (inconsistent with project conventions?)
   - Obvious bugs (wrong variable, off-by-one, missing None-check, unhandled edge case)
   - Security surface (hardcoded secrets, unsanitized input, SQL without params)
   - Code smell (copy-paste duplication, commentless logic that's hard to follow)
3. **Report in 3-5 bullet points max** — only flag things worth fixing, not nitpicks

## Speed Rule

Hard limit: **30 seconds of analysis**. If you don't see anything in that window, say "looked clean" and move on. Don't deep-dive. This is a skim, not an audit.

## Output Format

```
## One-Shot Review

**Files:** `file1.py`, `file2.py`

- [file:line] issue description
- [file:line] issue description
- nothing spotted — looks clean
```

## Triage Rule

Only flag things that are:
1. **Likely a bug** — will probably break at runtime
2. **Security risk** — secrets, injection, unsafe patterns
3. **Definitely wrong** — wrong import, wrong type, missing null check

Skip: style preferences, naming opinions (unless genuinely confusing), formatting debates.

## No Linter

Do NOT run linters, formatters, or type checkers. Just read and reason. The goal is judgment, not enforcement.
