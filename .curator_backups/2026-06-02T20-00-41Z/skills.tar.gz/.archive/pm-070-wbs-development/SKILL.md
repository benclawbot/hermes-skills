---
name: pm-070-wbs-development
description: Define project scope and decompose it into a Work Breakdown Structure (WBS) of deliverables, work packages, and activities.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, scope-management, planning]
    trigger: [WBS, work breakdown structure, scope definition, scope decomposition, deliverables hierarchy, WBS dictionary]
    trigger_context: "Thomas breaking down project scope into a hierarchical WBS — defining all deliverables and work packages"
---

# WBS Development SOP

## What This SOP Does

This skill guides Thomas through creating a comprehensive Work Breakdown Structure (WBS) that decomposes project scope into manageable work elements. The WBS ensures complete coverage of all deliverables and provides the foundation for schedule development, cost estimation, and responsibility assignment.

## Step-by-Step WBS Development Process

### 1. Validate Scope Baseline
- Review approved project scope statement
- Confirm project charter and objectives
- Verify deliverables list from requirements elicitation
- Check constraints and assumptions documentation
- Reconcile any scope conflicts before decomposition begins

### 2. Identify Major Deliverables
- List all tangible and intangible deliverables from scope
- Group deliverables by project phase or domain
- Identify external deliverables (to customer, external parties)
- Identify internal deliverables (for subsequent phases, handoff)
- Document each deliverable clearly and unambiguously

### 3. Decompose to Work Packages
- Break down each major deliverable into smaller components
- Continue decomposition until work is:
  - **Estimable**: Can be reasonably estimated for time and cost
  - **Manageable**: Can be assigned to a single responsible party
  - **Measurable**: Progress can be tracked and reported
- Define work packages as the lowest level assigned to a single owner

### 4. Assign WBS Codes
- Develop a numbering system that reflects hierarchy
- Follow standard format: Project → Phase → Deliverable → Work Package → Activity
- Example: 1.0 → 1.1 → 1.1.1 → 1.1.1.1 → 1.1.1.1.1
- Maintain consistency across the entire structure
- Ensure codes are unique and non-repeating

### 5. Create WBS Dictionary Entries
- Document each WBS element in the WBS dictionary
- Include detailed description, owner, and deliverables
- Note dependencies and interfaces
- Capture effort estimates and assumptions
- Ensure dictionary entries align with WBS codes

### 6. Validate with Stakeholders
- Review WBS with project team and key stakeholders
- Verify 100% rule: WBS includes all project scope
- Confirm no work is missing or double-counted
- Check that decomposition is at appropriate level
- Obtain formal sign-off on WBS structure

## WBS Structure Rules

### The 100% Rule
The WBS must encompass 100% of the work scope, including:
- All project deliverables
- All internal work necessary to produce deliverables
- Project management activities (typically 5-15% of effort)
- Warranty and support activities where applicable

### Mutually Exclusive
- Each WBS element represents unique, non-overlapping work
- No deliverable appears in two different branches
- Boundaries between elements are clear and distinct
- Avoids double-counting of work or effort

### Outcomes, Not Actions
- WBS elements represent outcomes (deliverables) not activities
- Use nouns: "Requirements Document" not "Writing Requirements Document"
- Use "Analysis of X" not "Analyzing X"
- Activities live in the activity list, not the WBS

## WBS Hierarchy Levels

| Level | Name | Description | Example |
|-------|------|-------------|---------|
| 1 | Project | The complete project | ERP Implementation |
| 2 | Phase | Major project phase | Planning Phase |
| 3 | Deliverable | Key deliverable/product | Requirements Specification |
| 4 | Work Package | Bundle of related work | Requirements Gathering |
| 5 | Activity | Specific task (in activity list) | Stakeholder interviews |

## WBS Dictionary Template

```
WBS Element: [Code] [Name]
=====================================

**Description:** [Clear description of what this element includes]

**Owner:** [Person/Role responsible]

**Deliverables Produced:**
- [Deliverable 1]
- [Deliverable 2]

**Dependencies:**
- [Predecessor WBS elements or external dependencies]
- [Input dependencies]

**Effort Estimate:** [Person-hours/days/weeks]

**Assumptions:** [Any assumptions underlying this estimate]

**Constraints:** [Any constraints affecting this work]

**Interfaces:** [Cross-cutting concerns or handoff points]
```

## WBS Outline Template (Hierarchical Markdown)

```markdown
# Project WBS

## 1.0 [Project Name]

### 1.1 [Phase 1: Initiation]

#### 1.1.1 [Deliverable 1.1.1]
- 1.1.1.1 [Work Package A]
- 1.1.1.2 [Work Package B]

#### 1.1.2 [Deliverable 1.1.2]
- 1.1.2.1 [Work Package A]
- 1.1.2.2 [Work Package B]

### 1.2 [Phase 2: Planning]

#### 1.2.1 [Deliverable 1.2.1]
- 1.2.1.1 [Work Package A]

### 1.3 [Phase 3: Execution]

### 1.4 [Phase 4: Monitoring & Control]

### 1.5 [Phase 5: Closing]

### 1.6 [Project Management Activities]
- 1.6.1 [Project Integration]
- 1.6.2 [Schedule Management]
- 1.6.3 [Cost Management]
- 1.6.4 [Quality Management]
- 1.6.5 [Risk Management]
- 1.6.6 [Communications Management]
```

## Complete WBS Example (Small Project)

```markdown
# Website Redesign Project WBS

## 1.0 Website Redesign Project

### 1.1 Initiation
#### 1.1.1 Project Charter
#### 1.1.2 Stakeholder Register

### 1.2 Planning
#### 1.2.1 Requirements Definition
- 1.2.1.1 Requirements Gathering
- 1.2.1.2 Requirements Documentation
- 1.2.1.3 Requirements Approval
#### 1.2.2 Design Specifications
- 1.2.2.1 Information Architecture
- 1.2.2.2 Visual Design
- 1.2.2.3 Prototype Development

### 1.3 Development
#### 1.3.1 Front-end Development
- 1.3.1.1 Page Templates
- 1.3.1.2 User Interface Components
- 1.3.1.3 Responsive Design
#### 1.3.2 Back-end Development
- 1.3.2.1 Database Configuration
- 1.3.2.2 API Development
- 1.3.2.3 Integration Services

### 1.4 Testing
#### 1.4.1 Unit Testing
#### 1.4.2 Integration Testing
#### 1.4.3 User Acceptance Testing

### 1.5 Deployment
#### 1.5.1 Staging Deployment
#### 1.5.2 Production Deployment
#### 1.5.3 Training and Documentation

### 1.6 Project Management
- 1.6.1 Planning Activities
- 1.6.2 Tracking and Reporting
- 1.6.3 Change Management
- 1.6.4 Quality Assurance
```

## Decomposition Guidelines

### When to Stop Decomposing
Stop when work packages are:
- Small enough to be completed within one reporting period (typically 2-4 weeks)
- Clearly understood by responsible party
- Able to be realistically estimated
- Assignable to a single owner

### Common Decomposition Approaches
- **By Phase**: Initiation → Planning → Execution → Monitoring → Closing
- **By Deliverable**: Each major deliverable becomes a branch
- **By Geographic Location**: Regional or site-based breakdown
- **By Resource Type**: Hardware, Software, People, Services
- **By Functional System**: Subsystem or component breakdown

## Automation Tier Summary

**Tier 2 — Accelerate**

This skill accelerates WBS development by:
- Providing ready-to-use WBS outline templates
- Offering structured WBS dictionary format
- Presenting clear hierarchy guidelines and rules
- Enabling rapid creation of consistent documentation
- Reducing planning time through template adaptation

The skill does NOT automatically decompose work or generate the WBS structure — it provides the framework and templates that Thomas populates based on project knowledge.

## Known Limitations

1. **Subjectivity in decomposition**: Determining the right level of detail requires judgment and experience
2. **Scope creep during decomposition**: Breaking down work often reveals additional tasks not originally envisioned
3. **Changing requirements**: WBS may need revision as requirements evolve
4. **Resource knowledge dependency**: Accurate decomposition requires understanding of how work gets done
5. **Integration complexity**: Interface and dependency management between WBS elements can be challenging
6. **Large project complexity**: Very large projects may have deep WBS hierarchies that are difficult to navigate
7. **Cross-project dependencies**: WBS typically focuses on single project; multi-project dependencies require additional management
