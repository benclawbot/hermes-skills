---
name: pm-260-team-demobilization
description: Formally demobilize the project team — release resources, conduct exit interviews, reassign workloads, and close project accounts.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, closure, team, resource-management]
    trigger: [team demobilization, resource release, team release, project close, offboarding, resource allocation]
    trigger_context: "Thomas formally releasing the project team at project close — reassigning people, closing project codes, exit interviews"
---
# PM-260: Team Demobilization

## What
Release project team members back to their line managers, close project charge codes, conduct exit interviews, and ensure a clean transition.

## Step-by-Step SOP
1. **Confirm closure date**: Align with sponsor and line managers on exact end date
2. **Notify team early**: Minimum 2 weeks notice — formal notification to each member and their manager
3. **Complete time sheets**: All team members complete and submit final timesheets
4. **Close project codes**: Notify finance to close project cost centers/charge codes
5. **Conduct exit interviews**: 15-minute conversation with each team member — what worked, what didn't, future availability
6. **Transfer knowledge**: Ensure all project knowledge is documented and transferred to operations/BA
7. **Issue reference**: PM provides reference for contract staff who performed well
8. **Confirm next assignments**: Line manager confirms next role/project for each team member
9. **Celebrate**: Recognize team achievements — even a simple thank-you matters
10. **Close team accounts**: Remove project access credentials, close shared channels

## Project Team Release Timeline
| Milestone | Timing | Action |
|-----------|--------|--------|
| Notify team of end | -2 weeks | Formal announcement |
| Complete final deliverables | -1 week | Last work items finished |
| Exit interviews | -3 days to 0 | PM conducts |
| Final timesheet submission | Last day | Finance cutoff |
| Project code closed | End date + 3 days | Finance action |
| Final payment processed | End date + 5 days | Contractors/vendors |

## Team Member Transition Log
| Team Member | Role | Line Manager | Next Assignment | Last Day | Exit Interview |
|-------------|------|--------------|----------------|----------|---------------|
| Jean-Didier | Developer | [Mgr Name] | Project Alpha | 2024-07-31 | ✓ Complete |
| Nathanael | Tech Lead | [Mgr Name] | Available | 2024-07-31 | Scheduled |
| ... | ... | ... | ... | ... | ... |

## Exit Interview Template (15 min)
1. **What went well** during this project? (process, team, support)
2. **What could improve**? (process, communication, resources)
3. **Would you work on a similar project again**?
4. **Any other feedback**?
5. **Next steps**: PM records notes, shares with line manager if relevant

## Data Sources
- Team roster (original resource plan)
- HR/Finance on project codes
- Line manager coordination

## Automation Tier
**Tier 3 — Augment**: Hermes can draft the release notification email, generate transition log template, and prepare exit interview prompts. Human handles the interpersonal aspects.

## Limitations
- Team demobilization is sensitive — cannot fully automate the human elements
- Staff leasing/contractor timing depends on contract end dates
- Exit interviews require human empathy and judgment