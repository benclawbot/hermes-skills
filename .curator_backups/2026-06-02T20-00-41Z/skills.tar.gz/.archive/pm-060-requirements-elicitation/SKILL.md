---
name: pm-060-requirements-elicitation
description: Elicit, document, and validate detailed requirements from stakeholders using structured techniques (interviews, workshops, JAD sessions).
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, requirements-management, stakeholder-engagement]
    trigger: [requirements, requirements elicitation, user stories, backlog items, acceptance criteria, JAD session, interview]
    trigger_context: "Thomas as Senior IT PM gathering detailed requirements from stakeholders — structured elicitation leading to clear, testable requirements"
---

# Requirements Elicitation SOP

## What This SOP Does

This skill guides Thomas through the systematic process of identifying, capturing, documenting, and validating project requirements from stakeholders. It ensures requirements are complete, unambiguous, testable, and traceable.

## Step-by-Step Elicitation Process

### 1. Identify Stakeholders
- Map all project stakeholders (users, sponsors, governance, external parties)
- Document stakeholder categories: primary users, secondary users, influencers, decision-makers
- Identify champion users and key SMEs for each domain area
- Document contact information and engagement preferences

### 2. Select Elicitation Technique
Choose appropriate technique(s) based on stakeholder availability, domain complexity, and project phase:

- **Interviews**: One-on-one sessions for deep discovery, sensitive topics, or high-authority stakeholders
- **Workshops**: Group sessions for alignment, cross-functional requirements, or ideation
- **JAD (Joint Application Development) Sessions**: Structured workshops with IT and business working together
- **Observation**: Shadowing users in their environment for operational requirements
- **Document Analysis**: Review existing documentation, policies, and system artifacts

### 3. Prepare Elicitation Activities
- Develop interview guides or workshop agendas
- Schedule sessions and confirm attendees
- Distribute pre-reading materials if needed
- Set up recording and note-taking protocols
- Prepare required templates and tools

### 4. Conduct Elicitation Sessions
- Follow prepared guides while remaining flexible to follow valuable tangents
- Use open-ended questions to explore needs, then closed questions to confirm understanding
- Apply the 5 Whys technique to drill into root causes
- Capture assumptions and constraints explicitly
- Maintain focus on "what" and "why" not "how"
- Manage group dynamics in workshop settings

### 5. Document Requirements
- Record all requirements in the requirements register template
- Apply consistent ID numbering convention (e.g., REQ-001, REQ-002)
- Write requirements in standardized format
- Identify requirements dependencies and relationships
- Tag requirements with source stakeholder

### 6. Validate Requirements
- Review documented requirements with original stakeholders
- Conduct structured walkthrough sessions
- Verify requirements are: Complete, Correct, Consistent, Feasible, Necessary, Testable, Unambiguous
- Check traceability to business objectives

### 7. Obtain Sign-off
- Present final requirements document for approval
- Obtain sign-off from authorized stakeholders
- Distribute approved requirements to project team
- Establish change control process for subsequent modifications

## Requirements Document Template

| Field | Description |
|-------|-------------|
| **ID** | Unique requirement identifier (e.g., REQ-001) |
| **Description** | Clear, concise statement of the requirement |
| **Source** | Stakeholder or document that originated this requirement |
| **Priority** | MoSCoW rating (Must have, Should have, Could have, Won't have) |
| **Acceptance Criteria** | Specific conditions that must be met for the requirement to be considered fulfilled |
| **Dependencies** | Other requirements or external factors this depends on |
| **Owner** | Person responsible for this requirement's delivery |
| **Type** | Functional, Non-functional, Technical, Business rule |

## User Story Format

```
As a [type of user]
I want [goal/action]
so that [benefit/value]
```

### Example:
```
As a Department Manager
I want to approve purchase requests online
so that I can process approvals faster without being physically present
```

### Acceptance Criteria for User Stories:
- Given [context/precondition]
- When [action performed]
- Then [expected outcome]

## MoSCoW Prioritization

| Category | Description | Target Allocation |
|----------|-------------|-------------------|
| **Must Have** | Critical for project success; no go-live without | ~60% of requirements |
| **Should Have** | Important but not critical; significant value impact | ~20% of requirements |
| **Could Have** | Desirable but optional; minor impact | ~15% of requirements |
| **Won't Have (This Release)** | Explicitly excluded; deferred to future phase | ~5% of requirements |

## Requirements Register Template

```
# Requirements Register

**Project:** [Project Name]
**Date:** [Date]
**Prepared By:** [Name]

## Requirement List

| ID | Description | Source | Priority | Owner | Status |
|----|-------------|--------|----------|-------|--------|
| REQ-001 | [Description] | [Source] | Must | [Owner] | [Status] |
| REQ-002 | [Description] | [Source] | Should | [Owner] | [Status] |

## Sign-off

| Role | Name | Signature | Date |
|------|------|-----------|------|
| Business Sponsor | | | |
| Project Manager | | | |
| IT Lead | | | |
```

## Elicitation Techniques Reference

### Interviews
- **Types**: Structured, Semi-structured, Unstructured
- **Best for**: Deep discovery, executive stakeholders, sensitive topics
- **Duration**: 45-90 minutes typical
- **Tips**: Prepare questions in advance, record (with permission), send summary for validation

### Workshops/JAD Sessions
- **Best for**: Cross-functional alignment, complex requirements, rapid prototyping
- **Duration**: 2-4 hours typical
- **Group Size**: 6-12 participants optimal
- **Tips**: Clear agenda, skilled facilitator, breakout groups for complex topics

### Observation
- **Types**: Passive observation, Active observation, Shadowing
- **Best for**: Operational processes, hidden requirements, usability insights
- **Duration**: Multiple sessions of 2-4 hours
- **Tips**: Explain purpose, ask clarifying questions during observation

### Document Analysis
- **Best for**: Understanding existing systems, policy requirements, historical context
- **Sources**: Policies, procedures, existing system documentation, forms, reports

## Automation Tier Summary

**Tier 3 — Augment**

This skill augments the requirements elicitation process by:
- Providing structured templates for consistent documentation
- Offering technique selection guidance based on context
- Presenting prioritization frameworks (MoSCoW)
- Enabling faster document creation through templates
- Capturing best practices and tips within the skill

Automation does NOT replace human elicitation activities, stakeholder engagement, or judgment calls. The PM must still conduct interviews, facilitate workshops, and interpret stakeholder input.

## Known Limitations

1. **Template fatigue**: Excessive use of templates can make sessions feel rigid; balance structure with flexibility
2. **Stakeholder availability**: Key stakeholders may not be available for validation sessions; build in buffer time
3. **Scope creep risk**: Elicitation often reveals additional needs; maintain strict scope management
4. **Requirement ambiguity**: Some requirements emerge gradually; allow for iterative refinement
5. **Conflicting stakeholder needs**: Different stakeholders may have incompatible requirements; PM must facilitate resolution
6. **Cultural/language barriers**: In global projects, ensure clear communication across language differences
7. **Tacit knowledge**: Some knowledge is not easily articulated; observation helps but may miss nuances
