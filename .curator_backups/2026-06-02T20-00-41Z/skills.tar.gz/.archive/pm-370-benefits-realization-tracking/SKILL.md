---
name: pm-370-benefits-realization-tracking
description: Track project benefits after go-live — measure realized benefits against targets, document variances, and report to stakeholders.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, closure, benefits, value-realization, ROI]
    trigger: [benefits realization, benefits tracking, value realization, post-project benefits, ROI tracking, business case benefits]
    trigger_context: "Thomas tracking benefits after go-live — measuring if the project delivered the expected business value"
---
# PM-370: Benefits Realization Tracking

## What
After project go-live, track whether the benefits promised in the business case are actually being realized — measure against targets, document gaps, and report to sponsor.

## Benefits vs. Deliverables
| | Deliverables | Benefits |
|-|--------------|----------|
| What | Project outputs (software, systems, reports) | Business outcomes (revenue increase, cost reduction) |
| When | During project | After go-live (may take months/years) |
| Who owns | Project team | Business / Operations |
| Measurement | QA, acceptance | KPIs, financial metrics |

## Benefits Categories
| Category | Examples | Measurement |
|----------|----------|-------------|
| **Revenue** | New sales, increased conversion | € or % increase |
| **Cost reduction** | Headcount reduction, process automation | € saved/year |
| **Time savings** | Faster process, reduced cycle time | hours or days saved |
| **Quality** | Error reduction, compliance | % improvement |
| **Customer satisfaction** | NPS, CSAT | Point increase |
| **Strategic** | Market position, compliance | Qualitative |

## Post-Project Review Cadence
| Review | Timing | Focus |
|--------|--------|-------|
| Go-live + 30 days | First check | System stable, basic usage |
| Go-live + 90 days | Early benefits | Are benefits starting to materialize? |
| Go-live + 6 months | Mid-term | Benefits trajectory vs. target |
| Go-live + 12 months | Full assessment | Total realized vs. business case |
| Annual (years 2-3) | Long-term | Sustained benefits, new opportunities |

## Benefits Tracking Table
| Benefit ID | Benefit Description | Target | Actual (30d) | Actual (90d) | Actual (6m) | Status |
|------------|---------------------|--------|-------------|-------------|------------|--------|
| B-001 | Call center handle time | -20% | -8% | -15% | -18% | 🟡 On track |
| B-002 | Customer NPS | +15 points | +5 points | +10 points | +13 points | 🟢 Ahead |
| B-003 | Annual cost savings | €500K | N/A | N/A | €120K | 🟡 Partial |
| ... | ... | ... | ... | ... | ... | ... |

## Variance Analysis
| Benefit | Target | Actual | Variance | % Achieved | Explanation |
|---------|--------|--------|----------|-----------|-------------|
| B-001 Handle time | -20% | -18% | +2% | 90% | Slight difference in baseline measurement |
| B-002 NPS | +15 pts | +13 pts | -2 pts | 87% | System downtime affected experience in month 2 |
| B-003 Cost savings | €500K | €120K (6m) | €380K | 24% | Benefits realization takes time — tracking annually |
| ... | ... | ... | ... | ... | ... |

## Step-by-Step SOP
1. **Baseline**: At project close (pm-250-project-closure-report), extract benefit targets from business case
2. **Assign owners**: Each benefit has a business owner who tracks and reports
3. **Define measurement**: For each benefit, define how to measure it (metric, source system, frequency)
4. **Review schedule**: Set post-project review dates (30d, 90d, 6m, 12m, annual)
5. **Collect data**: At each review, gather actual values from source systems
6. **Compare**: Actual vs. target — note positive/negative variance
7. **Investigate**: If significant negative variance — understand why, document root cause
8. **Report**: Benefits realization report to sponsor at each review point
9. **Act**: If benefits not materializing — identify corrective actions (process change, training, system tweaks)

## Output: Benefits Realization Report (Post-Project Review)

### Executive Summary
> 3 of 5 benefits are on track or ahead. B-003 (cost savings) is tracking at 24% of target at 6 months — this is normal for cost benefits which take time to materialize. B-001 (handle time) is at 90% of target — minor measurement variance. Overall, project is delivering expected value.

### Benefits Status
| Benefit | Category | Target | Current | Achieved | RAG |
|---------|----------|--------|---------|----------|-----|
| Call handling time | Efficiency | -20% | -18% | 90% | 🟡 |
| Customer NPS | Satisfaction | +15 pts | +13 pts | 87% | 🟡 |
| Annual cost savings | Cost reduction | €500K | €120K (6m) | 24% | 🟢* |
| System uptime | Operational | 99.5% | 99.7% | 100% | 🟢 |
| Employee satisfaction | People | +10 pts | +8 pts | 80% | 🟡 |

*Cost savings typically realize over 12 months as processes stabilize

### Corrective Actions Needed
| Benefit | Gap | Action | Owner | Date |
|---------|-----|--------|-------|------|
| B-003 Cost savings | €380K gap | Operational change program launched | Operations Lead | 2024-10-01 |

## Data Sources
- Business case (pm-040-business-case)
- Project closure report (pm-250-project-closure-report)
- Business operational data (source systems)
- Business owners

## Automation Tier
**Tier 2 — Accelerate**: Hermes can draft benefits tracking table from business case targets, pull actual values from data sources (if integrated), and generate variance reports.

## Limitations
- Benefits measurement depends on operational data availability — some benefits are hard to isolate
- External factors (market conditions, organizational changes) can affect benefit realization
- Benefits realization is a business responsibility — PM facilitates, business owns it
- Lag time between go-live and benefit realization can be 12+ months — requires sustained attention