---
name: pm-330-quality-assurance-deliverables
description: Conduct QA reviews and formally accept or reject project deliverables against acceptance criteria and quality standards.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, QA, deliverable-review, acceptance]
    trigger: [QA review, deliverable review, acceptance testing, UAT, quality review, sign-off]
    trigger_context: "Thomas reviewing deliverables against acceptance criteria — formally accepting or rejecting work products"
---
# PM-330: Quality Assurance & Deliverable Review

## What
Conduct formal reviews of deliverables — verify against acceptance criteria, check quality standards, and formally accept or reject each deliverable.

## QA Review Levels
| Level | Focus | Who | When |
|-------|-------|-----|------|
| **Peer review** | Technical accuracy | Dev team | During development |
| **QA review** | Functional correctness | QA | After development |
| **UAT** | Business fit | Business owner | Before go-live |
| **Final review** | Complete acceptance | Sponsor/PM | At delivery |

## Deliverable Review Checklist
- [ ] Deliverable matches description in WBS
- [ ] Acceptance criteria met (all checkboxes)
- [ ] Quality metrics within thresholds (defect density, coverage)
- [ ] Documentation complete
- [ ] Dependencies resolved (integrates with other deliverables)
- [ ] No critical or major open issues against this deliverable
- [ ] Signed off by responsible reviewer

## Acceptance Criteria Types
| Type | Example | Verification |
|------|---------|-------------|
| Functional | "User can search by name" | Test passes |
| Performance | "Response time < 200ms" | Load test passes |
| Security | "No critical vulns" | Security scan passes |
| Usability | "Accessible to WCAG AA" | Audit passes |
| Operational | "Deployable in < 30 min" | Deployment test passes |

## Step-by-Step SOP
1. **Identify deliverable**: Which WBS element / deliverable is ready for review
2. **Notify reviewer**: QA lead or business owner — provide deliverable location and criteria
3. **Review**: Reviewer checks against criteria — document findings
4. **If rejected**: Log issues, return to team with specific defects — re-review after fixes
5. **If conditionally accepted**: Note minor issues, set timeline for fixes
6. **If accepted**: Sign-off in deliverable acceptance log (pm-250-project-closure-report)
7. **Update status**: Move deliverable to "Accepted" state

## Output: Deliverable Review Record
| Deliverable | Reviewer | Review Date | Decision | Issues Found | Sign-off |
|-------------|----------|-------------|----------|-------------|----------|
| API Gateway | QA Lead | 2024-07-01 | Accepted | 0 critical, 2 minor | ✓ |
| User Portal | Business Owner | 2024-07-05 | Conditional | 1 major (navigation) | Pending fix |
| Mobile App | Security Auditor | 2024-07-08 | Rejected | Critical auth vuln | Fix by 07-12 |
| ... | ... | ... | ... | ... | ... |

## Quality Metrics Dashboard
| Deliverable | Defect Density | Coverage | Performance | Security | Status |
|-------------|---------------|----------|-------------|----------|--------|
| API Gateway | 1.2/KLOC | 82% | ✓ | ✓ | Accepted |
| User Portal | 3.5/KLOC | 68% | ✓ | ✓ | Conditionally accepted |
| ... | ... | ... | ... | ... | ... |

## Data Sources
- WBS (pm-070-wbs-development)
- Quality plan (pm-150-quality-planning)
- Test results (CI/CD pipeline, QA reports)
- Acceptance criteria per deliverable

## Automation Tier
**Tier 3 — Augment**: Hermes can draft QA review checklist from acceptance criteria, compare test results against thresholds, and flag deliverables not meeting quality gates.

## Limitations
- Human judgment required for business acceptance — UAT cannot be fully automated
- Some quality checks require specialized tools (security scanners, performance testers)
- Acceptance is a formal commitment — should not be given lightly