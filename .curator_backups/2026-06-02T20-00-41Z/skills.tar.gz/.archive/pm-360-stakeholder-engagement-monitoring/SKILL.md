---
name: pm-360-stakeholder-engagement-monitoring
description: Monitor stakeholder engagement levels, track satisfaction, and identify stakeholders at risk of becoming disengaged or opposed.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, stakeholder-management, engagement]
    trigger: [stakeholder engagement, stakeholder satisfaction, stakeholder monitoring, engagement level, stakeholder health]
    trigger_context: "Thomas monitoring stakeholder engagement and satisfaction — identifying at-risk stakeholders before they become problems"
---
# PM-360: Stakeholder Engagement Monitoring

## What
Monitor stakeholder engagement levels continuously — track satisfaction, identify early warning signals of disengagement or opposition, and take action before stakeholders become project blockers.

## Stakeholder Engagement Levels (Managing Interest & Influence)
| Level | Description | Behavior | Action |
|-------|-------------|----------|--------|
| **Leading** | Highly engaged, strong advocate | Actively promotes project | Keep informed, involve in decisions |
| **Supportive** | Engaged, agrees with direction | Participates when asked | Regular updates, recognition |
| **Neutral** | Not engaged or disengaged | Attends meetings but passive | Increase communication, invite input |
| ** Resistant** | Active opposition | Undermines decisions | Understand concerns, address directly |
| **Blocking** | Highest opposition | Stops progress | Escalate, manage formally |

## Engagement Assessment Method
Ask stakeholders directly (quarterly survey or conversation):
> "On a scale of 1-10, how engaged do you feel with this project?"
> "What would increase your engagement?"

Track over time — downward trend is a warning signal.

## Early Warning Signals
| Signal | What it looks like | Risk level |
|--------|-------------------|-----------|
| Attendance drops | Missing meetings, no response to invites | Medium |
| Feedback stops | No comments, no questions, silent in meetings | Medium |
| Quality of feedback changes | superficial approval vs. genuine input | Medium |
| Escalation frequency increases | Sponsor getting complaints before PM hears | High |
| Scope objections | Formal objections to changes, requirements | High |
| Sponsor disengagement | Sponsor stops attending steering committee | Critical |

## Step-by-Step SOP
1. **Baseline**: At project start, assess each stakeholder's current engagement level (Leading/Supportive/Neutral/Resistant/Blocking)
2. **Track**: Monitor meeting attendance, response rate, feedback quality over time
3. **Survey**: Quarterly — brief pulse survey on engagement and satisfaction
4. **Update**: Adjust engagement levels in stakeholder register
5. **Act**: For Resistant or Blocking stakeholders — develop targeted engagement plan
6. **Escalate**: If sponsor disengages or Blocking stakeholder emerges — escalate immediately

## Engagement Tracking Table
| Stakeholder | Role | Baseline | Week 4 | Week 8 | Week 12 | Trend |
|-------------|------|----------|--------|--------|---------|-------|
| Jean-Marc (Sponsor) | Sponsor | Leading | Leading | Supportive | | ↓ Concern |
| Sophie (Business) | Business Lead | Supportive | Supportive | Neutral | | ↓ Watch |
| ... | ... | ... | ... | ... | ... | ... |

## Targeted Engagement Plans
For stakeholders showing resistance or disengagement:
1. **Understand**: Why? Direct conversation — "I've noticed you've been less involved — what would help?"
2. **Address**: If concerns are valid, address them (change, extra communication, involvement)
3. **Escalate**: If cannot resolve — involve PM's manager or sponsor to help

## Output: Stakeholder Engagement Health Report
| Stakeholder Group | Count | Leading | Supportive | Neutral | Resistant | Blocking |
|-------------------|-------|---------|------------|---------|-----------|----------|
| Steering Committee | 5 | 2 | 2 | 1 | 0 | 0 |
| Business Owners | 8 | 1 | 4 | 2 | 1 | 0 |
| Technical Team | 12 | 3 | 6 | 3 | 0 | 0 |

> **Alert**: 2 stakeholders at Neutral, 1 at Resistant — engagement plan active for Sophie (Business). Jean-Marc (Sponsor) engagement declining — schedule 1:1 this week.

## Data Sources
- Stakeholder register (pm-020-stakeholder-analysis)
- Meeting attendance logs
- Survey responses
- Sponsor and PM observations

## Automation Tier
**Tier 2 — Accelerate**: Hermes can track engagement metrics (meeting attendance, response rates) from calendar/email, flag downward trends, and draft engagement health reports.

## Limitations
- True engagement is qualitative — data shows symptoms, not root causes
- Some stakeholders will not respond honestly in surveys
- Action requires human relationship — cannot automate engagement