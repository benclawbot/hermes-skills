---
name: pm-100-raci-matrix
description: Assign roles and responsibilities using a RACI matrix (Responsible, Accountable, Consulted, Informed) for all project activities.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, responsibility-matrix, resource-management, accountability]
    trigger: [RACI matrix, responsibility matrix, RACI, resource allocation, role assignment, accountability, RASCI]
    trigger_context: "Thomas creating a RACI matrix for a project — assigning who does what and who is accountable for each activity"
---

# RACI Matrix Development SOP

## What This SOP Does

This skill guides Thomas through creating a RACI matrix to assign and communicate roles and responsibilities for all project activities. It ensures clear accountability, prevents gaps in responsibility, and facilitates stakeholder alignment.

## RACI Definitions

| Code | Role | Description | Key Characteristics |
|------|------|-------------|---------------------|
| **R** | Responsible | Does the work to complete the task | Performs the activity, creates the deliverable |
| **A** | Accountable | Ultimate ownership; final decision authority | Only one A per activity; cannot delegate accountability |
| **C** | Consulted | Provides input; two-way communication | Subject matter experts, stakeholders who advise |
| **I** | Informed | Receives updates; one-way communication | Stakeholders who need to know outcomes |

### RACI Decision Rules
- **One A per activity**: One person has final accountability
- **At least one R per activity**: Someone must do the work
- **Max 5 RACI codes per activity**: Too many roles = confusion
- **C and I are not substitutes for R**: Don't consult your way out of doing work
- **A is always accountable, never merely responsible**: The buck stops here

## Step-by-Step RACI Development Process

### 1. List All Project Activities
- Review WBS and activity list
- Include all significant project activities
- Include project management activities
- Group activities by phase or workstream for clarity
- Ensure activity list is comprehensive (100% rule)

### 2. Identify All Project Roles
- Define all roles involved in the project
- Consider: Project Manager, Sponsor, Team Lead, SMEs, Stakeholders, External parties
- Document roles, not individuals (allows for staffing flexibility)
- Group related roles where appropriate
- Ensure all activities have corresponding roles defined

### 3. Assign RACI Codes per Activity
For each activity, determine:
- **R**: Who performs the work?
- **A**: Who has final decision authority?
- **C**: Who must be consulted before proceeding?
- **I**: Who needs to be informed after completion?

Document reasoning for each assignment.

### 4. Review for Gaps and Overlaps
Check matrix for common issues:
- **Empty cells**: Activity with no assignment
- **No A**: Activity without accountable party
- **No R**: Activity no one does
- **Multiple A**: More than one accountable party
- **Too many codes**: More than 5 roles per activity
- **All I's**: No one doing or accountable work

### 5. Validate with Stakeholders
- Review matrix with project team
- Validate role assignments are accurate
- Confirm stakeholders understand their roles
- Adjust based on feedback
- Obtain sign-off from role owners

## RACI Matrix Template

### Basic Format
```
                    | Role 1 | Role 2 | Role 3 | Role 4 | Role 5 |
--------------------|--------|--------|--------|--------|--------|
Activity 1          |   R    |   A    |   C    |   I    |        |
Activity 2          |   C    |   R    |   A    |        |        |
Activity 3          |   A    |   R    |   C    |   I    |        |
```

### Detailed Format with Descriptions
```
                    | Sponsor | PM | BA | Dev Lead | Developer | QA Lead | Tester |
--------------------|---------|----|----|----------|-----------|---------|--------|
Requirements        |   I     | A  | R  |    C     |           |    C    |   C    |
Design              |   I     | A  | C  |    R     |           |    C    |        |
Development         |   I     | A  | I  |    R     |    R      |         |        |
Testing             |   I     | A  | I  |    C     |           |    R    |   R    |
Deployment          |   I     | A  | I  |    R     |           |    C    |        |
```

## RACI Matrix Example (Complete Project)

```markdown
# Project RACI Matrix

**Project:** ERP Implementation
**Version:** 1.0
**Date:** 2026-01-15

## Roles Defined
| Role | Description |
|------|-------------|
| Sponsor | Executive sponsor with budget authority |
| PM | Project Manager |
| BA | Business Analyst |
| Arch | Solution Architect |
| DevL | Development Lead |
| Dev | Developer |
| QAL | QA Lead |
| Tester | QA Tester |
| BizOps | Business Operations |
| Trainer | Training Lead |

## RACI Matrix

| Activity | Sponsor | PM | BA | Arch | DevL | Dev | QAL | Tester | BizOps | Trainer |
|----------|---------|----|----|------|------|-----|-----|--------|--------|---------|
| **Initiation** |
| Project Charter | A | R | C | C | I | I | I | I | I | I |
| Stakeholder Register | A | R | R | I | I | I | I | I | C | I |
| **Planning** |
| Requirements | I | A | R | C | C | I | C | I | C | I |
| Design | I | A | C | R | C | I | I | I | I | I |
| Schedule | I | A | C | C | R | C | C | I | I | C |
| **Execution** |
| Development | I | A | I | C | R | R | I | I | I | I |
| Testing | I | A | C | I | C | I | R | R | I | I |
| Training | I | A | C | I | I | I | I | I | C | R |
| Deployment | A | R | I | C | C | C | C | C | C | C |
| **Closing** |
| Hypercare | I | A | I | C | R | R | C | C | I | C |
| Project Sign-off | A | R | C | C | C | I | C | C | C | I |
```

## RACI Matrix by Phase

### Initiation Phase

| Activity | Sponsor | PM | BA | Tech Lead | Biz Rep |
|----------|---------|----|----|-----------|---------|
| Define project scope | A | R | C | C | C |
| Identify stakeholders | I | R | R | C | C |
| Develop business case | A | R | C | I | C |
| Create project charter | A | R | C | C | I |
| Initial risk assessment | I | A | C | R | I |

### Planning Phase

| Activity | Sponsor | PM | BA | Tech Lead | Biz Rep |
|----------|---------|----|----|-----------|---------|
| Detailed requirements | I | A | R | C | C |
| System design | I | A | C | R | I |
| Development plan | I | A | I | R | I |
| Testing strategy | I | A | C | R | C |
| Training plan | I | A | C | I | R |
| Schedule development | I | A | C | R | C |

### Execution Phase

| Activity | Sponsor | PM | BA | Tech Lead | Biz Rep |
|----------|---------|----|----|-----------|---------|
| System development | I | A | I | R | I |
| Unit testing | I | A | I | R | I |
| Integration testing | I | A | C | R | I |
| UAT coordination | I | A | R | C | R |
| Training delivery | I | A | C | I | R |
| Deployment | A | R | C | R | C |

### Monitoring & Controlling

| Activity | Sponsor | PM | BA | Tech Lead | Biz Rep |
|----------|---------|----|----|-----------|---------|
| Status reporting | I | R | I | C | I |
| Risk monitoring | I | A | C | C | I |
| Change control | A | R | C | C | C |
| Quality assurance | I | A | C | R | I |
| Schedule tracking | I | R | I | C | I |

### Closing Phase

| Activity | Sponsor | PM | BA | Tech Lead | Biz Rep |
|----------|---------|----|----|-----------|---------|
| Final testing | I | A | C | R | I |
| Documentation | I | A | C | R | I |
| Handoff to operations | A | R | C | C | R |
| Project review | I | A | C | C | C |
| Archiving | I | R | I | C | I |

## RACI Validation Checklist

### Gap Analysis
- [ ] Every activity has at least one R (Responsible)
- [ ] Every activity has exactly one A (Accountable)
- [ ] No activities have zero assignments
- [ ] No activities have more than one A

### Quality Checks
- [ ] Matrix is not overloaded (no row with >5 codes)
- [ ] Consulted (C) roles provide meaningful input
- [ ] Informed (I) roles need to know, not need to approve
- [ ] RACI is balanced across roles

### Clarity Checks
- [ ] Role names are consistent
- [ ] Activities are clearly worded
- [ ] Matrix is easy to read and understand
- [ ] Stakeholders can find their roles easily

## Common RACI Patterns

### Pattern 1: Normal Execution
```
Activity | PM | Team Member |
---------|----|-------------|
Work     | A  | R           |
```
PM accountable, team member does the work.

### Pattern 2: Approval Required
```
Activity | Sponsor | PM | Team |
---------|---------|----|------|
Work     |    I    | A  |  R  |
Approval |    A   | R  |  C  |
```
Sponsor informed of work, accountable for approval.

### Pattern 3: Advisory Input
```
Activity | PM | SME | Team |
---------|----|-----|------|
Work     | A  | C   |  R  |
```
SME consulted for expertise, team does work.

## RACI vs. Other Responsibility Matrices

| Matrix | R | A | C | I | Notes |
|--------|---|---|---|---|-------|
| **RACI** | Yes | Yes | Yes | Yes | Most common for projects |
| **RASCI** | Yes | Yes | Yes | Yes | S = Support (similar to Responsible) |
| **RACI-VS** | Yes | Yes | Yes | Yes | VS = Verified |
| **DACI** | Yes | Yes | Yes | Yes | D = Driver (PM-like), C = Contributor, I = Informed |

## Automation Tier Summary

**Tier 2 — Accelerate**

This skill accelerates RACI development by:
- Providing structured RACI matrix templates
- Presenting clear definitions and examples
- Offering validation checklists for gap analysis
- Enabling rapid creation of role-activity mappings
- Providing phase-by-phase template structures

The skill does NOT automatically determine who should fill each role — it provides the framework and templates that Thomas populates based on organizational structure and stakeholder analysis.

## Known Limitations

1. **Organizational complexity**: Matrix can become unwieldy with many roles and activities
2. **Role ambiguity**: Overlapping role definitions lead to confusion
3. **Cultural differences**: Accountability concepts may vary across cultures
4. **Staffing changes**: Matrix based on roles, not individuals; transitions need updates
5. **Over-complication**: Not every activity needs full RACI treatment; use judgment
6. **Static document**: Project dynamics may require frequent updates
7. **Stakeholder resistance**: Some stakeholders may resist being assigned "I" (informed only)
8. **Matrix sprawl**: Large projects may require multiple matrices by workstream or phase
9. **Not a substitute for communication**: Matrix does not replace regular engagement
