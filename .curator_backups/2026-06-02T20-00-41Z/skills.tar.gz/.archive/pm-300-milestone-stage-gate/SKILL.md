---
name: pm-300-milestone-stage-gate
description: Run stage gate reviews and milestone reviews — assess readiness to proceed, make go/no-go decisions, and formally document approvals.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, milestones, governance, stage-gate]
    trigger: [milestone review, stage gate, go no-go, gate review, phase review, checkpoint, milestone approval]
    trigger_context: "Thomas running a stage gate or milestone review — assessing if the project can proceed to the next phase"
---
# PM-300: Milestone & Stage Gate Reviews

## What
Run formal phase-end or milestone reviews to assess whether the project (or phase) is ready to proceed. Document go/no-go decisions, conditions, and approvals.

## Stage Gate Types
| Gate | Timing | Decision | Authority |
|------|--------|----------|-----------|
| **Gate 0** | Before project start | Authorize project | Sponsor/Steering |
| **Gate 1** | End of Initiation | Authorize planning | Sponsor |
| **Gate 2** | End of Planning | Authorize execution | Sponsor |
| **Gate 3** | End of Design | Authorize build | Sponsor + Technical |
| **Gate 4** | Go-Live | Authorize launch | Sponsor + Business |
| **Gate 5** | End of Closure | Close project | Sponsor |

## Gate Review Inputs
| Document | Gate 1 | Gate 2 | Gate 3 |
|----------|--------|--------|--------|
| Project charter | ✓ | | |
| Feasibility study | ✓ | | |
| Business case | ✓ | | |
| Requirements | | ✓ | |
| WBS | | ✓ | |
| Schedule | | ✓ | |
| Budget | | ✓ | |
| Risk register | | ✓ | ✓ |
| QA plan | | | ✓ |
| Design documents | | | ✓ |

## Gate Review Agenda (60 minutes)
| Time | Topic | Presenter |
|------|-------|-----------|
| 0-10min | Gate purpose and success criteria | PM |
| 10-30min | Deliverables status | PM/Team |
| 30-40min | Metrics review (schedule, budget, quality) | PM |
| 40-50min | Risks and issues | PM |
| 50-55min | Questions and discussion | All |
| 55-60min | Decision (Go/No-Go/Conditional) | Sponsor |

## Decision Outcomes
| Decision | Meaning | Next Step |
|----------|---------|-----------|
| **GO** | Ready to proceed | Sign gate record, start next phase |
| **NO-GO** | Significant issues must be resolved | List conditions, re-review date |
| **CONDITIONAL GO** | Minor items, proceed with conditions | List conditions, verify by date |
| **HOLD** | Major uncertainty, pause project | Reassess project viability |

## Step-by-Step SOP
1. **Prepare**: PM collects all gate inputs (see table above), drafts gate review package
2. **Distribute**: Send package to gate participants minimum 3 days before review
3. **Review**: Present status of each deliverable, metrics, risks
4. **Discuss**: Questions, concerns, conditions
5. **Decide**: Sponsor makes go/no-go/conditional/hold decision
6. **Document**: PM records decision, conditions, action items in gate record
7. **Communicate**: Notify team of decision and implications
8. **Follow up**: Verify conditions met by specified date if conditional

## Output: Gate Review Record
| Field | Value |
|-------|-------|
| Gate | Gate 2 (End of Planning) |
| Date | 2024-02-15 |
| Project | [Project Name] |
| Participants | Sponsor, PM, Tech Lead, BA |
| Decision | CONDITIONAL GO |
| Conditions | (1) Budget confirmed by Finance by 2024-02-18; (2) Risk register updated with vendor risks |
| Actions | PM to follow up on conditions by 2024-02-18 |
| Sign-off | [Sponsor signature] |

## Milestone Definition Template
| Milestone | Date | Success Criteria | Owner | Status |
|-----------|------|-----------------|-------|--------|
| M1: Design complete | 2024-04-01 | All design docs approved by Tech Lead | Dev Lead | ✓ Done |
| M2: Development complete | 2024-05-15 | Code merged, unit tests passing | Dev Lead | 🟡 In progress |
| M3: UAT sign-off | 2024-06-01 | 100% acceptance criteria met | Business | Pending |
| ... | ... | ... | ... | ... |

## Automation Tier
**Tier 2 — Accelerate**: Hermes can prepare gate review package (agenda, metrics summary, deliverable checklist), generate gate record document, and track condition completion.

## Limitations
- Decision authority must be human — cannot automate sponsor judgment
- Gate package quality depends on project documentation completeness
- Stalling gate reviews delays the project — set and keep review dates