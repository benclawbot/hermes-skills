---
name: pm-020-stakeholder-analysis
description: Identify all project stakeholders, assess their power, interest, influence, and develop engagement strategies for each group.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, stakeholder-management, stakeholder-analysis, engagement]
    trigger: [stakeholder analysis, stakeholder register, stakeholder mapping, power/interest grid, stakeholder engagement]
    trigger_context: "Thomas as Senior IT PM identifying and analyzing stakeholders for a project — mapping who has power, interest, and how to manage them"
---

# Stakeholder Analysis SOP

## What This SOP Does

The Stakeholder Analysis skill provides a systematic approach to identify, classify, assess, and plan engagement strategies for all project stakeholders. It ensures projects have comprehensive visibility into who can affect or is affected by the project, enabling appropriate management of expectations, requirements, and communications.

**Purpose:** Maximize stakeholder support and minimize stakeholder opposition through targeted engagement strategies based on each stakeholder's power, interest, and influence profile.

## Step-by-Step Process

### Step 1: Identify Stakeholders
- Review project charter and business case for named stakeholders
- Conduct stakeholder brainstorming sessions with project team
- Interview key sponsors and leadership about known stakeholders
- Review organizational charts and project dependency maps
- Document all individuals and groups with interest in or influence over the project
- Include both internal and external stakeholders

### Step 2: Classify Stakeholders
- Categorize by relationship type (sponsor, user, vendor, regulator, etc.)
- Group by organizational function or department
- Identify primary vs. secondary stakeholders
- Note any stakeholder groups with competing interests
- Document stakeholder categories: Individual, Group, Organization

### Step 3: Assess Stakeholder Power, Interest, and Influence
- Evaluate power level (high/medium/low): ability to approve/reject, allocate resources, change scope
- Evaluate interest level (high/medium/low): degree of impact from project outcomes
- Evaluate influence level (high/medium/low): ability to affect project decisions, resources, or timeline
- Assess current attitude (supportive/neutral/opposed)
- Identify potential for attitude change
- Determine urgency of engagement

### Step 4: Develop Engagement Strategies
- Map stakeholders to power/interest grid positions
- Define engagement approach per grid quadrant
- Set communication frequency and channel preferences
- Identify key messages and concerns to address
- Plan engagement activities (meetings, workshops, briefings)
- Assign relationship owners for each stakeholder group

### Step 5: Monitor and Update
- Review stakeholder register periodically (at each phase gate)
- Track engagement effectiveness through feedback
- Update assessments when circumstances change
- Add newly identified stakeholders promptly
- Retire stakeholders who are no longer relevant

## Power/Interest Grid Explanation

The power/interest grid positions stakeholders based on two dimensions:

```
                    HIGH INTEREST
                         │
         KEEP SATISFIED  │  MANAGE CLOSELY
    (High Power,         │  (High Power,
     Low Interest)       │   High Interest)
                         │
LOW POWER ───────────────┼────────────────── HIGH POWER
                         │
    MONITOR              │  KEEP INFORMED
(Low Power,              │  (High Interest,
 Low Interest)           │   Low Power)
                         │
                    LOW INTEREST
```

**Manage Closely (High Power, High Interest):** Engage actively, involve in decisions, seek regular input, address concerns immediately.

**Keep Satisfied (High Power, Low Interest):** Ensure they are kept informed of major decisions, provide summary updates, avoid over-communication.

**Keep Informed (Low Power, High Interest):** Provide regular project updates, solicit feedback, involve in user acceptance activities.

**Monitor (Low Power, Low Interest):** Provide basic project status, monitor for changes in their situation.

## Data Sources

- Project Charter: Identifies sponsors and key stakeholders
- Business Case: Outlines expected beneficiaries and affected parties
- Organizational Charts: Reveals reporting relationships and departments
- Procurement Documents: Vendor and contractor stakeholders
- Regulatory Documents: Compliance stakeholders
- Industry Standards: External stakeholder expectations

## Automation Tier

**Tier 2 — Accelerate**

This skill accelerates stakeholder analysis by:
- Generating stakeholder register templates
- Creating power/interest grid visualizations
- Formatting assessment findings into structured registers
- Tracking engagement activities and communications
- Alerting when stakeholder assessments need updates

Human analysis is required to accurately assess power dynamics, relationship nuances, and appropriate engagement intensity.

## Output: Stakeholder Register

```
STAKEHOLDER REGISTER
====================

Project Name: [Project Title]
Date: [Analysis Date]
Version: [X.X]
PM: [PM Name]

STAKEHOLDER MATRIX
------------------
| Name/Group | Role | Power | Interest | Influence | Attitude | Engagement Strategy | Frequency | Owner |
|------------|------|-------|----------|-----------|----------|---------------------|-----------|-------|
| [Name 1]   |      | H/M/L | H/M/L    | H/M/L     | S/N/O    |                     |           |       |
| [Name 2]   |      | H/M/L | H/M/L    | H/M/L     | S/N/O    |                     |           |       |
| [Name 3]   |      | H/M/L | H/M/L    | H/M/L     | S/N/O    |                     |           |       |

POWER/INTEREST GRID POSITIONS
------------------------------
Manage Closely:
- [Stakeholder 1]
- [Stakeholder 2]

Keep Satisfied:
- [Stakeholder 3]
- [Stakeholder 4]

Keep Informed:
- [Stakeholder 5]
- [Stakeholder 6]

Monitor:
- [Stakeholder 7]
- [Stakeholder 8]

ENGAGEMENT CALENDAR
-------------------
| Stakeholder | Activity | Date | Owner | Status |
|-------------|----------|------|-------|--------|
|             |          |      |       |        |

REGISTER UPDATES
----------------
| Date | Version | Changes | Updated By |
|------|---------|---------|------------|
|      |         |         |            |

Legend: Power (H/M/L), Interest (H/M/L), Influence (H/M/L), Attitude (S=Supportive, N=Neutral, O=Opposed)
```

## Known Limitations

- Stakeholder power dynamics can shift during project lifecycle
- Individual assessments may be subjective and require validation
- Some stakeholders may not be identifiable early in the project
- Hidden stakeholders (unknown parties with interest) may emerge later
- Stakeholder attitudes may change due to external factors beyond project control
- Competing priorities among stakeholders may create conflicting requirements
