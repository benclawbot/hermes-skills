---
name: pm-040-business-case
description: Document the strategic justification for a project including ROI, cost-benefit analysis, and alignment with organizational strategy.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, business-case, ROI, cost-benefit, investment-justification]
    trigger: [business case, ROI analysis, cost-benefit, investment justification, strategic alignment, value proposition]
    trigger_context: "Thomas as Senior IT PM building a business case to justify project investment — documenting expected returns, costs, and strategic value"
---

# Business Case Development SOP

## What This SOP Does

The Business Case skill provides a comprehensive methodology to document the strategic justification for a proposed project investment. It establishes the economic and strategic rationale by quantifying expected benefits, estimating costs, calculating financial returns, and demonstrating alignment with organizational strategy.

**Purpose:** Provide decision-makers with objective, data-driven justification for project investment, enabling informed prioritization and resource allocation decisions.

## Step-by-Step Process

### Step 1: Identify and Define the Business Need
- Document the specific business problem or opportunity being addressed
- Quantify the current state pain points (costs, inefficiencies, revenue gaps)
- Define the business context and market/competitive factors
- Identify who requested this and why (demand generation)
- Determine urgency and time-sensitivity of the need
- Confirm organizational strategic objectives this supports

### Step 2: Quantify Expected Benefits
- Identify tangible benefits (measurable in currency):
  - Cost reductions (labor, infrastructure, vendors)
  - Revenue increases (new products, efficiency, speed to market)
  - Cost avoidance (risk mitigation, compliance)
  - Productivity gains (FTE savings, cycle time reduction)
- Identify intangible benefits (difficult to quantify but valuable):
  - Customer satisfaction improvements
  - Employee morale and retention
  - Brand/reputation enhancement
  - Innovation capability
- Categorize benefits as one-time or recurring
- Assign confidence levels to benefit estimates

### Step 3: Estimate All Costs
- Capital Costs (one-time):
  - Software licensing/purchase
  - Hardware and infrastructure
  - Implementation services
  - Training and change management
  - Data migration
  - Contingency reserves
- Operating Costs (ongoing/recurring):
  - Annual maintenance and support
  - Subscription fees
  - Internal labor for operations
  - Utilities and facilities
  - Admin and overhead
- Lifecycle costs (full duration):
  - Calculate Total Cost of Ownership (TCO)
  - Define analysis period (typically 3-5 years)
  - Document any residual/salvage values

### Step 4: Calculate Financial Metrics
- **Net Present Value (NPV):**
  NPV = Sum of (Benefits - Costs) / (1 + discount_rate)^year
  Calculate for each year of analysis period; positive NPV indicates value creation

- **Internal Rate of Return (IRR):**
  The discount rate at which NPV = 0
  Higher IRR indicates better investment; compare to hurdle rate

- **Payback Period:**
  Time required to recover initial investment
  Calculate cumulative cash flow until Breakeven point

- **Return on Investment (ROI):**
  ROI = (Total Benefits - Total Costs) / Total Costs × 100%
  Express as percentage; higher ROI indicates better return

### Step 5: Document Strategic Alignment
- Map project outcomes to strategic objectives
- Identify competitive advantages gained
- Document compliance/regulatory alignment
- Note organizational capability improvements
- Quantify strategic optionality (future flexibility)

### Step 6: Assess and Document Risks
- Financial risks (cost overruns, benefit shortfalls)
- Implementation risks (schedule, technical)
- Operational risks (adoption, training)
- External risks (market, regulatory)
- Document risk mitigation approaches

### Step 7: Compare Alternatives
- Document do-nothing option (status quo)
- Document alternative approaches considered
- Compare cost/benefit profiles of alternatives
- Recommend preferred option with rationale

### Step 8: Present Recommendation
- Synthesize analysis into clear recommendation
- Summarize key findings and metrics
- Highlight key assumptions and dependencies
- Present sensitivity analysis for critical variables
- Provide go/no-go recommendation

## Data Sources

- Project Charter: Scope, timeline, and resource requirements
- Feasibility Study: Technical, operational, and schedule assessments
- Financial Historical Data: Cost baselines, labor rates, vendor pricing
- Stakeholder Input: Business unit expectations, user needs
- Organizational Strategy: Strategic plans, priorities, budget guidance
- Market Analysis: Industry benchmarks, competitive data
- Historical Project Data: Actual costs and benefits from similar projects

## Cost-Benefit Analysis Template

```
COST-BENEFIT ANALYSIS
====================

Project Name: [Project Title]
Analysis Date: [Date]
Analyst: [Name]
Analysis Period: [X years]
Discount Rate: [X%]

TANGIBLE BENEFITS
-----------------
| Benefit | Category | One-Time/Recurring | Year 1 | Year 2 | Year 3 | Total |
|---------|----------|-------------------|--------|--------|--------|-------|
|         | Cost Reduction |              |        |        |        |       |
|         | Revenue Increase|              |        |        |        |       |
|         | Cost Avoidance  |              |        |        |        |       |
|         | Productivity    |              |        |        |        |       |
| TOTAL TANGIBLE |          |              |        |        |        |       |

INTANGIBLE BENEFITS
-------------------
| Benefit | Description | Estimated Value Range | Confidence |
|---------|-------------|------------------------|------------|
|          |             |                        |            |
|          |             |                        |            |

TOTAL BENEFITS
--------------
| Type | Value |
|------|-------|
| Tangible (NPV) | $[Amount] |
| Intangible | [Description] |
| Total | |

COST CATEGORIES
---------------
Capital Costs (One-Time):
| Category | Amount | Timing |
|----------|--------|--------|
| Software |        |        |
| Hardware |        |        |
| Services |        |        |
| Training |        |        |
| Other    |        |        |
| Contingency |     |        |
| Subtotal |        |        |

Operating Costs (Recurring):
| Category | Annual Cost | Years | Total |
|----------|-------------|-------|-------|
| Maintenance |          |       |       |
| Subscriptions|          |       |       |
| Labor       |           |       |       |
| Other       |           |       |       |
| Subtotal    |           |       |       |

TOTAL COST OF OWNERSHIP
------------------------
| Component | Amount |
|-----------|--------|
| Capital Costs | $[Amount] |
| Operating Costs | $[Amount] |
| Total TCO | $[Amount] |

NET VALUE
---------
| Metric | Value |
|--------|-------|
| Total Benefits (NPV) | $[Amount] |
| Total Costs (NPV) | $[Amount] |
| Net Value | $[Amount] |
```

## Financial Metrics Formulas

### Net Present Value (NPV)
```
NPV = Sum [t=1 to n] (Bt - Ct) / (1 + r)^t

Where:
Bt = Benefits in year t
Ct = Costs in year t
r = Discount rate
n = Number of years
```

### Internal Rate of Return (IRR)
```
IRR is the rate where NPV = 0
Calculate by solving:
0 = Sum [t=1 to n] (Bt - Ct) / (1 + IRR)^t
```

### Payback Period
```
Payback Period = Year before breakeven + (Unrecovered cost at start of year / Cash flow during year)
```

### Return on Investment (ROI)
```
ROI = (Total Benefits - Total Costs) / Total Costs × 100%
```

## Automation Tier

**Tier 2 — Accelerate**

This skill accelerates business case development by:
- Generating structured cost-benefit analysis templates
- Performing NPV, IRR, and payback period calculations
- Compiling and formatting financial data
- Comparing alternatives in structured format
- Managing document versioning and review workflow

Human judgment is required to validate benefit estimates, assess confidence levels, make qualitative strategic arguments, and present recommendations persuasively.

## Output: Business Case Document Template

```
BUSINESS CASE
=============

1. EXECUTIVE SUMMARY
--------------------
Project Name: [Project Title]
Date: [Date]
Prepared By: [Name, Title]
Recommendation: [Proceed/Modify/Defer/Decline]

Key Metrics:
- Total Investment: $[Amount]
- Expected NPV: $[Amount]
- IRR: [%]
- Payback Period: [X months/years]
- ROI: [%]

2. BUSINESS NEED
----------------
Problem/Opportunity Statement:
[Clear statement of the business issue or opportunity]

Current State:
[Description of existing situation and pain points]

Future State:
[Description of expected improvements]

Strategic Alignment:
- Objective 1: [How project supports]
- Objective 2: [How project supports]

3. OPTIONS ANALYSIS
-------------------
Option A: [Do Nothing]
- Costs: $[Amount]
- Benefits: None
- Risks: [Description of risk of inaction]

Option B: [Proposed Solution] - RECOMMENDED
- Costs: $[Amount]
- Benefits: $[Amount]
- Risks: [Description]

Option C: [Alternative] - CONSIDERED
- Costs: $[Amount]
- Benefits: $[Amount]
- Risks: [Description]

Comparison Summary:
| Criteria | Option A | Option B | Option C |
|----------|----------|----------|----------|
| NPV     |          |          |          |
| IRR     |          |          |          |
| Payback |          |          |          |
| Risk    |          |          |          |
| Strategic Fit |    |          |          |

4. COST-BENEFIT ANALYSIS
------------------------
[Insert completed Cost-Benefit Analysis template above]

5. FINANCIAL ANALYSIS
----------------------
NPV: $[Amount] (at [X%] discount rate)
IRR: [%]
Payback Period: [X months/years]
ROI: [%]

Sensitivity Analysis:
| Variable | Base Case | Optimistic | Pessimistic |
|----------|-----------|------------|-------------|
| Benefits |           |            |             |
| Costs    |           |            |             |
| Timeline |           |            |             |

6. RISK ASSESSMENT
------------------
| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
|      |             |        |            |

7. ASSUMPTIONS AND DEPENDENCIES
--------------------------------
Key Assumptions:
| Assumption | Impact if Incorrect |
|------------|---------------------|
|            |                     |

Dependencies:
| Dependency | Owner | Status |
|------------|-------|--------|
|            |       |        |

8. RECOMMENDATION
-----------------
[Clear recommendation with supporting rationale]

Key Success Factors:
- [Factor 1]
- [Factor 2]

Critical Risks to Mitigate:
- [Risk 1]
- [Risk 2]

9. APPROVAL
-----------
| Role | Name | Decision | Signature | Date |
|------|------|----------|-----------|------|
| Sponsor |      |          |           |      |
| Finance  |      |          |           |      |
| Executive|      |          |           |      |
```

## Known Limitations

- Benefit estimates are projections based on assumptions; actual results may vary
- Cost estimates have inherent uncertainty, especially for new technologies
- ROI calculations are sensitive to discount rate and timeline assumptions
- Intangible benefits are difficult to quantify and validate
- External factors (market conditions, regulatory changes) may affect outcomes
- Comparison with alternatives may be limited by available data
- Business case represents point-in-time analysis; updates may be needed
