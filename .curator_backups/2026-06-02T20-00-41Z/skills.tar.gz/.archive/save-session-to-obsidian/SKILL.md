---
name: save-session-to-obsidian
description: Save Hermes session transcripts to Obsidian as daily conversation summaries. Session files are detected automatically by a watchdog cron job and written to $OBSIDIAN_VAULT_PATH/Conversations/YYYY/YYYY-MM/YYYY-MM-DD.md. Multiple sessions on the same day are appended to the same file (not overwritten) with time-stamped session markers. Designed to be fully automatic — no manual steps required.
version: 1.3.0
---

# Save Session to Obsidian

Session transcripts are detected and written automatically. Manual steps are only needed if the watchdog is not running.

## Architecture

```
Hermes session ends (any way: /quit, Ctrl+C, exit)
  → ~/.hermes/sessions/
       ├── saved/hermes_conversation_YYYYMMDD_HHMMSS.json  (Telegram)
       ├── session_YYYYMMDD_HHMMSS_id.json                  (CLI interactive)
       ├── session_bg_HHMMSS_id.json                         (CLI background/terminal)
       └── session_cron_JOBID_YYYYMMDD_HHMMSS.json           (cron subagent)
  → watch_sessions.py (cron, every 15 min)
  → $OBSIDIAN_VAULT_PATH/Conversations/YYYY/YYYY-MM/YYYY-MM-DD.md
  → Conversations/README.md index updated
```

**All 4 formats are monitored.** Source is auto-detected and labeled in output: `📱 TELEGRAM` for `hermes_conversation_*`, `💻 CLI` for everything else. Topic heading and session marker both carry the source label.

## Key design decisions

**`/save` does NOT write to Obsidian.** It saves a local JSON transcript to `~/.hermes/sessions/saved/`. The watchdog then picks it up within 15 min and writes to Obsidian. Do not rely on `/save` as a manual Obsidian save — it's a local transcript only.

**Cron watchdog, NOT manual invocation.** First version required `/skill save-session-to-obsidian` then `/quit`. User rejected this — "I'm not going to call manually the skill then exit." Automation via `watch_sessions.py` running as a no_agent cron job is the correct pattern.

**Append, don't overwrite.** Multiple sessions per day accumulate in the same file, each with a `### Session HH:MM [source]` marker. Overwriting (old → new) loses data.

**State tracking.** `~/.hermes/sessions/.session_watchdog_state` tracks processed files — prevents re-processing on re-runs. Uses `fcntl.flock` for concurrency safety.

**Watchdog frequency:** Every 15 minutes. Sufficient — sessions appear in the filesystem within seconds of ending, 15 min is an acceptable lag.

## Session file formats

| Pattern | Source | Date extraction | Time extraction |
|---------|--------|-----------------|-----------------|
| `hermes_conversation_YYYYMMDD_HHMMSS.json` | Telegram | `re.search(r'(\d{8})')` | `re.search(r'_(\d{2})(\d{2})(\d{2})(?:_\w+)?$')` |
| `session_YYYYMMDD_HHMMSS_id.json` | CLI | `re.search(r'(\d{8})')` | `re.search(r'_(\d{2})(\d{2})(\d{2})(?:_\w+)?$')` |
| `session_bg_HHMMSS_id.json` | background | fallback → mtime | same regex |
| `session_cron_JOBID_YYYYMMDD_HHMMSS.json` | cron subagent | `re.search(r'(\d{8})')` | same regex |

**Date:** Parsed from `YYYYMMDD` anywhere in filename — do not assume fixed position. Falls back to file `mtime` if no date found.

**Time:** HHMMSS extracted from the end of the stem using `re.search(r'_(\d{2})(\d{2})(\d{2})(?:_\w+)?$')` which handles all four formats. The session marker format is `### Session HH:MM`.

## Ctrl+C / incomplete file handling

When a session ends abruptly (Ctrl+C, signal kill), the JSON file may be half-written or truncated. `watch_sessions.py` guards against this with `is_json_valid(filepath)` — a full `json.load()` parse test. Files that fail are:
- Skipped silently
- Recorded in the state file so they are not re-checked every tick

The watchdog will not re-process corrupt/incomplete files on subsequent runs.

## Scripts

| Script | Purpose |
|--------|---------|
| `scripts/watch_sessions.py` | Watchdog — run via cron, detects new sessions, writes to Obsidian |
| `scripts/save_session.py` | Manual one-shot — parses a session file and writes summary (no state tracking) |

## Cron job setup

**⚠️ The scheduler prepends `~/.hermes/scripts/` to the script path** and splits on spaces. You CANNOT pass `python3 /full/path` — it becomes `/home/user/.hermes/scripts/python3 /full/path`. Instead, create a wrapper shell script in `~/.hermes/scripts/` and pass its name only:

```bash
# Create wrapper (one-time)
cat > ~/.hermes/scripts/watch_sessions.sh << 'EOF'
#!/bin/bash
exec python3 /home/thomas/.hermes/skills/note-taking/save-session-to-obsidian/scripts/watch_sessions.py
EOF
chmod +x ~/.hermes/scripts/watch_sessions.sh

# Create cron job — use WRAPPER NAME only, no spaces
hermes cron create "*/15 * * * *" \
  --script "watch_sessions.sh" \
  --name "session-to-obsidian watchdog" \
  --no-agent
```

## Troubleshooting

**Sessions not appearing in Obsidian:**
1. Check cron is running: `hermes cron list`
2. Check state file exists: `cat ~/.hermes/sessions/.session_watchdog_state`
3. Check session files exist: `ls ~/.hermes/sessions/`
4. Run watchdog manually: `python3 ~/.hermes/skills/note-taking/save-session-to-obsidian/scripts/watch_sessions.py`
5. Check cron output for `Script not found` — if seen, the wrapper script is missing or the job uses a spaced command instead of the wrapper name

**Duplicate entries in README:** Safe to re-run — README update is idempotent (checks if date already linked before adding).

## Manual override

If the cron fails or you want to save immediately without waiting 15 min:

```bash
python3 ~/.hermes/skills/note-taking/save-session-to-obsidian/scripts/save_session.py
```

Does NOT use state tracking — always writes/overwrites a single session to Obsidian.