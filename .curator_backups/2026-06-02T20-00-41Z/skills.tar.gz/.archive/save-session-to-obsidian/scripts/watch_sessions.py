#!/usr/bin/env python3
"""
Watchdog: monitors ~/.hermes/sessions/saved/ for new Hermes session files.
On new files, generates and writes a summary to Obsidian.
Maintains state in ~/.hermes/sessions/.session_watchdog_state to avoid re-processing.
Designed to run as a no_agent=true cron job — stdout is the delivery mechanism.
"""

import json
import os
import sys
import fcntl
import time
from datetime import datetime
from pathlib import Path

VAULT_BASE = Path(os.environ.get("OBSIDIAN_VAULT_PATH", Path.home() / "Dropbox/memory/Obsidian"))
SESSIONS_DIR = Path.home() / ".hermes/sessions"
STATE_FILE = Path.home() / ".hermes/sessions/.session_watchdog_state"
CONV_DIR = VAULT_BASE / "Conversations"
README_PATH = CONV_DIR / "README.md"


def load_state():
    if STATE_FILE.exists():
        with open(STATE_FILE) as f:
            fcntl.flock(f.fileno(), fcntl.LOCK_SH)
            data = json.load(f)
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)
            return set(data)
    return set()


def save_state(processed):
    with open(STATE_FILE, "w") as f:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        json.dump(sorted(processed), f)
        fcntl.flock(f.fileno(), fcntl.LOCK_UN)


def find_new_sessions(processed):
    """Return list of unprocessed session files, newest first.
    Covers both telegram (hermes_conversation_*.json) and cli (session_*.json)."""
    # Also check sessions/saved/ for hermes_conversation_*.json (Telegram)
    saved_dir = SESSIONS_DIR / "saved"
    sessions = sorted(
        list(saved_dir.glob("hermes_conversation_*.json")) +
        list(SESSIONS_DIR.glob("session_*.json")) +
        list(SESSIONS_DIR.glob("session_bg_*.json")),
        key=lambda f: f.stat().st_mtime,
        reverse=True
    )
    return [f for f in sessions if f.name not in processed]


def parse_session(filepath):
    with open(filepath) as f:
        data = json.load(f)
    messages = []
    for msg in data.get("messages", []):
        role = msg.get("role", "")
        content = msg.get("content", "")
        if role in ("user", "assistant") and content:
            messages.append((role, content))
    return messages


def truncate(content, max_chars=700):
    if len(content) <= max_chars:
        return content
    return content[:max_chars].rsplit(" ", 1)[0] + "…"


def get_source_from_session(filepath):
    """Detect session source from filename."""
    name = filepath.name
    if name.startswith("hermes_conversation_"):
        return "telegram"
    return "cli"

def generate_summary(messages, source="telegram"):
    if not messages:
        return None
    icon = "📱" if source == "telegram" else "💻"
    topic = truncate(messages[0][1], 100)
    lines = [f"## Topic [{icon} {source.upper()}]\n{topic}"]

    sampled = []
    if len(messages) >= 2:
        sampled.append(f"- You: {truncate(messages[0][1], 200)}")
        sampled.append(f"- Assistant: {truncate(messages[1][1], 200)}")
    if len(messages) > 4:
        sampled.append(f"- … Assistant: {truncate(messages[len(messages)//2][1], 200)}")
    if len(messages) > 2:
        for role, content in reversed(messages):
            if role == "user":
                sampled.append(f"- You (end): {truncate(content, 200)}")
                break

    lines.append("\n## Key exchanges")
    lines.extend(sampled[:6])
    return "\n".join(lines)


def get_date_from_session(filepath):
    """Extract date from session filename. Handles multiple formats:
    - session_YYYYMMDD_HHMMSS_id.json (CLI)
    - session_bg_HHMMSS_id.json (background)
    - session_cron_JOBID_YYYYMMDD_HHMMSS.json (cron)
    - hermes_conversation_YYYYMMDD_HHMMSS.json (Telegram legacy)
    """
    name = filepath.stem
    import re
    # Match YYYYMMDD anywhere in filename
    m = re.search(r'(\d{8})', name)
    if m:
        try:
            return datetime.strptime(m.group(1), "%Y%m%d")
        except ValueError:
            pass
    # Fallback: mtime
    return datetime.fromtimestamp(filepath.stat().st_mtime)


def write_to_obsidian(date, summary_text, session_file=None):
    year = date.strftime("%Y")
    month = date.strftime("%Y-%m")
    day = date.strftime("%Y-%m-%d")
    month_dir = CONV_DIR / year / month
    month_dir.mkdir(parents=True, exist_ok=True)
    filepath = month_dir / f"{day}.md"

    session_marker = ""
    if session_file:
        source = get_source_from_session(session_file)
        icon = "📱" if source == "telegram" else "💻"
        import re
        name = session_file.stem
        # session_YYYYMMDD_HHMMSS_id.json or hermes_conversation_YYYYMMDD_HHMMSS.json
        m = re.search(r'_(\d{2})(\d{2})(\d{2})(?:_\w+)?$', name)
        if m:
            hh, mm = m.group(1), m.group(2)
            session_marker = f"\n\n---\n### Session {hh}:{mm} [{icon} {source.upper()}]\n"

    content = f"{session_marker}{summary_text}\n"

    if filepath.exists():
        with open(filepath, "a") as f:
            f.write(content)
    else:
        with open(filepath, "w") as f:
            f.write(f"# Conversation — {day}\n{content}")

    return filepath


def update_readme(date):
    day = date.strftime("%Y-%m-%d")
    year = date.strftime("%Y")
    month = date.strftime("%Y-%m")
    link = f"- [[Conversations/{year}/{month}/{day}|{day}]]"

    if not README_PATH.exists():
        return

    with open(README_PATH) as f:
        readme = f.read()

    if day in readme:
        return

    lines = readme.split("\n")
    new_lines = []
    inserted = False
    for i, line in enumerate(lines):
        new_lines.append(line)
        if f"### {year}" in line and not inserted:
            for j in range(i + 1, len(lines)):
                if lines[j].startswith("### 20"):
                    new_lines.insert(j, link)
                    inserted = True
                    break
            if not inserted:
                new_lines.append(link)
                inserted = True

    if not inserted:
        new_lines.append(link)

    with open(README_PATH, "w") as f:
        f.write("\n".join(new_lines))


def is_json_valid(filepath):
    """Check if a file contains valid, complete JSON."""
    try:
        with open(filepath) as f:
            json.load(f)
        return True
    except (json.JSONDecodeError, UnicodeDecodeError):
        return False

def process_session(filepath, processed_state=None):
    # Skip incomplete/corrupt files (e.g. Ctrl+C mid-write)
    if not is_json_valid(filepath):
        print(f"SKIP (incomplete/corrupt): {filepath.name}", file=sys.stderr)
        # Record in state so we don't re-check every tick
        if processed_state is not None:
            processed_state.add(filepath.name)
        return None
    messages = parse_session(filepath)
    if not messages:
        return None
    source = get_source_from_session(filepath)
    date = get_date_from_session(filepath)
    summary_text = generate_summary(messages, source)
    filepath_written = write_to_obsidian(date, summary_text, filepath)
    update_readme(date)
    return str(filepath_written)


def main():
    state = load_state()
    new_sessions = find_new_sessions(state)

    if not new_sessions:
        print("NO_NEW_SESSIONS")
        return

    written = []
    for session_file in new_sessions:
        try:
            result = process_session(session_file, state)
            if result:
                state.add(session_file.name)
                written.append(result)
        except Exception as e:
            print(f"ERROR processing {session_file.name}: {e}", file=sys.stderr)

    save_state(state)

    if written:
        print(f"PROCESSED:{len(written)}")
        for w in written:
            print(w)
    else:
        print("NO_NEW_SESSIONS")


if __name__ == "__main__":
    main()
