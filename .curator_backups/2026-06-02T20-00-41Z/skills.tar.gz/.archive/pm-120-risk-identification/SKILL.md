---
name: pm-120-risk-identification
description: Identify, categorize, and score project risks using structured techniques to build a comprehensive risk register.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, risk-management]
    trigger: [risk register, risk identification, risk scoring, risk assessment, risk likelihood, risk impact, risk matrix]
    trigger_context: "Thomas identifying and scoring project risks — building a risk register with likelihood, impact, and mitigation plans"
---
# PM-120: Risk Identification

## What
Systematically identify all project risks, categorize them, score them by likelihood and impact, and document them in a risk register.

## Risk Categories
- **Strategic**: alignment with business strategy, organizational change
- **Operational**: day-to-day execution, process, people
- **Financial**: budget, cost overrun, funding, currency
- **Technical**: technology, architecture, integration, performance
- **Compliance**: regulatory, legal, security, privacy
- **External**: market, vendor, weather, geopolitical

## Identification Techniques
| Technique | Best for |
|-----------|----------|
| Brainstorming | Team-based, cross-functional risks |
| Delphi | Anonymous consensus, avoids groupthink |
| SWOT | Link organizational strengths/weaknesses to project threats |
| Checklist | Reuse from previous projects (PMBOK, industry) |
| Assumption analysis | Find contradictions in stated assumptions |
| FMEA (Failure Mode) | Technical/engineering risks |

## Scoring Matrix
Score = Likelihood (1–5) × Impact (1–5)

| Score | Band | Action |
|-------|------|--------|
| 15–25 | **High** | Immediate mitigation required |
| 6–14  | **Medium** | Monitor and plan response |
| 1–5   | **Low** | Accept or watch |

## Likelihood Scale
| Rating | Label | Description |
|--------|-------|-------------|
| 1 | Rare | May occur only in exceptional circumstances |
| 2 | Unlikely | Probably will not occur |
| 3 | Possible | Might occur at some point |
| 4 | Likely | Will probably occur |
| 5 | Almost Certain | Expected to occur |

## Impact Scale
| Rating | Label | Description |
|--------|-------|-------------|
| 1 | Negligible | Minor delay, <5% budget overrun |
| 2 | Minor | 5-10% budget overrun, short delay |
| 3 | Moderate | 10-20% budget overrun, milestone missed |
| 4 | Major | 20-40% budget overrun, key stakeholder impact |
| 5 | Catastrophic | >40% budget overrun, project cancellation |

## Step-by-Step SOP
1. **Prepare**: Collect project documents (charter, WBS, stakeholder register, assumptions)
2. **Identify**: Apply 2-3 techniques (brainstorming + checklist + assumption analysis)
3. **Categorize**: Assign each risk to a category (Strategic, Operational, etc.)
4. **Score**: Assign Likelihood (1-5) and Impact (1-5), calculate Score
5. **Rank**: Sort by Score descending, focus on High and Medium
6. **Document**: Fill risk register — one row per risk
7. **Validate**: Review with project team and sponsor
8. **Review**: Re-assess at each phase gate or monthly

## Output: Risk Register
| ID | Description | Category | Likelihood | Impact | Score | Owner | Trigger | Mitigation |
|----|-------------|----------|-----------|--------|-------|-------|---------|------------|
| R-001 | Key developer leaves mid-project | Operational | 3 | 4 | 12 | Thomas | Notice given | Knowledge transfer, documentation, backup resource |
| R-002 | Third-party API deprecation | Technical | 2 | 4 | 8 | Dev Lead | API changelog | Abstraction layer, alternative vendor identified |
| ... | ... | ... | ... | ... | ... | ... | ... | ... |

## Data Sources
- Project charter
- WBS and activity list
- Stakeholder register
- Industry risk checklists
- Team inputs via workshop

## Automation Tier
**Tier 1 — Eliminate**: Hermes can draft a risk register from project type + team inputs, applying standard risk checklists and scoring. Human validates and adjusts.

## Limitations
- Risk identification is inherently limited by experience and imagination of participants
- Some risks are "unknown unknowns" — cannot be fully anticipated
- Scores are subjective; calibration workshops improve accuracy