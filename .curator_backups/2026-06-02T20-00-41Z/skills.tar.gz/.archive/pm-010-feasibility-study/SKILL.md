---
name: pm-010-feasibility-study
description: Conduct feasibility assessment across technical, economic, legal, operational, and schedule dimensions for a new project initiative.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, feasibility, assessment, go-no-go, investment-appraisal]
    trigger: [feasibility study, feasibility assessment, project viability, go/no-go, investment appraisal]
    trigger_context: "Thomas as Senior IT PM evaluating whether a new project should proceed — checking viability before commitment"
---

# Feasibility Study SOP

## What This SOP Does

The Feasibility Study skill provides a structured methodology to assess whether a proposed project initiative is viable across five critical dimensions before committing resources. It evaluates technical capability, economic justification, legal compliance, operational readiness, and scheduling realism to support go/no-go decision-making.

**Purpose:** Ensure projects are only initiated when there is sufficient evidence of success probability across all dimensions, reducing wasted investment and stakeholder disappointment.

## Step-by-Step Process

### Step 1: Technical Feasibility Assessment
- Evaluate whether the organization has or can acquire the necessary technology stack
- Assess technical staff skills and capacity against project requirements
- Review infrastructure adequacy (hardware, network, cloud resources)
- Identify technical dependencies and their maturity levels
- Document any technology risks or unknowns

### Step 2: Economic Feasibility Assessment
- Quantify estimated project costs (development, implementation, ongoing operations)
- Identify expected financial benefits (cost savings, revenue generation, efficiency gains)
- Calculate preliminary ROI indicators (NPV, IRR, Payback Period)
- Compare against budget constraints and organizational financial thresholds
- Assess economic risks including cost overrun potential

### Step 3: Legal Feasibility Assessment
- Review regulatory compliance requirements applicable to the project
- Assess contractual obligations and vendor dependencies
- Evaluate data privacy and security compliance needs
- Identify intellectual property considerations
- Document any legal constraints or pending regulatory changes

### Step 4: Operational Feasibility Assessment
- Evaluate organizational readiness and change management capacity
- Assess impact on current business processes and operations
- Determine user acceptance and adoption likelihood
- Review training and support requirements
- Identify operational risks during and after implementation

### Step 5: Schedule Feasibility Assessment
- Develop preliminary timeline based on scope and resource estimates
- Identify critical milestones and dependencies
- Assess whether timeline aligns with business needs and deadlines
- Evaluate resource availability against timeline requirements
- Identify schedule risks and constraints

## Data Sources

- Project Brief: Initial statement of project need and high-level scope
- Business Requirements: Detailed functional and non-functional requirements
- Stakeholder Input: Expectations, constraints, and priorities from key stakeholders
- Historical Data: Lessons learned from similar past projects
- Market Analysis: Technology trends and vendor landscape information

## Automation Tier

**Tier 2 — Accelerate**

This skill accelerates feasibility assessment by:
- Generating structured assessment templates
- Compiling data collection checklists
- Formatting findings into the standard report structure
- Calculating preliminary ROI metrics
- Managing review and approval workflow

Human judgment remains essential for weighing dimensional findings and making final go/no-go recommendations.

## Output: Feasibility Study Report

```
FEASIBILITY STUDY REPORT
========================

Project Name: [Project Title]
Date: [Assessment Date]
Prepared By: [PM Name]
Status: [Draft/Final]

EXECUTIVE SUMMARY
-----------------
[2-3 sentence overview of project and overall feasibility determination]

TECHNICAL FEASIBILITY
--------------------
Assessment: [Feasible/Conditionally Feasible/Not Feasible]
Findings:
- [Technical finding 1]
- [Technical finding 2]
Key Risks:
- [Risk 1 with mitigation approach]

ECONOMIC FEASIBILITY
-------------------
Assessment: [Feasible/Conditionally Feasible/Not Feasible]
Estimated Costs: $[Amount]
Estimated Benefits: $[Amount]
Preliminary ROI: [%]
Payback Period: [Months/Years]
Key Risks:
- [Risk 1 with mitigation approach]

LEGAL FEASIBILITY
----------------
Assessment: [Feasible/Conditionally Feasible/Not Feasible]
Compliance Requirements:
- [Requirement 1]
- [Requirement 2]
Key Risks:
- [Risk 1 with mitigation approach]

OPERATIONAL FEASIBILITY
----------------------
Assessment: [Feasible/Conditionally Feasible/Not Feasible]
Change Readiness: [High/Medium/Low]
Training Needs: [Description]
Key Risks:
- [Risk 1 with mitigation approach]

SCHEDULE FEASIBILITY
-------------------
Assessment: [Feasible/Conditionally Feasible/Not Feasible]
Estimated Duration: [X months]
Key Milestones:
- [Milestone 1: Date]
- [Milestone 2: Date]
Key Risks:
- [Risk 1 with mitigation approach]

OVERALL RECOMMENDATION
---------------------
[Go/No-Go/Conditional Go with conditions]
Rationale:
[Detailed justification for recommendation]

NEXT STEPS
----------
- [Action 1]
- [Action 2]

APPROVALS
---------
Prepared By: _________________ Date: _______
Reviewed By: _________________ Date: _______
Approved By: _________________ Date: _______
```

## Known Limitations

- Preliminary cost estimates may differ significantly from final project costs
- Schedule estimates based on limited information are inherently uncertain
- Technology landscape changes may affect feasibility between assessment and execution
- Cross-functional dependencies may not be fully visible at this stage
- Stakeholder input may be incomplete if key stakeholders are not yet engaged
