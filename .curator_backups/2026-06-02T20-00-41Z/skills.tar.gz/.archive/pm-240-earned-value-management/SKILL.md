---
name: pm-240-earneds-value-management
description: Calculate Earned Value Management (EVM) metrics — PV, EV, AC, CV, SV, CPI, SPI — and produce a dashboard of project health.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, EVM, earned-value, KPIs, monitoring]
    trigger: [EVM, earned value management, CPI, SPI, schedule variance, cost variance, project health, PV, EV, AC]
    trigger_context: "Thomas calculating EVM metrics — cost variance, schedule variance, CPI, SPI to assess project health"
---
# PM-240: Earned Value Management (EVM)

## What
Measure project performance using earned value metrics — Planned Value (PV), Earned Value (EV), Actual Cost (AC), Cost Variance (CV), Schedule Variance (SV), Cost Performance Index (CPI), Schedule Performance Index (SPI).

## Core Formulas

### Earned Value (EV)
> EV = % complete × Total Budget
> e.g., 60% of €200,000 project = €120,000 EV

### Planned Value (PV)
> PV = planned % complete × Total Budget
> e.g., Should be 70% complete at end of Week 6 = €140,000 PV

### Cost Variance (CV)
> CV = EV - AC
> Positive = under budget | Negative = over budget

### Schedule Variance (SV)
> SV = EV - PV
> Positive = ahead of schedule | Negative = behind schedule

### Cost Performance Index (CPI)
> CPI = EV / AC
> >1 = under budget | <1 = over budget | =1 = on budget

### Schedule Performance Index (SPI)
> SPI = EV / PV
> >1 = ahead | <1 = behind | =1 = on schedule

### Estimate at Completion (EAC)
| Method | Formula | When to use |
|--------|---------|-------------|
| Current burn rate | AC + (BAC - EV) / CPI | CPI is expected to continue |
| Typical trend | AC + (BAC - EV) / (CPI × SPI) | Schedule also a factor |
| Bottom-up | Re-estimate remaining work | Significant scope change |

### To-Complete Performance Index (TCPI)
> TCPI = (BAC - EV) / (BAC - AC)
> What CPI must be to finish on budget

## EVM Dashboard Thresholds
| Metric | Green | Yellow | Red |
|--------|-------|--------|-----|
| CPI | ≥ 0.95 | 0.90-0.94 | < 0.90 |
| SPI | ≥ 0.95 | 0.90-0.94 | < 0.90 |
| CV | ≥ -5% of BAC | -5% to -10% | < -10% |
| SV | ≥ -5% of PV | -5% to -10% | < -10% |

## Step-by-Step SOP
1. **Establish baseline**: Total Budget (BAC), planned schedule (dates), work breakdown
2. **Measure progress**: For each WBS element, determine % complete
3. **Calculate EV**: Apply % complete to BAC for each element, sum
4. **Get AC**: Actual cost spent to date from financial system
5. **Calculate PV**: What was planned to be done by today (from schedule)
6. **Compute variances**: CV, SV, CPI, SPI
7. **Forecast EAC**: Project remaining work based on current performance
8. **Assess health**: Compare to thresholds — Green/Yellow/Red
9. **Report**: Dashboard + narrative — what's happening, why, what it means

## Output: EVM Dashboard
| Metric | Formula | Value | Status |
|--------|---------|-------|--------|
| Total Budget (BAC) | | €200,000 | |
| Planned Value (PV) | | €140,000 | |
| Earned Value (EV) | | €120,000 | |
| Actual Cost (AC) | | €130,000 | |
| Cost Variance (CV) | EV - AC | -€10,000 | 🔴 |
| Schedule Variance (SV) | EV - PV | -€20,000 | 🔴 |
| CPI | EV/AC | 0.92 | 🟡 |
| SPI | EV/PV | 0.86 | 🔴 |
| EAC | BAC/CPI | €217,391 | 🔴 |
| TCPI | (BAC-EV)/(BAC-AC) | 1.14 | 🟡 |

## Output: EVM Narrative
> **Project is $10K over budget and 2 weeks behind schedule. CPI of 0.92 means we are spending 8% more per unit of work than planned. SPI of 0.86 means we are completing only 86% of planned work per time period. At current pace, EAC is €217,391 (vs. BAC €200,000). Recommend: reduce scope by 10 story points to bring EAC back in line, or request additional €17,391 from sponsor.**

## Data Sources
- Project baseline (BAC, schedule)
- Progress reports (% complete per WBS element)
- Financial system (actual costs to date)

## Automation Tier
**Tier 1 — Eliminate**: Hermes calculates all EVM metrics from raw data inputs (BAC, % complete, actual cost). Generates dashboard and narrative automatically.

## Limitations
- EVM requires disciplined progress measurement — garbage in, garbage out
- Not all project types suit EVM (agile projects often use burndown instead)
- % complete estimation is subjective — use with other metrics