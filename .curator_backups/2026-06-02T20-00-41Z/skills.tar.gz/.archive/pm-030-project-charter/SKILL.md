---
name: pm-030-project-charter
description: Develop and formally authorize a project charter that defines project purpose, objectives, scope, governance, and the PM's authority.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, project-charter, authorization, governance, initiation]
    trigger: [project charter, charter development, project authorization, project sponsor, charter sign-off]
    trigger_context: "Thomas as Senior IT PM drafting or updating a project charter — formal authorization document at project start"
---

# Project Charter Development SOP

## What This SOP Does

The Project Charter skill provides a structured approach to developing a formal authorization document that establishes the project's existence, defines its purpose and objectives, identifies key stakeholders, and grants the project manager authority to begin work. The charter is the critical bridge between project conception and execution.

**Purpose:** Formally authorize the project and provide the PM with the authority and clarity needed to acquire resources, engage stakeholders, and execute project activities.

## Step-by-Step Process

### Step 1: Define Project Basics
- Develop clear, concise project title
- Write project purpose statement (why this project matters)
- Document business case summary (strategic context and expected value)
- Identify project category/type
- Define high-level scope boundaries
- Confirm project start date and expected end date

### Step 2: Establish SMART Objectives
- Define Specific objectives that clearly state what will be achieved
- Ensure Objectives are Measurable with defined success criteria
- Verify Objectives are Achievable given available resources and constraints
- Confirm Objectives are Relevant to organizational strategy and stakeholder needs
- Define Time-bound targets with specific deadlines
- Limit to 3-5 primary objectives to maintain focus

### Step 3: Identify Key Stakeholders
- List project sponsor(s) with name, title, and contact
- Identify primary stakeholders (those most affected)
- Note executive steering committee members
- Document key user representatives
- Identify any external stakeholders (vendors, regulators, customers)

### Step 4: Define Governance Structure
- Establish project governance body (Steering Committee, etc.)
- Define decision-making authority levels
- Outline escalation path for issues and conflicts
- Define approval requirements for key deliverables
- Establish reporting structure and cadence
- Document roles and responsibilities matrix

### Step 5: Document Constraints and Assumptions
- List known constraints (budget limits, timeline, resource availability)
- Document key assumptions that project is based upon
- Identify dependencies on other projects or systems
- Note organizational policies and standards that apply
- Define any regulatory or compliance requirements

### Step 6: Define High-Level Scope
- Document in-scope items (what the project includes)
- Document out-of-scope items (explicit exclusions)
- Define major deliverables or deliverables groups
- Identify key milestones with target dates
- Establish scope change control process

### Step 7: Develop Budget and Resource Overview
- Document high-level budget estimate
- Identify key resource categories (FTEs, contractors, etc.)
- Note any pre-approved resources or budgets
- Define resource acquisition authority

### Step 8: Conduct Risk Assessment
- Identify top 3-5 high-level project risks
- Document risk categories (technical, organizational, external)
- Outline initial risk response strategies
- Define risk monitoring approach

### Step 9: Obtain Signatures and Authorization
- Review draft charter with sponsor
- Incorporate feedback and finalize content
- Obtain formal signatures from sponsor and key stakeholders
- Distribute approved charter to all stakeholders
- File charter in project repository

## Data Sources

- Business Case: Strategic justification and expected ROI
- Feasibility Study: Technical, economic, operational assessments
- Stakeholder Analysis: Power, interest, and engagement strategies
- Organizational Strategy: Strategic objectives the project supports
- Historical Project Data: Lessons learned and previous project information
- Portfolio Prioritization: Strategic alignment documentation

## Key Charter Elements

| Element | Description |
|---------|-------------|
| Project Title | Clear, descriptive name |
| Purpose | Why the project exists |
| SMART Objectives | Specific, measurable, achievable, relevant, time-bound |
| Scope Summary | High-level in/out of scope |
| Budget | Authorized spending limit |
| Timeline | Key dates and milestones |
| Governance | Decision-making structure |
| PM Authority | Powers granted to PM |
| Assumptions | Current beliefs underlying project |
| Constraints | Known limitations |
| Risks | Top-level risk assessment |
| Stakeholders | Key stakeholders and their roles |
| Approvals | Authorized signatories |

## Automation Tier

**Tier 2 — Accelerate**

This skill accelerates charter development by:
- Generating structured charter templates
- Compiling information from related documents
- Formatting content into standard layout
- Managing signature workflow and version control
- Creating stakeholder distribution lists

Human judgment is required to negotiate sponsor expectations, balance competing stakeholder interests, and make final decisions on scope and authority levels.

## Output: Project Charter Template

```
PROJECT CHARTER
===============

1. PROJECT INFORMATION
----------------------
Project Title: [Official project name]
Project Code/ID: [Unique identifier]
Project Manager: [Name, Title, Contact]
Sponsor(s): [Name, Title, Department]
Start Date: [Date]
Planned End Date: [Date]
Document Version: [X.X]
Date: [Version Date]

2. PROJECT PURPOSE
------------------
[2-3 sentences explaining why this project is being undertaken and what business problem it addresses]

3. BUSINESS CASE SUMMARY
------------------------
[Concise summary of strategic context, expected benefits, and ROI justification]

4. PROJECT OBJECTIVES (SMART)
-----------------------------
| # | Objective | Success Criteria | Target Date |
|---|-----------|------------------|-------------|
| 1 |           |                  |             |
| 2 |           |                  |             |
| 3 |           |                  |             |

5. HIGH-LEVEL SCOPE
-------------------
In Scope:
- [Deliverable or work package 1]
- [Deliverable or work package 2]

Out of Scope:
- [Explicit exclusion 1]
- [Explicit exclusion 2]

6. KEY MILESTONES
-----------------
| Milestone | Description | Target Date |
|-----------|-------------|-------------|
| M1        |             |             |
| M2        |             |             |
| M3        |             |             |

7. BUDGET
---------
Approved Budget: $[Amount]
Budget Type: [Fixed/Firm/Not-to-Exceed]
Cost Center: [Code/Department]
Currency: [USD/EUR/etc.]

8. GOVERNANCE STRUCTURE
-----------------------
Governance Body: [Committee Name/Description]
Meeting Cadence: [Frequency]
Decision Authority: [Level description]

Project Manager Authority:
- [Authority 1]
- [Authority 2]
- [Limitations if any]

Escalation Path:
- Level 1: [Role/Person]
- Level 2: [Role/Person]
- Level 3: [Role/Person]

9. KEY STAKEHOLDERS
-------------------
| Name | Role | Department | Interest | Authority Level |
|------|------|------------|----------|-----------------|
|      |      |            |          |                 |

10. ASSUMPTIONS
---------------
| # | Assumption | Impact if Wrong | Owner |
|---|------------|-----------------|-------|
| 1 |            |                 |       |
| 2 |            |                 |       |

11. CONSTRAINTS
---------------
| Constraint Type | Description | Mitigation |
|-----------------|-------------|------------|
| Budget          |             |           |
| Schedule        |             |           |
| Resource        |             |           |
| Technical       |             |           |

12. HIGH-LEVEL RISKS
--------------------
| Risk | Probability | Impact | Mitigation Strategy |
|------|-------------|--------|---------------------|
|      | H/M/L       | H/M/L  |                     |

13. APPROVALS
-------------
By signing below, the sponsor authorizes this project and grants the Project Manager the authority to proceed.

| Role | Name | Signature | Date |
|------|------|-----------|------|
| Executive Sponsor |      |           |      |
| Business Sponsor  |      |           |      |
| Project Manager   |      |           |      |
| Steering Committee|      |           |      |

14. DISTRIBUTION
---------------
| Recipient | Role | Date Received |
|-----------|------|---------------|
|            |      |               |
```

## Known Limitations

- Charter estimates are high-level and subject to refinement during planning
- Stakeholder identification may be incomplete at charter stage
- Authority levels may need adjustment as project complexity becomes clearer
- Business case assumptions may change before project execution
- External factors may require charter revision after approval
- Charter does not replace detailed planning documents
