---
name: pm-280-lessons-learned
description: Capture, document, and distribute project lessons learned for organizational learning and future project improvement.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, closure, lessons-learned, continuous-improvement]
    trigger: [lessons learned, project retrospective, project review, post-project review, organizational learning]
    trigger_context: "Thomas documenting lessons learned at project close — capturing what worked, what didn't, for future projects"
---
# PM-280: Lessons Learned Documentation

## What
Capture knowledge gained during the project — what worked, what didn't, what to do differently next time — and document it in a format that benefits future projects.

## Lessons Learned Categories
| Category | Focus |
|----------|-------|
| **Scope Management** | Scope changes, WBS accuracy, requirements volatility |
| **Schedule Management** | Estimation accuracy, scheduling tools, dependencies |
| **Budget Management** | Cost estimation, budget tracking, contingency usage |
| **Quality Management** | QA activities, defect rates, quality gates |
| **Risk Management** | Risk identification accuracy, response effectiveness |
| **Vendor Management** | Vendor performance, contract issues, relationship |
| **Team & Communication** | Team dynamics, communication effectiveness, meetings |
| **Tools & Process** | PM tools, methodologies, process adherence |
| **Stakeholder Engagement** | Stakeholder management, expectation setting |
| **Technical Decisions** | Architecture choices, technology selection, debt |

## Lessons Learned Template
| ID | Category | What happened | Impact | Root cause | What worked | What didn't | Recommendation |
|----|----------|---------------|--------|------------|-------------|-------------|----------------|
| LL-001 | Risk Management | Key risk materialized earlier than expected | +3 week delay, +€15K | Risk identified but trigger monitoring inadequate | Risk register updated | Trigger monitoring gap | Add weekly risk trigger review in PM cadence |
| LL-002 | Schedule | Underestimated integration testing effort | +1 week | Used analogous estimate from smaller project | | Estimation methodology wrong | Use PERT for complex integrations |
| ... | ... | ... | ... | ... | ... | ... | ... |

## Step-by-Step SOP
1. **Timing**: Conduct 30-60 days after project closure — enough time for perspective, not so long that memory fades
2. **Prepare**: Review project history — status reports, issues, risks, decisions made
3. **Invite**: Include PM, sponsor, key team members, business owner
4. **Facilitate**: Structured conversation using template above — identify events, analyze, recommend
5. **Categorize**: Assign each lesson to a category
6. **Prioritize**: Vote on top 5 most impactful lessons to highlight
7. **Document**: Fill template, write in plain language anyone can understand
8. **Share**: Upload to organizational knowledge base, share with PM community
9. **Reference**: Link to project charter, risk register, closure report

## Knowledge Sharing Format
### Summary (1 page)
> **Top 5 Lessons from [Project Name]**
> 1. Risk trigger monitoring must be weekly, not monthly — our biggest risk was identified 6 weeks before impact but we missed the trigger signal
> 2. Integration testing estimates need a minimum 1.5x multiplier for complex APIs — analogously scaled estimates from simpler projects consistently undershoot
> 3. Vendor SLA penalties must be in the contract — we had no leverage when delivery slipped by 3 weeks
> 4. Stakeholder sign-off should happen at each milestone gate — late feedback from business caused 2 major rework cycles
> 5. Sprint velocity should be calculated excluding infrastructure weeks — pure development velocity is more accurate for planning

### Full Report
All lessons in template format with full context for anyone who needs to understand the details.

## Data Sources
- Project closure report (pm-250-project-closure-report)
- Risk register and issue log (pm-120, pm-170)
- Sprint velocity data (pm-sprint-helper)
- Team exit interviews (pm-260-team-demobilization)
- PM's own reflection notes

## Automation Tier
**Tier 2 — Accelerate**: Hermes can draft lessons learned template from project data (risks materialized, issues logged, velocity trends). Human adds context and recommendations.

## Limitations
- Lessons learned require honest reflection — blame culture undermines learning
- Recommendations must be actionable, not vague ("improve communication" is useless — "scheduling weekly risk review with sponsor" is actionable)
- Document must be accessible — bury it in an archive and it will never be used