---
name: pm-210-sprint-review
description: Demonstrate completed sprint deliverables to stakeholders, gather feedback, and formally accept or reject stories.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, scrum, sprint-review, demo]
    trigger: [sprint review, sprint demo, sprint review meeting, stakeholder demo, acceptance]
    trigger_context: "Thomas running the sprint review — demo to stakeholders, gathering feedback, formal acceptance of stories"
---
# PM-210: Sprint Review

## What
At the end of each sprint, demonstrate completed work to stakeholders, gather feedback, and formally accept or reject each story based on acceptance criteria.

## Sprint Review Participants
- Development Team (presenting)
- Product Owner (evaluating)
- Business Stakeholders (feedback)
- Scrum Master (facilitating)
- PM (coordinate, log action items)

## Sprint Review Agenda (60-90 minutes)
| Time | Topic | Owner |
|------|-------|-------|
| 0-5min | Sprint goal recap | Scrum Master |
| 5-45min | Demo completed stories | Dev Team |
| 45-60min | Product Owner evaluation | Product Owner |
| 60-80min | Stakeholder feedback | All |
| 80-90min | Action items, next sprint prep | PM |

## Demo Best Practices
- Demo working software, not slides
- Focus on business value delivered
- Show what was committed vs. what was delivered
- Keep demos short (5-10 min each)
- Invite questions after each demo item

## Story Acceptance Decision
| Decision | Meaning | Next Step |
|----------|---------|-----------|
| **Accepted** | Meets acceptance criteria | Move to Done, mark velocity |
| **Rejected** | Does not meet criteria | Return to backlog, re-sprint |
| **Conditional** | Meets with minor issues | Fix in follow-up sprint |

## Step-by-Step SOP
1. **Prepare**: Review sprint commitment, ensure stories are ready for demo (code merged, tested)
2. **Recap goal**: Remind participants what the sprint was supposed to deliver
3. **Run demo**: Team demonstrates each completed story — working software first
4. **Gather feedback**: Stakeholders provide feedback, questions, concerns
5. **Acceptance check**: Product Owner reviews each story against acceptance criteria
6. **Log decisions**: Record accept/reject per story with rationale
7. **Capture feedback**: Log all stakeholder suggestions for backlog refinement
8. **Action items**: Assign follow-up actions with owners and dates
9. **Update backlog**: Move accepted stories to Done, rejected back to backlog

## Output: Sprint Review Summary
### Stories Completed
| Story ID | Title | Committed | Delivered | Decision | Notes |
|----------|-------|-----------|-----------|----------|-------|
| SP-101 | User login | ✓ | ✓ | Accepted | |
| SP-102 | OAuth2 | ✓ | ✗ | Rejected | API timeout not resolved |
| ... | ... | ... | ... | ... | ... |

### Velocity
| Sprint | Committed | Delivered | Rate |
|--------|-----------|-----------|------|
| #27 | 35 SP | 30 SP | 86% |

### Stakeholder Feedback
- [ ] Feature X needs additional filtering — backlog refinement item
- [ ] Payment flow timing acceptable — sign-off from business

### Action Items
| Action | Owner | Due |
|--------|-------|-----|
| Fix API timeout in OAuth2 | Nathanael | 2024-03-18 |
| Add filter to user dashboard | Dev Team | Next sprint |

## Data Sources
- Sprint commitment (pm-190-sprint-planning)
- Sprint backlog status (pm-200-sprint-execution)
- Acceptance criteria per story

## Automation Tier
**Tier 3 — Augment**: Hermes can draft sprint review summary, format story acceptance table, and log feedback into backlog refinement notes.

## Limitations
- Live demo cannot be automated — requires working software
- Acceptance decision is Product Owner's, not PM's
- Feedback must be actionable — vague feedback is noise