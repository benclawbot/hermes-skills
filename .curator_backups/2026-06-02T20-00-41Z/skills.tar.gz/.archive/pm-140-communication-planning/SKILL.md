---
name: pm-140-communication-planning
description: Develop a communication management plan defining what, when, how, and to whom information is distributed throughout the project.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, communication, reporting]
    trigger: [communication plan, stakeholder communication, communication matrix, reporting schedule, status reporting]
    trigger_context: "Thomas creating a communication plan — defining what to communicate, when, to whom, and via what channel"
---
# PM-140: Communication Planning

## What
Define all project communications — what information goes to whom, in what format, how often, and through what channel.

## Communication Types
| Type | Mechanism | When to use |
|------|-----------|-------------|
| **Push** | Email, Teams message, Slack | One-way, timely, specific recipients |
| **Pull** | Wiki, SharePoint, project portal | Reference material, low urgency, self-serve |
| **Interactive** | Meetings, standups, workshops | Two-way, discussion, decisions, escalations |

## Information Types
- **Status reports**: weekly project health, KPIs, milestones
- **Escalations**: risks, issues, change requests exceeding threshold
- **Budget updates**: spend vs. plan, forecast, variance
- **Milestone reports**: phase completion, gate approvals
- **Change notices**: approved changes, scope updates
- **Decision logs**: key decisions and rationale
- **Meeting outcomes**: standups, steering committee, retrospectives

## Escalation Path
| Level | Trigger | Who | Response Time |
|-------|---------|-----|---------------|
| 1 | Risk score ≥ 15 (High) | PM | Notify sponsor within 24h |
| 2 | Budget variance > 10% | PM + Sponsor | Review within 48h |
| 3 | Schedule impact > 2 weeks | PM + Sponsor + Steering | Emergency meeting |

## Step-by-Step SOP
1. Review stakeholder register (pm-020-stakeholder-analysis) — each stakeholder's information needs
2. List all information types the project will produce
3. For each stakeholder group, determine: what they need, how often, in what format, via what channel
4. Assign communication owners (who is responsible for producing and sending)
5. Define escalation thresholds and routes
6. Document in communication matrix
7. Review at project start and adjust as stakeholder landscape changes

## Output: Communication Matrix
| Audience | Information Type | Format | Frequency | Owner | Channel | Notes |
|----------|------------------|--------|-----------|-------|---------|-------|
| Steering Committee | Status report + budget | PDF report | Monthly | PM | Email + meeting | 3 days before meeting |
| Sponsor | Milestone report + risks | Short brief | Bi-weekly | PM | Email | + ad-hoc for escalations |
| Development Team | Sprint goals, blockers | Verbal/Teams | Daily | Scrum Master | Standup | |
| Business Stakeholders | Feature status, UAT schedule | Dashboard | Weekly | PM | Wiki | Self-serve pull |
| Change Control Board | Change requests | Formal doc | Per event | PM | Email | Formal process |
| ... | ... | ... | ... | ... | ... | ... |

## Output: Communication Schedule Summary
| Report/Meeting | Cadence | Audience | Owner | Last Send |
|----------------|---------|----------|-------|-----------|
| Weekly status report | Every Monday | Sponsor + Steering | PM | |
| Daily standup | Daily | Dev team | Scrum Master | |
| Sprint review | End of sprint | All stakeholders | Scrum Master | |
| Risk review | Monthly | PM + Sponsor | PM | |
| Budget forecast | Monthly | Sponsor | PM | |

## Data Sources
- Stakeholder register (pm-020-stakeholder-analysis)
- Project charter (governance section)
- Organizational communication standards

## Automation Tier
**Tier 2 — Accelerate**: Hermes can draft the communication matrix from stakeholder register and project type. Weekly status report can be auto-populated from project data.

## Limitations
- Plan must be adapted as project evolves — quarterly review recommended
- Too much communication creates noise — keep focused on what stakeholders actually need
- Channel effectiveness varies by organizational culture