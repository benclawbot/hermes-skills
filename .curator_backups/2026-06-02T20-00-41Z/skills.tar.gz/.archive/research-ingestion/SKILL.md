---
name: research-ingestion
description: Use when Thomas wants to ingest, index, or map a large body of source material (papers, articles, books) into an Obsidian knowledge vault. Multi-lot, subagent-driven, 500+ pages with wikilinks.
version: 1.0.0
author: Thomas
metadata:
  hermes:
    tags: [research, ingestion, obsidian, knowledge-base]
    related_skills: [deep-research-obsidian]
---

# Knowledge Vault Generator (Research Ingestion)

Scalable generator for ingesting source material into a 500+ page interconnected Obsidian vault. Multi-lot, subagent-driven with 2-stage review.

## When to Use

- Thomas provides a corpus of papers, articles, or books to index
- "ingest this research", "index these papers in Obsidian", "build a knowledge base from [material]"
- Large-scale knowledge mapping that requires structured page generation with wikilinks

## Variables to Fill

```
SUBJECT            : [e.g. "Crypto trading bots and strategies"]
CLUSTER_CHOISI    : [e.g. "Trading bots and strategies"]
VAULT_PATH        : /home/thomas/Desktop/Memory
NB_PAGES_TARGET   : 500
LOT_SIZE          : 4-5 pages per subagent (avoids stalls)
```

## Vault Architecture

```
{VAULT_PATH}/
├── CLAUDE.md                   # Vault schema
├── README.md                   # Overview
├── _MOC.md                     # Map of Content (index)
├── pages/                      # All pages organized by lots
│   ├── _Lot1_Topic-1/
│   │   └── ...
│   └── _LotN_Topic-N/
├── 99-Meta/
│   ├── Schema.md              # YAML conventions
│   ├── Plan.md                # All lots and pages plan
│   ├── Fact-Check-Log.md     # WebSearch traces
│   ├── Audit.md               # Final quality report
│   └── Debrief.md             # Experience report
└── .obsidian/
```

## Phases

### Phase 0 — Bootstrap
1. Create folder structure `pages/_LotN_Topic/` for each planned lot
2. Write `CLAUDE.md` root with conventions
3. Write `99-Meta/Schema.md` with detailed YAML schema
4. Write `99-Meta/Plan.md` with ALL lots and pages
5. Create lot folders BEFORE launching subagents

### Phase 1 — Generation by Lots (subagent-driven)

Per-lot workflow (4-5 pages):
1. Dispatch implementer subagent → generates pages in lot folder
2. Dispatch spec reviewer subagent → YAML compliance + wikilinks + anti-hallucination
3. If issues → implementer fix → spec reviewer re-review
4. Dispatch code quality reviewer → English quality, structure
5. If issues → implementer fix → code quality re-review
6. Lot marked complete

### Phase 2 — Linking and MOC
1. Generate `_MOC.md` with 3-paragraph intro + pages grouped by lot with 1 sentence each
2. Densify wikilinks — target 8-12 per page
3. Post-process broken links — only flag links to pages never planned

### Phase 3 — Quality Audit
Produce `99-Meta/Audit.md`:
1. YAML compliance
2. Duplicates
3. Contradictions
4. Orphan pages (0 inbound backlinks)
5. Anemic pages (<600 words)
6. Total wikilinks and ratio

### Phase 4 — Debrief
Report final stats, what worked, what went wrong, recommended adjustments.

## Anti-Hallucination Rules (Non-Negotiable)

1. **No invented proper names** — WebSearch required or page gets `status: to-verify`
2. **No fabricated dates** — note "exact date to confirm" if uncertain
3. **No unsourced statistical figures**
4. **No invented direct quotes** — paraphrase neutrally instead
5. Non-Latin characters detected → fix only contaminated pages
6. Debunked theories: say "debunked", "non-replicable", "considered pseudoscience"
7. Any hallucination detected → log in `99-Meta/Fact-Check-Log.md`

## Page Structure

```markdown
---
title: "Exact page name"
type: concept | theory | person | experience | controversy | school | disorder | method | term | debate | work | institution | event
cluster: "{CLUSTER_CHOISI}"
status: verified | to-verify | debated | debunked | hypothetical | stub | needs-sourcing
controversy: low | medium | high
importance: pillar | standard | deep-cut
source_knowledge: internal | web-checked | mixed
sources_count: N
tags: [#tag1, #tag2]
created: YYYY-MM-DD
strong_links: [["[[Page1]]", "[[Page2]]"]]
opposition_links: [["[[Page3]]"]]
---

# Title

> [!info] Summary
> 1-2 sentences clear pitch.

## Definition
2-4 dense paragraphs.

## Context and origin
Who, when, where, intellectual framework.

## Mechanisms / characteristics / details
3-6 paragraphs, concrete examples.

## Nuances, critiques, limits
MANDATORY on all pages.

## Links and implications
Wikilinks contextualized in full sentences. Min 7 outbound wikilinks. Target 8-12.

## Sources
[^1]: Author, *Title*, Publisher, year, URL
```

## Subagent 2-Stage Review

- **Implementer**: generates pages per lot, self-review before returning
- **Spec reviewer**: YAML compliance, wikilink count ≥7, no non-Latin chars, filename matches Plan
- **Code quality reviewer**: English quality, structure conforms, no gratuitous bullet lists