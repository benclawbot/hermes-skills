---
name: pm-180-vendor-management
description: Manage vendor contracts, monitor vendor performance, track deliverables, and handle vendor-related risks throughout the project.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, vendor, procurement, contracts]
    trigger: [vendor management, vendor contract, vendor performance, vendor risk, procurement, SOW]
    trigger_context: "Thomas managing vendor contracts and vendor performance — tracking deliverables, spend, and risk"
---
# PM-180: Vendor Management

## What
Manage vendor selection, contract negotiation, work monitoring, deliverable acceptance, and contract closure for all external suppliers.

## Vendor Selection Process
1. Define scope and evaluation criteria for needed work
2. Issue Request for Proposal (RFP) or Request for Quotation (RFQ)
3. Evaluate proposals against criteria (cost, capability, timeline, references)
4. Conduct vendor interviews or proof-of-concept
5. Select vendor and negotiate contract

## Contract Types
| Type | Description | Best for |
|------|-------------|----------|
| **Fixed Price** | Set price for defined scope | Well-defined deliverables |
| **Time & Materials** | Pay for time spent + materials | Variable scope, consulting |
| **Cost Reimbursable** | Actual cost + fee | Research, uncertain scope |
| **混合** | Hybrid T&M + milestone payments | Software development |

## Key Contract Clauses
- **Scope of Work (SOW)**: What is included and excluded
- **Deliverables**: Specific outputs with acceptance criteria
- **Payment schedule**: Milestone-based or monthly
- **Intellectual property**: Who owns what
- **Service Level Agreements (SLAs)**: Performance standards
- **Termination clause**: How to exit the contract
- **Warranty**: Support period after delivery

## Vendor Risk Categories
| Risk | Mitigation |
|------|------------|
| Vendor goes bankrupt | Payment milestones, keep source codeescrow |
| Key person leaves vendor | Key person clause, knowledge transfer plan |
| Scope creep | Clear SOW, change control process |
| Quality issues | Acceptance criteria, right to reject |
| Missed deadlines | Milestone payments tied to deliverables |
| Security breach | Security requirements in contract, audit rights |

## Step-by-Step SOP
1. **Define need**: Scope, timeline, budget, evaluation criteria
2. **Select vendor**: RFP → evaluate → select → negotiate
3. **Contract**: Draft SOW, agree payment schedule, include SLA/SLA penalties, sign
4. **Onboard vendor**: Introduce to team, share project plan, agree communication rhythm
5. **Monitor performance**: Weekly check-ins, track deliverable status vs. plan, invoice validation
6. **Accept deliverables**: Review against acceptance criteria, formally accept or request rework
7. **Manage changes**: All vendor scope changes through change control
8. **Close contract**: Final acceptance, final payment, lessons learned, contract归档

## Output: Vendor Status Dashboard
| Vendor | Contract Value | Paid to Date | Milestones | Status | Risks |
|--------|----------------|--------------|------------|--------|-------|
| Acme Corp | €120,000 | €60,000 | 3/5 done | On track | None |
| Beta Solutions | €45,000 | €15,000 | 1/3 done | At risk | Key person left |
| ... | ... | ... | ... | ... | ... |

## Output: Deliverable Acceptance Log
| Deliverable | Vendor | Due Date | Submitted | Accepted | Rejected | Notes |
|-------------|--------|----------|-----------|----------|----------|-------|
| Design document | Acme | 2024-03-01 | 2024-03-01 | ✓ | | |
| Prototype | Beta | 2024-03-15 | 2024-03-18 | | ✗ | Missing API layer |
| ... | ... | ... | ... | ... | ... | ... |

## Data Sources
- Contracts and SOW documents
- Invoice records
- Vendor progress reports
- Team feedback on vendor quality

## Automation Tier
**Tier 2 — Accelerate**: Hermes can draft SOW templates, generate vendor status dashboards, flag late deliverables, and validate invoices against milestones.

## Limitations
- Vendor management requires human relationship — cannot fully automate
- Small vendors may not have formal reporting processes
- Currency and tax implications vary by vendor location — consult finance