---
name: pm-200-sprint-execution
description: Monitor sprint execution daily — track progress, identify blockers, update backlog, and keep the sprint on target.
version: 1.0.0
metadata:
  hermes:
    tags: [project-management, scrum, sprint, execution]
    trigger: [sprint execution, sprint monitoring, daily standup, sprint status, backlog update, blocker]
    trigger_context: "Thomas monitoring sprint execution — tracking daily progress, removing blockers, updating the backlog"
---
# PM-200: Sprint Execution

## What
Monitor sprint progress daily, identify and remove blockers, update story status, and keep the sprint on target to meet the commitment.

## Daily Standup Format (15 minutes max)
| Question | Purpose |
|----------|--------|
| What did I complete yesterday? | Accountability, progress tracking |
| What will I do today? | Planning, coordination |
| What is blocking me? | Impediment identification |

## Sprint Health Indicators
| Indicator | Healthy | Warning | Critical |
|-----------|---------|---------|----------|
| Stories in progress | > 2 in flight | 1-2 | 0 or > 5 |
| Blockers | 0 | 1 | > 1 or > 1 day old |
| Completion rate (day 5) | ≥ 40% of commitment | 25-39% | < 25% |
| Backlog status | Updated daily | Updated 2-3x/week | Outdated |

## Step-by-Step SOP
1. **Daily standup**: Run 15-minute standup — each team member answers 3 questions
2. **Log blockers**: Immediately capture all blockers with owner and age
3. **Address blockers**: PM removes blockers or escalates — cannot wait
4. **Update story status**: Move stories through states: Ready → In Progress → Code Review → QA → Done
5. **Re-estimate if needed**: If story scope changed, re-estimate and adjust commitment
6. **Mid-sprint review (day 5)**: Compare actual progress vs. plan — adjust if needed
7. **Raise change**: If commitment is at risk, notify Product Owner and Sponsor immediately

## Blocker Escalation Path
| Blocker Age | Action |
|-------------|--------|
| < 4h | Team tries to resolve |
| 4-8h | PM intervenes, escalate if no progress |
| 8-24h | Escalate to technical lead or manager |
| > 24h | Notify sponsor — sprint goal at risk |

## Story States
`Ready → In Progress → Code Review → QA → Done → Accepted`

## Sprint Burndown Chart
| Day | Expected Remaining | Actual Remaining | Variance |
|-----|-------------------|------------------|----------|
| 0 | 35 SP | 35 SP | 0 |
| 1 | 32 SP | 33 SP | +1 (behind) |
| 2 | 29 SP | 30 SP | +1 |
| ... | ... | ... | ... |

## Sprint Adjustment Options (When Behind)
1. **Descope**: Move lowest-priority story to backlog (Product Owner approval)
2. **Add capacity**: Pair programming, reduce meeting load
3. **Extend sprint**: Only with team agreement and PM/Sponsor approval
4. **Re-estimate**: If original estimate was wrong, adjust and communicate

## Data Sources
- Daily standup notes
- Sprint backlog (pm-190-sprint-planning output)
- Jira or task board status
- Burndown data

## Automation Tier
**Tier 1 — Eliminate**: Hermes can draft standup notes from inputs, update burndown chart, flag when progress is behind plan, and suggest descope options.

## Limitations
- Blocker removal requires human authority and relationships
- If team consistently misses commitment, velocity data needs recalibration
- Don't add stories mid-sprint — corrupts velocity tracking