---
name: gh-api-caching
description: Cache GitHub API calls with in-memory LRU + file cache, 5-min TTL. Eliminates repeated gh CLI latency (~500ms → ~50ms). Used by project-health-digest, github-pr-digest, iagent-windows-digest.
triggers:
  - writing a script that calls `gh api` or `gh` CLI multiple times
  - need to speed up github monitoring scripts
  - cron job hitting github API repeatedly
---

# GitHub API Caching Pattern

## Core Pattern

```python
import hashlib, json, time, os
from pathlib import Path

CACHE_DIR = Path.home() / ".hermes/cache/gh"
CACHE_DIR.mkdir(parents=True, exist_ok=True)
TTL = 300  # 5 minutes

def gh_cached(cmd: list[str]) -> dict:
    """Run gh command, return cached result if fresh."""
    cache_key = hashlib.sha256(" ".join(cmd).encode()).hexdigest()
    cache_file = CACHE_DIR / f"{cache_key}.json"

    # Check memory + disk cache
    if cache_file.exists():
        age = time.time() - cache_file.stat().st_mtime
        if age < TTL:
            return json.loads(cache_file.read_text())

    # Run gh (use /home/thomas/bin/gh, not /usr/bin/gh)
    import subprocess
    result = subprocess.run(
        ["/home/thomas/bin/gh"] + cmd,
        capture_output=True, text=True
    )
    data = json.loads(result.stdout)

    # Cache to disk
    cache_file.write_text(json.dumps(data))
    return data
```

## Usage in Scripts

```python
from gh_cached import gh_cached

repos = gh_cached(["repo", "list", "--limit", "30"])
for repo in repos:
    runs = gh_cached(["api", f"/repos/benclawbot/{repo['name']}/actions/runs"])
    # ... process
```

## Key Constraints
- Use `/home/thomas/bin/gh` — authenticated as benclawbot via keyring
- TTL=300s (5 min) — safe for cron jobs that run every hour or less
- Not safe for real-time user-facing queries — cache is shared across all scripts
- For script-local cache (faster repeated calls within one run), add in-memory dict wrapper

## Verification
```bash
cd /home/thomas/.hermes/scripts && /home/thomas/Desktop/hermes-agent/.venv/bin/python3 -c "
from gh_cached import gh_cached
import time
t0 = time.time(); r1 = gh_cached(['repo', 'list', '--limit', '1'])
t1 = time.time(); r2 = gh_cached(['repo', 'list', '--limit', '1'])
print(f'fresh: {(t1-t0)*1000:.0f}ms, cached: {(time.time()-t1)*1000:.0f}ms')
"
```
Expected: fresh ~500ms, cached ~50ms.

## Skill Dependencies
- `parallel-gh-scripts` — use together for repo monitoring scripts
- `hermes-agent-development` — umbrella skill for hermes-agent-specific development patterns
- `hermes-performance-tuning` — gateway config tuning that complements fast tool execution