---
name: parallel-gh-scripts
description: Parallelize gh API calls in repo monitoring scripts using ThreadPoolExecutor. 8 workers, threads-join pattern. Used by project-health-digest (29 repos in 5.3s vs 30s sequential).
triggers:
  - writing a script that iterates over multiple GitHub repos
  - need to speed up multi-repo API queries
  - any script calling gh api in a loop
---

# Parallel gh API Script Pattern

## Core Structure

```python
from concurrent.futures import ThreadPoolExecutor, as_completed
import subprocess, json

GH = "/home/thomas/bin/gh"
WORKERS = 8

def fetch_repo_data(repo_name: str) -> dict:
    """Fetch all data for one repo. Runs in thread pool."""
    import subprocess
    data = {"name": repo_name, "error": None}
    try:
        # Example: get latest workflow run
        result = subprocess.run(
            [GH, "api", f"/repos/benclawbot/{repo_name}/actions/runs"],
            capture_output=True, text=True, timeout=15
        )
        runs = json.loads(result.stdout).get("workflow_runs", [])
        data["runs"] = runs[:3]  # last 3 runs
    except Exception as e:
        data["error"] = str(e)
    return data

def main():
    # Get repo list
    result = subprocess.run(
        [GH, "repo", "list", "benclawbot", "--limit", "30", "--json", "name"],
        capture_output=True, text=True
    )
    repos = [r["name"] for r in json.loads(result.stdout)]

    # Parallel fetch
    results = {}
    with ThreadPoolExecutor(max_workers=WORKERS) as ex:
        futures = {ex.submit(fetch_repo_data, repo): repo for repo in repos}
        for future in as_completed(futures):
            repo = futures[future]
            results[repo] = future.result()

    # Collate results
    for repo, data in results.items():
        if data["error"]:
            print(f"❌ {repo}: {data['error']}")
        else:
            print(f"✅ {repo}: {len(data['runs'])} runs")
```

## Key Parameters

| Param | Value | Rationale |
|-------|-------|-----------|
| `WORKERS` | 8 | Balances parallelism vs GitHub API rate limits |
| `timeout` | 15s per call | Prevents hung threads blocking the pool |
| `runs[:3]` | last 3 runs | Enough for health check, reduces data |

## Combining with gh-cached

```python
# In fetch_repo_data, replace subprocess.run with gh_cached():
from gh_cached import gh_cached

def fetch_repo_data(repo_name: str) -> dict:
    data = {"name": repo_name, "error": None}
    try:
        runs = gh_cached(["api", f"/repos/benclawbot/{repo_name}/actions/runs"])
        data["runs"] = runs.get("workflow_runs", [])[:3]
    except Exception as e:
        data["error"] = str(e)
    return data
```

## Verification

```bash
cd /home/thomas/.hermes/scripts && time /home/thomas/Desktop/hermes-agent/.venv/bin/python3 project-health-digest.py
```
Expected: ~5-6s for 29 repos. Sequential would be ~30s.

## Common Pitfalls
- Don't use `ThreadPoolExecutor` with `map` — use `as_completed` to process results as they finish
- Set a timeout on subprocess calls — gh API hangs can block threads forever
- GitHub rate limit: ~5000 req/hr authenticated. 8 workers hitting ~29 repos × 2 calls each = ~58 calls per run. Well within limit.