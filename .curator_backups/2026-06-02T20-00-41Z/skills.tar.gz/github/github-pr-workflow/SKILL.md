---
name: github-pr-workflow
description: "GitHub PR lifecycle: branch, commit, open, CI, merge."
version: 1.1.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [GitHub, Pull-Requests, CI/CD, Git, Automation, Merge]
    related_skills: [github-auth, github-code-review]
---

# GitHub Workflows

Complete guide for GitHub operations: PR lifecycle, code review, issues, and repository management. Each section shows the `gh` way first, then the `git` + `curl` fallback for machines without `gh`.

> **Auth prerequisite:** See `github-auth` skill for token/SSH setup before using any workflow here.
> **gh path:** Always use `/home/thomas/bin/gh` — `/usr/bin/gh` doesn't exist on this system. See `references/gh-path-note.md`.

## Skills Map

| Task | Skill |
|------|-------|
| PR: branch, commit, open, CI, merge | *(this skill — github-pr-workflow)* |
| PR: review, diff, inline comments | *(this skill — github-code-review section)* |
| Issues: create, triage, label, assign | *(this skill — github-issues section)* |
| Repo: clone, create, fork, releases, secrets | *(this skill — github-repo-management section)* |
| Auth: token setup, SSH, gh login | `github-auth` (separate skill) |

## Common Setup

- Authenticated with GitHub (see `github-auth` skill)
- Inside a git repository with a GitHub remote

### Quick Auth Detection

```bash
# Determine which method to use throughout this workflow
if command -v gh &>/dev/null && gh auth status &>/dev/null; then
  AUTH="gh"
else
  AUTH="git"
  # Ensure we have a token for API calls
  if [ -z "$GITHUB_TOKEN" ]; then
    if [ -f ~/.hermes/.env ] && grep -q "^GITHUB_TOKEN=" ~/.hermes/.env; then
      GITHUB_TOKEN=$(grep "^GITHUB_TOKEN=" ~/.hermes/.env | head -1 | cut -d= -f2 | tr -d '\n\r')
    elif grep -q "github.com" ~/.git-credentials 2>/dev/null; then
      GITHUB_TOKEN=$(grep "github.com" ~/.git-credentials 2>/dev/null | sed 's|https://[^:]*:\([^@]*\)@.*|\1|')
    fi
  fi
fi
echo "Using: $AUTH"
```

### Extracting Owner/Repo from the Git Remote

Many `curl` commands need `owner/repo`. Extract it from the git remote:

```bash
# Works for both HTTPS and SSH remote URLs
REMOTE_URL=$(git remote get-url origin)
OWNER_REPO=$(echo "$REMOTE_URL" | sed -E 's|.*github\.com[:/]||; s|\.git$||')
OWNER=$(echo "$OWNER_REPO" | cut -d/ -f1)
REPO=$(echo "$OWNER_REPO" | cut -d/ -f2)
echo "Owner: $OWNER, Repo: $REPO"
```

---

## 0. Confirm Intent Before Creating PRs

**Before opening a PR, confirm the goal.** A PR is only correct when the project is meant to contribute BACK to a host repo. If the goal is a standalone project, just push clean code to `main` — no PR needed.

Common mistake: agent opens a PR to the original repo because it was working in a fork of that repo. The user may only want the feature as a standalone project.

```
User: "I want Agent Commit as its own thing" → push clean main, no PR
User: "Open a PR to Hermes" → create PR to host repo
```

When in doubt, ask: "Push clean code and open a PR against [target], or just make it a standalone project?"

---

## 1. Pre-Flight: Verify Push Access

**Always run this BEFORE making commits** on a branch meant for a PR:

```bash
# Test push access to origin
git push --dry-run origin HEAD 2>&1
PUSH_OK=$?

if [ $PUSH_OK -ne 0 ]; then
  echo "No push access to origin — checking for fork remote..."
  # Check if a fork remote already exists
  git remote -v | grep -E "(fork|push)" && echo "Fork remote found"
  # Diagnose: gh auth status
  gh auth status 2>&1 | head -5
fi
```

**If push fails and a fork remote exists:** use the fork remote for pushes, keep origin for PR creation. Never make commits on a branch you can't push.

**The fork remote may already exist** (`git remote -v` shows it) even if push fails — this means the token/ssh key doesn't have write access to the fork. Use the fork-based workflow in Section 3.

**If no fork remote exists:** use the `gh api` fork creation + fork remote setup in Section 3, then push to the fork.

---

## 1. Branch Creation

This part is pure `git` — identical either way:

```bash
# Make sure you're up to date
git fetch origin
git checkout main && git pull origin main

# Create and switch to a new branch
git checkout -b feat/add-user-authentication
```

Branch naming conventions:
- `feat/description` — new features
- `fix/description` — bug fixes
- `refactor/description` — code restructuring
- `docs/description` — documentation
- `ci/description` — CI/CD changes

## 2. Making Commits

Use the agent's file tools (`write_file`, `patch`) to make changes, then commit:

```bash
# Stage specific files
git add src/auth.py src/models/user.py tests/test_auth.py

# Commit with a conventional commit message
git commit -m "feat: add JWT-based user authentication

- Add login/register endpoints
- Add User model with password hashing
- Add auth middleware for protected routes
- Add unit tests for auth flow"
```

Commit message format (Conventional Commits):
```
type(scope): short description

Longer explanation if needed. Wrap at 72 characters.
```

Types: `feat`, `fix`, `refactor`, `docs`, `test`, `ci`, `chore`, `perf`

## 3. Pushing and Creating a PR

### Push the Branch (same either way)

```bash
git push -u origin HEAD
```

### Push Troubleshooting

If `git push` fails with `403` or `permission denied`:

**1. Diagnose the token:**
```bash
# Check which token is being used
gh auth status 2>&1

# Extract token from git-credentials if gh is not usable
GIT_CREDS_TOKEN=$(cat ~/.git-credentials 2>/dev/null | grep github.com | head -1 | sed 's|https://[^:]*:||; s|@github.com||')

# Test token permissions against the repo
OWNER_REPO=$(git remote get-url origin | sed -E 's|.*github\.com[:/]||; s|\.git$||')
curl -s -o /dev/null -w "%{http_code}" \
  -H "Authorization: token $GIT_CREDS_TOKEN" \
  https://api.github.com/repos/$OWNER_REPO
# 200 = read+write, 404 = no access, 403 = read-only
```

**2. If token lacks write access — fork and push to fork:**
```bash
# Get the canonical URL to extract owner/repo
CANONICAL_URL=$(git remote get-url origin | sed 's|https://[^@]*@|https://|')

# Fork via GitHub API (requires write access to original to create fork)
# If fork already exists, just note it
OWNER_REPO=$(echo "$CANONICAL_URL" | sed -E 's|.*github\.com[:/]||; s|\.git$||')

# Create a fork (GitHub API handles "already exists" gracefully)
FORK_OWNER="YOUR_GITHUB_USERNAME"  # Replace with actual username
FORK_URL="https://github.com/$FORK_OWNER/$(echo $OWNER_REPO | cut -d/ -f2)"

# Add fork as a new remote and push there
git remote add fork "$FORK_URL" 2>/dev/null || true
git push -u fork HEAD

# Then open PR from fork → canonical repo via gh or curl
gh pr create --repo "$OWNER_REPO" --title "..." --body "..."
```

**5. `gh auth git-credential` (primary fix on Linux when gh is available):**
When HTTPS push fails with `could not read Username for 'https://github.com': No such device or address` and `gh auth status` shows a valid login, the credential helper/keyring system is broken. Use gh's built-in credential helper with the full gh path:

```bash
# Find gh path first — may not be in PATH from git's perspective
GH_PATH=$(which gh 2>/dev/null)
git config --global credential.helper "$GH_PATH auth git-credential"
git push origin main
```

**Why this works:** `gh auth git-credential` reads from gh's keyring directly, bypassing broken system credential helpers. The full path is required since gh may be installed at `/home/thomas/bin/gh` rather than `/usr/bin/gh` and git's credential helper doesn't inherit the shell's PATH.

**Post-push cleanup:** Always verify the remote URL contains no embedded credentials:
```bash
git remote -v | grep "github.com" | grep -v "@" && echo "Clean ✓"
```

If `gh auth token` fails (not installed), extract from `~/.git-credentials` or use `git config credential.helper` to clear the broken helper, then retry.

```bash
ssh-keygen -t ed25519 -C "your_email@github.com" -f ~/.ssh/id_ed25519 -N ""
gh api user/keys -X POST -F title="$(hostname)-$(date +%Y%m%d)" -F key="$(cat ~/.ssh/id_ed25519.pub)" 2>/dev/null || echo "Add key manually at github.com/settings/keys"
git remote set-url origin git@github.com:OWNER/REPO.git
git push origin main
```

**6. New Repo Default Branch Issue**
When HTTPS push is broken system-wide and credential helper fixes fail, switch to SSH entirely:
```bash
# Generate SSH key
ssh-keygen -t ed25519 -C "benclawbot@users.noreply.github.com" -f ~/.ssh/id_ed25519 -N ""

# Add to GitHub via gh API (requires admin:public_key scope) or have user add manually at github.com/settings/keys
gh api user/keys -X POST -F title="$(hostname)-$(date +%Y%m%d)" -F key="$(cat ~/.ssh/id_ed25519.pub)" 2>/dev/null || echo "Manual key add needed"

# Switch remote to SSH
git remote set-url origin git@github.com:OWNER/REPO.git
git push origin main
```
This bypasses the HTTPS credential system entirely and is the reliable path when HTTPS is broken.
```bash
# Never leave credentials embedded in the remote URL
git remote set-url origin "$(echo "$(git remote get-url origin)" | sed 's|https://[^@]*@|https://|')"
git remote -v  # verify no credentials visible
```

### New Repo Default Branch Issue

When creating a new GitHub repo via `gh repo create` and immediately pushing to it, the **first branch pushed becomes the default branch automatically** — even before the push completes. This means:

- If you push `feat/my-feature` first, `main` is not the default on the remote yet
- `gh pr create --base main` will fail with "Base sha can't be blank" because `main` isn't the remote default
- **Fix:** Always check the remote's default branch first:
  ```bash
  gh api repos/$OWNER/$REPO --jq '.default_branch'
  ```
- If the default is your feature branch and you need a `main` base, push `main` to the new repo first:
  ```bash
  # Push upstream main as main to the new repo
  git push newremote $(git rev-parse upstream/main):refs/heads/main
  ```
- Then create the PR with explicit head branch:
  ```bash
  gh pr create --repo owner/repo --base main --head feat/my-branch
  ```

### Create a PR

*(Assumes push succeeded or a fork remote was set up above)*

**With gh:**

```bash
gh pr create \
  --title "feat: add JWT-based user authentication" \
  --body "## Summary
- Adds login and register API endpoints
- JWT token generation and validation

## Test Plan
- [ ] Unit tests pass

Closes #42"
```

Options: `--draft`, `--reviewer user1,user2`, `--label "enhancement"`, `--base develop`

**With git + curl:**

```bash
BRANCH=$(git branch --show-current)

curl -s -X POST \
  -H "Authorization: token $GITHUB_TOKEN" \
  -H "Accept: application/vnd.github.v3+json" \
  https://api.github.com/repos/$OWNER/$REPO/pulls \
  -d "{
    \"title\": \"feat: add JWT-based user authentication\",
    \"body\": \"## Summary\nAdds login and register API endpoints.\n\nCloses #42\",
    \"head\": \"$BRANCH\",
    \"base\": \"main\"
  }"
```

The response JSON includes the PR `number` — save it for later commands.

To create as a draft, add `"draft": true` to the JSON body.

## 4. Monitoring CI Status

### Check CI Status

**With gh:**

```bash
# One-shot check
gh pr checks

# Watch until all checks finish (polls every 10s)
gh pr checks --watch
```

**With git + curl:**

```bash
# Get the latest commit SHA on the current branch
SHA=$(git rev-parse HEAD)

# Query the combined status
curl -s \
  -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$OWNER/$REPO/commits/$SHA/status \
  | python3 -c "
import sys, json
data = json.load(sys.stdin)
print(f\"Overall: {data['state']}\")
for s in data.get('statuses', []):
    print(f\"  {s['context']}: {s['state']} - {s.get('description', '')}\")"

# Also check GitHub Actions check runs (separate endpoint)
curl -s \
  -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$OWNER/$REPO/commits/$SHA/check-runs \
  | python3 -c "
import sys, json
data = json.load(sys.stdin)
for cr in data.get('check_runs', []):
    print(f\"  {cr['name']}: {cr['status']} / {cr['conclusion'] or 'pending'}\")"
```

### Poll Until Complete (git + curl)

```bash
# Simple polling loop — check every 30 seconds, up to 10 minutes
SHA=$(git rev-parse HEAD)
for i in $(seq 1 20); do
  STATUS=$(curl -s \
    -H "Authorization: token $GITHUB_TOKEN" \
    https://api.github.com/repos/$OWNER/$REPO/commits/$SHA/status \
    | python3 -c "import sys,json; print(json.load(sys.stdin)['state'])")
  echo "Check $i: $STATUS"
  if [ "$STATUS" = "success" ] ] || [ "$STATUS" = "failure" ] || [ "$STATUS" = "error" ]; then
    break
  fi
  sleep 30
done
```

## 5. Auto-Fixing CI Failures

When CI fails, diagnose and fix. This loop works with either auth method.

### Step 1: Get Failure Details

**With gh:**

```bash
# List recent workflow runs on this branch
gh run list --branch $(git branch --show-current) --limit 5

# View failed logs
gh run view <RUN_ID> --log-failed
```

**With git + curl:**

```bash
BRANCH=$(git branch --show-current)

# List workflow runs on this branch
curl -s \
  -H "Authorization: token $GITHUB_TOKEN" \
  "https://api.github.com/repos/$OWNER/$REPO/actions/runs?branch=$BRANCH&per_page=5" \
  | python3 -c "
import sys, json
runs = json.load(sys.stdin)['workflow_runs']
for r in runs:
    print(f\"Run {r['id']}: {r['name']} - {r['conclusion'] or r['status']}\")"

# Get failed job logs (download as zip, extract, read)
RUN_ID=<run_id>
curl -s -L \
  -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$OWNER/$REPO/actions/runs/$RUN_ID/logs \
  -o /tmp/ci-logs.zip
cd /tmp && unzip -o ci-logs.zip -d ci-logs && cat ci-logs/*.txt
```

### Step 2: Fix and Push

After identifying the issue, use file tools (`patch`, `write_file`) to fix it:

```bash
git add <fixed_files>
git commit -m "fix: resolve CI failure in <check_name>"
git push
```

### Step 3: Verify

Re-check CI status using the commands from Section 4 above.

### Auto-Fix Loop Pattern

When asked to auto-fix CI, follow this loop:

1. Check CI status → identify failures
2. Read failure logs → understand the error
3. Use `read_file` + `patch`/`write_file` → fix the code
4. `git add . && git commit -m "fix: ..." && git push`
5. Wait for CI → re-check status
6. Repeat if still failing (up to 3 attempts, then ask the user)

## 6. Merging

**With gh:**

```bash
# Squash merge + delete branch (cleanest for feature branches)
gh pr merge --squash --delete-branch

# Enable auto-merge (merges when all checks pass)
gh pr merge --auto --squash --delete-branch
```

**With git + curl:**

```bash
PR_NUMBER=<number>

# Merge the PR via API (squash)
curl -s -X PUT \
  -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$OWNER/$REPO/pulls/$PR_NUMBER/merge \
  -d "{
    \"merge_method\": \"squash\",
    \"commit_title\": \"feat: add user authentication (#$PR_NUMBER)\"
  }"

# Delete the remote branch after merge
BRANCH=$(git branch --show-current)
git push origin --delete $BRANCH

# Switch back to main locally
git checkout main && git pull origin main
git branch -d $BRANCH
```

Merge methods: `"merge"` (merge commit), `"squash"`, `"rebase"`

### Enable Auto-Merge (curl)

```bash
# Auto-merge requires the repo to have it enabled in settings.
# This uses the GraphQL API since REST doesn't support auto-merge.
PR_NODE_ID=$(curl -s \
  -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$OWNER/$REPO/pulls/$PR_NUMBER \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['node_id'])")

curl -s -X POST \
  -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/graphql \
  -d "{\"query\": \"mutation { enablePullRequestAutoMerge(input: {pullRequestId: \\\"$PR_NODE_ID\\\", mergeMethod: SQUASH}) { clientMutationId } }\"}"
```

## 7. Complete Workflow Example

```bash
# 1. Start from clean main
git checkout main && git pull origin main

# 2. Branch
git checkout -b fix/login-redirect-bug

# 3. (Agent makes code changes with file tools)

# 4. Commit
git add src/auth/login.py tests/test_login.py
git commit -m "fix: correct redirect URL after login

Preserves the ?next= parameter instead of always redirecting to /dashboard."

# 5. Push
git push -u origin HEAD

# 6. Create PR (picks gh or curl based on what's available)
# ... (see Section 3)

# 7. Monitor CI (see Section 4)

# 8. Merge when green (see Section 6)
```

---

## Code Review

*Absorbed from `github-code-review` — see that skill's full content for complete PR review workflow.*

### Quick Local Review (Pre-Push)

```bash
# Get the diff
git diff main...HEAD

# Check for common issues
git diff main...HEAD | grep -n "print(\|console\.log\|TODO\|FIXME\|HACK\|XXX\|debugger"
git diff main...HEAD | grep -in "password\|secret\|api_key\|token.*=\|private_key"
```

### Review Output Format

```
## Code Review Summary

### Critical
- **src/auth.py:45** — SQL injection: user input passed directly to query.

### Warnings
- **src/models/user.py:23** — Password stored in plaintext.

### Suggestions
- **tests/test_auth.py** — Missing edge case: expired token test.

### Looks Good
- Clean separation of concerns in the middleware layer
```

### Review Checklist

- **Correctness:** Does it do what it claims? Edge cases handled?
- **Security:** No hardcoded secrets? Input validation? SQL injection?
- **Code Quality:** Clear naming? DRY? Single responsibility?
- **Testing:** New paths tested? Error cases covered?
- **Performance:** N+1 queries? Unnecessary loops?
- **Documentation:** Public APIs documented?

### Full Code Review Workflow (End-to-End)

For complete PR review instructions (checking out PRs, posting inline comments, formal review submission), see `references/github-code-review-workflow.md`.

---

## GitHub Issues

*Absorbed from `github-issues` — see that skill's full content for complete issue management.*

### Quick Reference

| Action | gh | curl endpoint |
|--------|-----|--------------|
| List issues | `gh issue list` | `GET /repos/{o}/{r}/issues` |
| View issue | `gh issue view N` | `GET /repos/{o}/{r}/issues/N` |
| Create issue | `gh issue create ...` | `POST /repos/{o}/{r}/issues` |
| Add labels | `gh issue edit N --add-label ...` | `POST /repos/{o}/{r}/issues/N/labels` |
| Assign | `gh issue edit N --add-assignee ...` | `POST /repos/{o}/{r}/issues/N/assignees` |
| Comment | `gh issue comment N --body ...` | `POST /repos/{o}/{r}/issues/N/comments` |
| Close | `gh issue close N` | `PATCH /repos/{o}/{r}/issues/N` |

### Bug Report Template

```
## Bug Description
<What's happening>

## Steps to Reproduce
1. <step>

## Expected Behavior
<What should happen>

## Actual Behavior
<What actually happens>
```

For full issue management (triage, bulk operations, linking to PRs), see `references/github-issues-workflow.md`.

---

## Repository Management

*Absorbed from `github-repo-management` — see that skill's full content for clone, fork, releases, secrets, and CI/CD.*

### Quick Reference

| Action | gh | git + curl |
|--------|-----|-----------|
| Clone | `gh repo clone o/r` | `git clone https://github.com/o/r.git` |
| Create repo | `gh repo create name --public` | `curl POST /user/repos` |
| Fork | `gh repo fork o/r --clone` | `curl POST /repos/o/r/forks` |
| Repo info | `gh repo view o/r` | `curl GET /repos/o/r` |
| Edit settings | `gh repo edit --...` | `curl PATCH /repos/o/r` |
| Create release | `gh release create v1.0` | `curl POST /repos/{o}/{r}/releases` |
| Rerun CI | `gh run rerun ID` | `curl POST /repos/{o}/{r}/actions/runs/ID/rerun` |

### Non-Negotiable: No Credentials in Git

Before ANY `git add` or `git push`:

```bash
# Check what's staged
git status
git diff --cached --name-only

# Critical .gitignore entries (where credentials hide):
.wrangler/  .next/  dist/  dist.zip  *.map
.env  .env.local  .env.*.local
*.pem  *.key  id_rsa*  id_ed25519*
```

For complete repository management (branch protection, secrets, gists, feature extraction patterns), see `references/github-repo-management-workflow.md`.

---

## Useful PR Commands Reference

| Action | gh | git + curl |
|--------|-----|-----------|
| List my PRs | `gh pr list --author @me` | `curl -s -H "Authorization: token $GITHUB_TOKEN" "https://api.github.com/repos/$OWNER/$REPO/pulls?state=open"` |
| View PR diff | `gh pr diff` | `git diff main...HEAD` (local) or `curl -H "Accept: application/vnd.github.diff" ...` |
| Add comment | `gh pr comment N --body "..."` | `curl -X POST .../issues/N/comments -d '{"body":"..."}'` |
| Request review | `gh pr edit N --add-reviewer user` | `curl -X POST .../pulls/N/requested_reviewers -d '{"reviewers":["user"]}'` |
| Pre-push credential check | `references/pre-push-checks.md` — mandatory credential audit before any push |
| Push Troubleshooting | `references/fork-workflow.md` — complete fork-based workflow when no write access to origin |
| | `references/push-auth-troubleshooting.md` — HTTPS push auth failures: SSH fallback, embedded URL token, token scope traps, diagnostic sequence, cleanup |
| | `references/gh-path-note.md` — why /home/thomas/bin/gh must be hardcoded in Python scripts |
| | `references/pyright-usage.md` — static type checking with pyright |
| New repo + first PR | `references/new-repo-first-pr.md` — new repo creation, first branch pushed becomes default, pushing main first, using --body-file safely |
| Handling divergent branches | `references/divergent-branch-strategy.md` — soft-reset squash when upstream changed same files; bypass nested rebase/merge conflicts |
| Check out someone's PR | `gh pr checkout N` | `git fetch origin pull/N/head:pr-N && git checkout pr-N` |
| New repo, first PR traps | `references/new-repo-first-pr.md` — README persists trap, default branch trap, verify clean extraction |
| PyPI publishing | `references/pypi-publishing.md` — build, upload, verify, and lockfile traps |
| Repo health monitoring | `references/benclawbot-repo-health.md` — 3-script system for all 29 benclawbot repos: PR digest, project health, iAgent-windows specific |