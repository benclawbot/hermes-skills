# Skill Security & Hygiene Audit

Use when Thomas says "remove risky skills", "audit skills", "clean up skills", or asks
about a hub-installed skill that might be dangerous. The `csl-policy` skill (bundled,
active security gate) uses `tirith` (binary in `~/.hermes/bin/`) to scan every skill at
install time and writes a `scan_verdict` into `~/.hermes/skills/.hub/lock.json`. The
audit reads that verdict, not vibes.

## The 4-tier priority for a "remove risky skills" request

1. **Unambiguously dangerous** — `scan_verdict: "dangerous"` in `.hub/lock.json` with
   `trust_level: "community"`. Move the skill directory to `~/.hermes/skills/.hub/quarantine/`
   and remove its entry from `lock.json` (use `hermes curator` if available, else edit
   the JSON directly). The quarantine dir is pre-built and currently empty.
2. **Wrong platform** — installed but the target environment is wrong. e.g.
   `apple/apple-notes`, `apple/macos-computer-use`, `apple/findmy`, `apple/imessage`
   on a Linux box; `minecraft-modpack-server`, `pokemon-player`, `touchdesigner-mcp`
   on a server with no GUI. Cheap to remove: just `rm -rf` the dir.
3. **Never used** — installed but `last_used_at == null` AND `last_viewed_at == null`
   in `~/.hermes/skills/.usage.json`. Filter out skills the user obviously *might* use
   (e.g. a fresh install) by checking `created_at` recency. The standard 46-skill
   "never used" list is mostly noise — most are correctly named dirs whose base name
   matches a category dir and the flat-name check fires false positives. Confirm by
   checking `last_used_at` AND that the skill actually has a `SKILL.md` on disk.
4. **Stale** — `last_used_at` more than ~14 days ago. Don't remove these on a single
   audit; they may be legitimate low-frequency tools (`csl-policy` itself shows
   23d stale but is the active security gate).

Always present findings as **tiered** so the user can pick scope. They said "remove
risky" not "clean house" — don't silently bundle all tiers together.

## Diagnosis sequence

```bash
# 1. Find hub-flagged skills (the real "risky" set)
cat ~/.hermes/skills/.hub/lock.json | python3 -m json.tool \
  | grep -B1 -A1 'scan_verdict'

# 2. Get the block history (verifies the gate actually fired, not just the verdict)
cat ~/.hermes/skills/.hub/audit.log

# 3. Check the quarantine slot exists and is empty
ls -la ~/.hermes/skills/.hub/quarantine/

# 4. Find never-used installed skills
python3 -c "
import json
data = json.load(open('/home/thomas/.hermes/skills/.usage.json'))
for n,v in sorted(data.items()):
    if v.get('last_used_at') is None and v.get('last_viewed_at') is None:
        print(n)
"
```

## What a "dangerous" verdict means concretely

The `taste-skill` case (the reference example) — `scan_verdict: "dangerous"` with
`6_findings` in audit.log, `trust_level: "community"`, `source: "clawhub"`. The skill
itself is honest about its surface area: "may propose CLI commands, skill folder edits,
onboarding steps, and publish or install actions that require user review." It can
shell out, modify other skills, and propose install/publish actions. That's the shape
of "risky" — broad write/exec surface, low trust provenance.

The reverse case — `baoyu-article-illustrator` shows `scan_verdict: "backfilled"` and
`trust_level: "builtin"`. "Backfilled" is informational (skill was pre-staged from
`optional-skills`, not freshly scanned), not a security flag. Don't conflate the two.

## Skill visibility gotcha

`skills_list` shows skills by the **description's name**, but `skill_view(name="X")`
looks up by **registered manifest name**. The same logical skill can show up as
`taste` in one and `taste-skill` in another (the `taste-skill` directory's manifest
declares the name as `taste`). If `skill_view` returns "not found" for something
`skills_list` shows, the skill may already be inert — or just inconsistently
registered. Either way, the agent can't load it, so removal is low-risk.

## Removing dangerous skills — exact procedure

```bash
# 1. Move to quarantine (preserves the install, lets you restore if wrong)
mv ~/.hermes/skills/<skill-name> ~/.hermes/skills/.hub/quarantine/

# 2. Edit .hub/lock.json — remove the "installed" entry, also remove from
#    .usage.json if present. Preserve JSON validity (use python -m json.tool to verify).

# 3. Verify the lock is still valid JSON
python3 -m json.tool ~/.hermes/skills/.hub/lock.json > /dev/null

# 4. Append a line to .hub/audit.log so the next audit sees the cleanup
echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) QUARANTINED <skill-name> clawhub:community dangerous" \
  >> ~/.hermes/skills/.hub/audit.log

# 5. Gateway restart is NOT required for skill removals — skills are read at session
#    start. A /reset in chat is enough.
```

## Pitfalls

- **Don't conflate "backfilled" with "dangerous"** — `scan_verdict: "backfilled"` means
  the skill was pre-staged before the scanner ran. It's a metadata gap, not a security
  finding. The fix is re-running the scanner (`hermes curator` does this on schedule),
  not removing the skill.
- **Don't use `skill_manage(action="delete")` on hub-installed skills** — the
  `hermes-agent` skill (bundled) and any skill marked `installed` in `.hub/lock.json`
  is protected. `skill_manage` will refuse; you must `mv` the directory and edit
  `lock.json` by hand.
- **Don't trust `skills_list` as ground truth for "is this skill loaded?"** — it lists
  everything the agent *knows about* including manifest entries that have no local
  `SKILL.md` (e.g. entries in `.bundled_manifest` like `arxiv`, `obliteratus`,
  `macos-computer-use`). Use `find ~/.hermes/skills/ -name SKILL.md` to get the real
  installed set.
- **Don't recommend `hermes curator` cleanup for "remove risky"** without first
  reading `.curator_state` — the curator archives into `.archive/` (still queryable),
  it doesn't delete. If Thomas wants the skill *gone*, manual removal is the path.
