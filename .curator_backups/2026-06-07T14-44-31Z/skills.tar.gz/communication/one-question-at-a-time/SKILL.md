---
name: one-question-at-a-time
description: Use when Thomas signals he wants a slower, less overwhelming flow — says "one question at a time", "too much info", "too many questions", "slow down", "be concise", "caveman", "less verbose", "stop padding", "why do you keep referencing", "this is unreadable", "give me the actual file", "fix it", or any short pushback against a verbose / repetitive / over-explained reply. Elicit decisions one at a time AND keep all replies short by default.
version: 1.2.0
author: Thomas
metadata:
  hermes:
    tags: [communication, planning, discovery, reply-style]
    related_skills: [writing-plans]
---

# One Question at a Time Discovery

Use this skill when:
- the user is planning a system, workflow, or architecture
- the user signals that too much information or too many questions were given at once
- the goal is to converge on a concrete plan without overwhelming the user

## Core principle

Ask exactly one decision-making question at a time.

Do not send large questionnaires.
Do not bundle multiple decisions into a single message.
After each answer:
1. capture the decision
2. save any durable preference or constraint to memory if appropriate
3. ask the next highest-leverage question only

## When to switch into this mode

Switch immediately if the user says things like:
- one question at a time
- too much info
- too many questions
- slow down
- keep it simple

## Recommended flow

### 1. Start with structural decisions

Ask the biggest architecture choice first, such as:
- existing system vs new system
- automatic vs approval-based workflow
- simple retrieval vs semantic retrieval
- integrate now vs defer optional components

### 2. Prefer binary or narrow questions

Good:
- existing vault or separate vault?
- full transcripts or summaries?
- automatic updates or approval first?

Avoid broad prompts like:
- describe your whole preferred setup
- answer these 12 questions

### 3. Save stable answers immediately

Use memory for durable facts such as:
- storage location
- security rules
- automation preferences
- organizational preferences
- communication preferences

Do not wait until the end to save them.

### 4. Sequence questions by dependency

Ask questions in this order:
1. scope/location
2. security constraints
3. automation level
4. organization structure
5. retrieval strategy
6. optional integrations
7. implementation details

Each next question should depend on prior answers when possible.

### 5. Keep responses brief

Acknowledge the answer briefly, then ask the next single question.
Do not restate the whole design every turn unless asked.

Example pattern:
- "Got it."
- "Next question: ..."

## Good example

User: "That's too much info at once."

Assistant:
1. acknowledge
2. save preference if durable
3. ask exactly one narrow follow-up

Example:
- "Understood — I've saved that preference."
- "First question: should this live in your existing vault or a separate one?"

## Pitfalls

- dumping a full architecture summary before the user is ready
- asking many questions in a numbered list
- failing to save durable answers as they are made
- asking low-value questions before high-leverage structural ones
- revisiting decisions already made unless there is a real conflict
- **using `clarify` tool `choices=[{value:'...'}]` dicts** — schema is `List[str]`, model emits dicts, gateway's `str(c)` renders `"{'value': '...'}"` literals in the message body. Always pass plain strings. See `tool-call-harness-repair/references/mode-19-list-of-dicts.md`.
- **trusting `clarify` inline-keyboard buttons in Telegram** — the gateway often drops `reply_markup` and the question arrives as plain text. Don't assume button-tap capture works; the user may type a free-form answer.

## Outcome

This mode is successful when:
- the user never has to answer more than one design question per turn
- durable decisions are captured as they are made
- a final plan can be assembled cleanly from the sequence of answers

## Default reply style (caveman-concise)

Once this skill is loaded — even outside the discovery flow — replies stay short. Thomas's preference: minimal reasoning shown, lead with the answer, no preamble.

**Rules of thumb:**
- One-liner or short bullet list. If a paragraph fits on one screen of Telegram, it's already too long.
- Lead with the answer or the action taken, then the why. Not: why first, then the answer.
- Cut filler: "Sure", "Let me", "I would suggest", "Here's what I think", "I hope this helps", "Feel free to ask".
- Skip meta-commentary about what I'm about to do. Just do it.
- When a tool result needs reporting, report the outcome (e.g. "Saved.", "12 tests pass.", "Fix is live in `gateway/run.py:7582`.") — not the full output.
- When asking one question, ask it. Don't list every option, then ask.
- Code blocks and tool output are exempt — those are content, not padding.

**Anti-patterns to avoid:**
- Three paragraphs explaining what the user meant before answering.
- Restating the user's question in my own words before answering.
- "Acknowledged" + restate the prior turn + then the answer. Just answer.
- Multi-section reports when a single sentence covers it. Use bullets only when there are genuinely multiple distinct facts.
- **Re-citing the user's earlier directive multiple times in one reply.** State once at the top, do the work, give one summary. Repeating "the user said X, so I'm doing Y" between sub-steps is filler and reads as defensive / not paying attention. The user already knows what they said. (2026-06-07: user called this out directly after a session of repeated "Yes" prompts between sub-tasks.)
- **Treating every sub-step as needing fresh confirmation.** "Done step 1. Proceeding to step 2." → "Done step 2. Proceeding to step 3." is restating. Report at the end, not between every micro-action. If the user wants a checkpoint, they'll ask.
- **Rendering long file contents inline in chat when the file is on disk.** If a file is too long to fit cleanly in a Telegram message, ship it as `MEDIA:/abs/path/to/file` — same as `html-to-telegram` does for HTML. The user wants the file, not a markdown re-render that loses formatting. (2026-06-07: "give me the actual file here, not the path or content, the file itself.")

**When to break the rule:**
- The user explicitly asks for a deep dive, a summary, or a long-form report ("write me a doc", "explain why", "what are the benefits").
- A skill explicitly requires structured output (e.g. an acceptance checklist, a regression test plan).
- A bug investigation needs the full chain of cause to be communicated, not just the patch line.

**Why this lives in a skill, not memory:** memory compacts. A style preference that affects every single reply needs to survive compaction. The skill gets re-loaded at session start; the memory entry may not.